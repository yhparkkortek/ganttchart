# -*- coding: utf-8 -*-
# ══════════════════════════════════════════════════════════════
# SAP GUI Scripting 32비트 브릿지 (2026-09-14 신규)
#
# kortek_backend.py(64비트 Python)는 win32com.client.GetObject("SAPGUI")로 SAP GUI에
# 직접 붙을 수 없다 — SAP GUI Scripting의 COM 컴포넌트가 32비트로만 등록돼 있기 때문
# (레지스트리 HKLM\SOFTWARE\WOW6432Node\SAP\SAPGUI Front\...\Security 에만 존재, 64비트
# 레지스트리 뷰에는 없음 — 실사용 진단으로 확인: 64비트 Python에서는 GetObject("SAPGUI")가
# 항상 COM 오류 -2147221020(MK_E_SYNTAX, "SAPGUI 항목을 찾을 수 없음")로 실패했고, 32비트
# Python에서는 즉시 정상적으로 연결을 찾았다). 그래서 이 스크립트를 32비트 Python
# (`py -3-32`)으로 별도 프로세스 실행해서, 실제 COM 작업은 여기서만 하고 결과를 JSON 한 줄로
# stdout에 출력한다 — kortek_backend.py는 이 출력을 그대로 읽어서 응답에 실어 보낸다.
#
# 단독으로 두 번째 인자 없이 실행하면 "현재 SAP 화면"을 덤프한다. 특정 트랜잭션 전용
# 파서를 만들지 않고(화면 종류가 바뀔 때마다 코드를 또 고치지 않기 위해), 화면에 ALV
# 그리드가 있으면 그리드를, 없으면 보이는 라벨/입력필드 텍스트를 최대한 있는 그대로
# 덤프해서 AI(callAiBackend)에게 구조화를 맡긴다 — kortek_backend.py의 예전 설계를 그대로
# 옮겨온 것.
#
# 두 번째 인자로 "open_document"를 주면(세 번째 인자로 문서 타입, 예: P01) 다른 동작 —
# MM03에서 이미 열어둔 자재의 "문서 데이터" 탭에서 그 문서 타입 행을 찾아 열고, 첨부된
# 원본 파일을 더블클릭해서 연결된 프로그램(Acrobat 등)으로 바로 연다. 2026-09-14 실사용
# 화면 녹화(SAP GUI "기록 및 재생")로 얻은 정확한 컨트롤 ID를 일반화한 것 — 절대경로
# 대신 "화면 어디에 있든 ID에 특정 문자열이 포함된 컨트롤을 재귀 탐색"하는 방식을 써서,
# 자재 유형별로 화면 서브구조 번호(SUB2/SUB7 등)가 달라져도 최대한 버티도록 했다.
# 네 번째 인자로 자재번호를 같이 주면(예: open_document P01 106188) 사람이 화면을 미리
# 열어둘 필요 없이 이 스크립트가 직접 MM03으로 이동해 그 자재를 조회한 뒤 "문서 데이터"
# 탭까지 연다(2026-09-15 실사용 화면 녹화로 추가 — `_navigate_to_material_document_tab`).
# 자재번호를 안 주면 기존과 동일하게 "사람이 미리 열어둔 화면"을 그대로 사용한다(하위호환).
#
# 두 번째 인자로 "download_documents_batch"를 주면(세 번째 인자로 문서 타입, 네 번째 인자로
# 쉼표구분 자재번호 목록) 여러 자재의 문서를 ZDMSR004("DMS 첨부파일 일괄 다운로드 프로그램")로
# 한 번에 `C:\SAP_DMS\`에 다운로드한다 — 자재 1개씩 MM03을 드릴다운하는 open_document보다
# 여러 개를 한 번에 처리할 때 훨씬 빠르다(2026-09-15 실사용 SAP GUI "기록 및 재생" 매크로로
# 확보한 정확한 컨트롤 ID 그대로 재현 — `download_documents_batch` 참고).
#
# 두 번째 인자로 "fetch_bom"을 주면(세 번째 인자로 자재번호, 네 번째 인자로 플랜트 — 생략 시
# 1000) ZPP038("BOM 전개")로 직접 이동해 그 자재의 BOM을 조회한 뒤 화면을 그대로 텍스트로
# 읽어온다(2026-09-15 실사용 매크로로 확보 — `fetch_bom`/`_navigate_to_bom_screen` 참고).
# ══════════════════════════════════════════════════════════════
import sys
import os
import json
import re
import time
import threading

# 💡 [2026-09-14 버그수정] 이 스크립트는 kortek_backend.py가 subprocess.run(capture_output=True)로
# 실행한다 — stdout이 실제 콘솔이 아니라 파이프로 연결되면, Windows에서는 Python이 시스템 ANSI
# 코드페이지(한국어 Windows면 cp949)로 stdout 인코딩을 잡는 경우가 있다. 이 스크립트의 오류
# 메시지엔 "—"(em dash, U+2014) 같은 cp949로 표현 안 되는 문자가 섞여 있어서, print(json.dumps(...))
# 시점에 UnicodeEncodeError로 죽어버려 "예상치 못한 오류" 자리에 오히려 이 인코딩 오류 자체의
# traceback이 사용자에게 그대로 노출되는 사고가 실사용에서 발생했다(진짜 원인은 감춰지고 무관한
# 인코딩 오류만 보임). stdout/stderr를 UTF-8로 명시적으로 재설정해서 원천 차단한다.
if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    sys.stderr.reconfigure(encoding='utf-8', errors='replace')


# 🆕 [2026-09-21, Phase 10] 실패 시점의 "어느 단계였는지" 표지. 처음엔 fetch_bom 등 진단이 모호했던
#    지점에만 점진적으로 심는다(없으면 이슈 수집은 오류 문구+화면 스냅샷만으로 군집화).
_CUR_STAGE = ['']


def _stage(name):
    _CUR_STAGE[0] = name


def _sap_gui_process_running():
    """SAP GUI(SAP Logon)가 실행 중인지 프로세스 목록으로 확인한다. 확인이 불가능하면 True(=모름, 기존 안내 유지).
    COM 오류 -2147221020은 "SAP GUI가 안 켜져 있음"과 "켜져 있지만 스크립팅이 꺼져 있음" 둘 다에서 똑같이
    나오므로, 이걸 구분해야 사용자를 올바른 조치(로그인 vs 스크립팅 설정)로 안내할 수 있다(Phase 10 첫 실데이터)."""
    try:
        import subprocess
        out = subprocess.run(['tasklist', '/NH'], capture_output=True, text=True, timeout=5, errors='replace').stdout.lower()
        if not out.strip():
            return True
        return any(n in out for n in ('saplogon.exe', 'sapgui.exe', 'saplgpad.exe'))
    except Exception:
        return True


def _get_sap_session():
    """이미 로그인돼 열려 있는 SAP GUI의 첫 번째 연결/세션을 가져온다."""
    import win32com.client
    try:
        sap_gui_auto = win32com.client.GetObject("SAPGUI")
    except Exception as e:
        hresult = None
        try:
            hresult = e.args[0] if e.args else None
        except Exception:
            pass
        if hresult == -2147221020:
            if not _sap_gui_process_running():
                raise RuntimeError('SAP GUI가 실행 중이 아닙니다 — SAP Logon을 실행해 로그인해주세요. 로그인한 뒤 다시 시도하면 됩니다.')
            raise RuntimeError('SAP GUI Scripting이 아직 켜져 있지 않습니다(COM 오류 -2147221020/MK_E_SYNTAX — "SAPGUI" 항목을 찾을 수 없음). 확인해주세요: ① SAP GUI가 켜져 있고 로그인돼 있는지 ② SAP GUI 세션 안에서 Alt+F12 → 옵션(Options) → Accessibility & Scripting → Scripting → "스크립트 사용(Enable Scripting)" 체크 후 세션을 다시 열었는지. 그래도 안 되면 SAP 서버 쪽 파라미터(sapgui/user_scripting) 문제일 수 있어 사내 SAP 담당자(Basis) 확인이 필요합니다.')
        raise RuntimeError('SAP GUI Scripting 엔진을 찾지 못했습니다. SAP GUI가 켜져 있는지 확인하세요. (원본 오류: ' + str(e) + ')')
    application = sap_gui_auto.GetScriptingEngine
    if application.Children.Count == 0:
        raise RuntimeError('SAP GUI Scripting 엔진 연결에는 성공했지만, 열려 있는 SAP 연결(접속)이 없습니다 — SAP에 로그인해주세요.')
    connection = application.Children(0)
    if connection.Children.Count == 0:
        raise RuntimeError('SAP 연결은 있지만 열려 있는 세션(화면)이 없습니다.')
    return connection.Children(0)


def _sap_find_grid(container, depth=0):
    """창 트리를 재귀 탐색해 첫 번째 ALV 그리드(GuiShell, SubType=GridView)를 찾는다."""
    if depth > 12:
        return None
    try:
        children = container.Children
    except Exception:
        return None
    if children is None:
        return None
    for i in range(children.Count):
        child = children.Item(i)
        try:
            if child.Type == 'GuiShell' and child.SubType == 'GridView':
                return child
        except Exception:
            pass
        found = _sap_find_grid(child, depth + 1)
        if found is not None:
            return found
    return None


def _sap_dump_grid(shell):
    """ALV 그리드의 보이는 열/행을 탭 구분 텍스트로 변환. 응답 크기 보호를 위해 최대 500행.
    ⚠️⚠️ [2026-09-15 실사용 진단] `shell.GetColumnTitle(cid)`는 `GuiGridView`에 실제로
    존재하는 메서드가 아니다(항상 예외 → 아래 except에서 원본 필드 코드 `cid`로 폴백) —
    "진짜" 메서드 이름은 `GetDisplayedColumnTitle(cid)`이지만, **의도적으로 이걸로 고치지
    않는다**: 실사용 SAP 세션에 직접 접속해 확인한 결과, 그 메서드가 반환하는 한글 텍스트가
    SAP GUI Scripting 내부에서 이미 복구 불가능하게 깨져서 나온다(Python에서 받은 문자열에
    유니코드 대체문자 U+FFFD가 섞여 있어 어떤 인코딩으로도 복구 불가 — Windows/SAP 세션
    코드페이지는 둘 다 정상인데도 발생, SAP GUI Scripting 자체의 한글 처리 버그로 추정).
    즉 "메서드 이름을 고치면" 코드(MTART 등, 최소한 읽을 순 있음) 대신 깨진 쓰레기 문자열이
    나오게 되므로 지금처럼 실패시키고 코드로 폴백하는 게 더 낫다 — 한글 헤더는 대신
    js/04h의 `window._SAP_FIELD_LABEL_MAP`(표준 SAP 필드명 사전)로 프런트엔드에서 치환한다.
    자세한 진단 과정은 CLAUDE.md의 "SAP GUI Scripting ALV 그리드의 한글이 원천적으로 깨져서
    나온다" 항목 참고."""
    try:
        col_ids = list(shell.ColumnOrder)
    except Exception:
        col_ids = []
    if not col_ids:
        return None
    titles = []
    for cid in col_ids:
        try:
            titles.append(shell.GetColumnTitle(cid) or cid)
        except Exception:
            titles.append(cid)
    total_rows = shell.RowCount
    row_count = min(total_rows, 500)
    lines = ['\t'.join(titles)]
    # SAP ALV는 화면에 보이는 행만 렌더링 → 스크롤 밖 행은 GetCellValue가 '' 반환
    # firstVisibleRow를 30행마다 강제 이동해 전 구간을 렌더링시킨다 (2026-09-29 수정)
    _SCROLL_STEP = 30
    for r in range(row_count):
        if r % _SCROLL_STEP == 0:
            try:
                shell.firstVisibleRow = r
                time.sleep(0.08)
            except Exception:
                pass
        cells = []
        for cid in col_ids:
            try:
                cells.append(str(shell.GetCellValue(r, cid)))
            except Exception:
                cells.append('')
        lines.append('\t'.join(cells))
    if total_rows > row_count:
        lines.append(f'... (총 {total_rows}행 중 {row_count}행만 표시)')
    return '\n'.join(lines)


def _sap_dump_fields(container, depth=0, max_depth=10):
    """그리드가 없는 화면(선택화면/상세화면 등)을 위한 대체 경로 — 라벨/입력필드 텍스트를
    보이는 순서대로 모아 평문으로 만든다."""
    lines = []
    if depth > max_depth:
        return lines
    try:
        children = container.Children
    except Exception:
        return lines
    if children is None:
        return lines
    for i in range(children.Count):
        child = children.Item(i)
        try:
            ctype = child.Type
        except Exception:
            continue
        if ctype in ('GuiLabel', 'GuiTextField', 'GuiCTextField', 'GuiComboBox', 'GuiCheckBox', 'GuiRadioButton'):
            try:
                text = (child.Text or '').strip()
                if text:
                    lines.append(text)
            except Exception:
                pass
        lines.extend(_sap_dump_fields(child, depth + 1, max_depth))
    return lines


def _sap_find_shell_any(container, depth=0):
    """창 트리를 재귀 탐색해 SubType 무관하게 첫 번째 GuiShell을 찾는다(2026-09-15 신규) —
    `_sap_find_grid`는 SubType이 정확히 'GridView'인 것만 찾는데, 일부 화면(예: ZPP038의
    "부모-자식 계층" 표시 모드처럼 ALV가 트리로 나오는 경우 — "BOM 표준가 부모-자식
    계층.vbs" 매크로로 이런 표시 모드가 존재함을 확인함)은 GuiShell이지만 SubType이
    GridView가 아닐 수 있어, 그런 화면도 놓치지 않기 위한 더 넓은 탐색."""
    if depth > 12:
        return None
    try:
        children = container.Children
    except Exception:
        return None
    if children is None:
        return None
    for i in range(children.Count):
        child = children.Item(i)
        try:
            if child.Type == 'GuiShell':
                return child
        except Exception:
            pass
        found = _sap_find_shell_any(child, depth + 1)
        if found is not None:
            return found
    return None


def _sap_dump_tree(shell):
    """GridView가 아닌 GuiShell(Tree류로 추정)을 텍스트로 덤프해본다(2026-09-15 신규,
    ⚠️ 실사용 미검증 — SAP GUI Tree 컨트롤의 정확한 스크립팅 API는 버전/화면마다 다를 수
    있어 여러 방식을 순서대로 시도한다). 전부 실패하면 None을 반환해 호출부가
    `_sap_dump_fields`로 폴백할 수 있게 한다."""
    try:
        node_keys = list(shell.GetAllNodeKeys())
    except Exception:
        return None
    if not node_keys:
        return None

    col_names = []
    try:
        col_names = list(shell.GetColumnNames())
    except Exception:
        col_names = []

    lines = []
    if col_names:
        lines.append('\t'.join(str(c) for c in col_names))
    max_nodes = 500
    for key in node_keys[:max_nodes]:
        row_vals = []
        if col_names:
            for col in col_names:
                val = ''
                for attempt in ('GetItemText', 'GetCellValue'):
                    try:
                        val = str(getattr(shell, attempt)(key, col))
                        break
                    except Exception:
                        continue
                row_vals.append(val)
        else:
            val = ''
            for attempt_fn in (lambda: shell.GetNodeTextByKey(key), lambda: shell.GetItemText(key, '')):
                try:
                    val = str(attempt_fn())
                    break
                except Exception:
                    continue
            row_vals.append(val)
        if any(row_vals):
            lines.append('\t'.join(row_vals))
    if not lines or (col_names and len(lines) <= 1):
        return None  # 컬럼 제목행만 있고 실제 값을 하나도 못 읽었으면 실패로 간주
    if len(node_keys) > max_nodes:
        lines.append(f'... (총 {len(node_keys)}개 노드 중 {max_nodes}개만 표시)')
    return '\n'.join(lines)


def _sap_dump_screen_body(wnd):
    """현재 화면을 "그리드 → 트리 → 필드" 순서로 시도해 텍스트로 덤프하고 (본문, source)를
    반환한다(2026-09-15 신규 — fetch_current_screen/fetch_material_documents/fetch_bom이
    각자 반복하던 2단계 폴백 로직을 하나로 통합 + 트리 지원 추가). source는
    'grid'|'tree'|'fields' 중 하나, 아무것도 못 읽으면 (None, None)."""
    grid = _sap_find_grid(wnd)
    if grid is not None:
        body = _sap_dump_grid(grid)
        if body:
            return body, 'grid'

    shell = _sap_find_shell_any(wnd)
    if shell is not None:
        body = _sap_dump_tree(shell)
        if body:
            return body, 'tree'

    body = '\n'.join(_sap_dump_fields(wnd))
    if body:
        return body, 'fields'
    return None, None


def fetch_current_screen():
    session = _get_sap_session()
    wnd = session.findById('wnd[0]')
    try:
        title = wnd.Text
    except Exception:
        title = ''
    try:
        transaction = session.Info.Transaction
    except Exception:
        transaction = ''
    try:
        status_text = session.findById('wnd[0]/sbar').Text
    except Exception:
        status_text = ''

    body, source = _sap_dump_screen_body(wnd)

    if not body:
        return {'ok': False, 'error': '현재 SAP 화면에서 읽을 수 있는 데이터를 찾지 못했습니다.'}

    header = f'[SAP 화면: {title}]\n[트랜잭션: {transaction}]\n'
    if status_text:
        header += f'[상태표시줄: {status_text}]\n'
    text = header + '\n' + body
    return {'ok': True, 'source': source, 'text': text}


# ── "화면 트리 통째로 덤프" (2026-09-23 신규, "SAP를 빠르게 마스터하는 법" 사용자 요청) ──
# 지금까지 새 SAP 기능을 붙일 때마다 사용자가 준 "기록 및 재생" 매크로(.vbs)나 스크린샷을
# 사람이 해석해서 필드 ID를 추측해왔다(팀운영비 기간지정 버그가 그 부작용 — 코드 주석
# 곳곳의 "추측 금지 원칙"도 이 문제의 방증). 매크로 해석 대신, 지금 SAP 화면에 떠 있는
# GuiComponent 트리 전체(Id·Type·SubType·Name·편집가능여부·**Text 값까지**)를 사람이
# 읽을 수 있는 텍스트로 그대로 덤프하는 범용 도구 — 새 기능이 필요하면 "그 화면을 열어두고
# 이 명령을 한 번 실행해서 결과를 보내주세요"만 요청하면, 매크로 해석 없이 정확한 findById
# 경로를 바로 확인할 수 있다.
# ⚠️ `_capture_failure_snapshot`(Phase 10 이슈 자동수집용)과는 목적이 다르다 — 그건 자동/
#    백그라운드로 수집되므로 필드 값을 마스킹하고 구조만 남기지만, 이건 사람이 새 기능을
#    만들려고 그때그때 수동으로 부르는 진단 도구라 값(Text)까지 그대로 남긴다. 자동 트리거
#    금지 — 반드시 사람이 명시적으로 요청했을 때만 호출할 것.
_DUMP_MAX_NODES = 1500
_DUMP_MAX_SECONDS = 8.0
_DUMP_SKIP_DESCEND = ('GuiMenubar', 'GuiStatusbar')


def _dump_safe_text(node):
    try:
        t = str(node.Text)
    except Exception:
        return ''
    return t.replace('\r', '').replace('\n', ' ¶ ')[:200]


def dump_screen_tree(save_dir=None):
    """지금 열려 있는 SAP 화면의 GuiComponent 트리 전체를 findById 상대경로 + Type/SubType/
    Text 그대로 텍스트로 덤프한다. `save_dir`을 주면 C:\\SAP_DMS 아래에 파일로도 남겨 매번
    채팅창에 옮겨 붙이지 않고 재사용할 수 있게 한다."""
    session = _get_sap_session()
    try:
        title = session.findById('wnd[0]').Text
    except Exception:
        title = ''
    try:
        info = session.Info
        tcode = str(info.Transaction)
        program = str(info.Program)
        screen = str(info.ScreenNumber)
    except Exception:
        tcode = program = screen = ''
    try:
        win_count = int(session.Children.Count)
    except Exception:
        win_count = 1

    t0 = time.time()
    lines = []
    total = 0
    truncated = False
    # 🐛 [2026-10-02] 팝업(wnd[1]+)을 **먼저** 덤프한다.
    #   예전엔 wnd[0]부터 돌았는데, MB21 신규품목처럼 wnd[0]이 큰 화면(43행 그리드 ≈ 350노드)이면
    #   8초 제한에 걸려 정작 보고 싶던 팝업(MB21 "코딩 블록" wnd[1])까지 가지도 못하고 끊겼다.
    #   사람이 덤프를 뜨는 순간 팝업이 떠 있다면 보통 그 팝업이 목적이다 — 작기도 해서 거의 공짜.
    win_order = list(range(1, win_count)) + [0]
    for wi in win_order:
        if total >= _DUMP_MAX_NODES or (time.time() - t0) >= _DUMP_MAX_SECONDS:
            truncated = True
            break
        try:
            wnd = session.findById('wnd[%d]' % wi)
        except Exception:
            continue
        lines.append(f'[wnd[{wi}]] text="{_dump_safe_text(wnd)}"')
        queue = [(wnd, 0)]
        while queue:
            if total >= _DUMP_MAX_NODES or (time.time() - t0) >= _DUMP_MAX_SECONDS:
                truncated = True
                break
            node, depth = queue.pop(0)
            try:
                children = node.Children
                count = children.Count
            except Exception:
                continue
            for ci in range(count):
                if total >= _DUMP_MAX_NODES or (time.time() - t0) >= _DUMP_MAX_SECONDS:
                    truncated = True
                    break
                try:
                    ch = children.Item(ci)
                except Exception:
                    continue
                total += 1
                try:
                    ctype = str(ch.Type)
                except Exception:
                    ctype = '?'
                try:
                    subtype = str(getattr(ch, 'SubType', '') or '')
                except Exception:
                    subtype = ''
                try:
                    cid = str(ch.Id)
                    rel = cid.split('ses[0]/', 1)[-1] if 'ses[0]/' in cid else cid
                except Exception:
                    rel = '?'
                try:
                    name = str(getattr(ch, 'Name', '') or '')
                except Exception:
                    name = ''
                try:
                    chg = ' [편집가능]' if ch.Changeable else ''
                except Exception:
                    chg = ''
                # 🆕 [2026-09-23] 라디오버튼/체크박스는 "무엇이 선택돼 있는가"가 핵심 정보인데
                # text만 찍어서는 알 수 없다 — 실제로 ZMMR060의 등록/조회 라디오 상태를 못 봐서
                # 구매오더 업로드 실패 원인 판정이 막혔다(실사용 진단, 2026-09-23). 상태를 같이 찍는다.
                sel = ''
                if ctype in ('GuiRadioButton', 'GuiCheckBox'):
                    try:
                        sel = ' [선택됨✓]' if ch.Selected else ' [선택안됨]'
                    except Exception:
                        sel = ''
                type_part = f'{ctype}/{subtype}' if subtype else ctype
                name_part = f' name={name}' if name else ''
                indent = '  ' * (depth + 1)
                lines.append(f'{indent}{rel}  ({type_part}){name_part}{chg}{sel}  text="{_dump_safe_text(ch)}"')
                if ctype == 'GuiShell' and subtype == 'GridView':
                    try:
                        grid_dump = _sap_dump_grid(ch)
                    except Exception:
                        grid_dump = None
                    if grid_dump:
                        grid_lines = grid_dump.split('\n')
                        for gl in grid_lines[:60]:
                            lines.append(indent + '  │ ' + gl)
                        if len(grid_lines) > 60:
                            lines.append(indent + f'  │ …(그리드 {len(grid_lines)}행 중 60행만 표시)')
                if ctype not in _DUMP_SKIP_DESCEND and depth < 14:
                    queue.append((ch, depth + 1))

    header = (f'[SAP 화면 트리 덤프]\n트랜잭션: {tcode} / 프로그램: {program} / 화면번호: {screen}\n'
              f'창 제목: {title}\n노드 수: {total}건' + (' (시간/개수 제한으로 일부 생략됨)' if truncated else ''))
    body = header + '\n\n' + '\n'.join(lines)

    result = {'ok': True, 'tcode': tcode, 'program': program, 'screen': screen, 'nodeCount': total, 'truncated': truncated, 'text': body}
    if save_dir:
        try:
            os.makedirs(save_dir, exist_ok=True)
            safe_tcode = re.sub(r'[^A-Za-z0-9_-]', '_', tcode or 'unknown')
            fname = f'sap_screen_dump_{safe_tcode}_{time.strftime("%Y%m%d_%H%M%S")}.txt'
            fpath = os.path.join(save_dir, fname)
            with open(fpath, 'w', encoding='utf-8') as f:
                f.write(body)
            result['savedPath'] = fpath
        except Exception:
            pass
    return result


def navigate_and_dump(tcode, save_dir=None):
    """트랜잭션 코드로 이동 후 화면 트리를 덤프한다."""
    tcode = (tcode or '').strip().upper()
    if not tcode:
        raise RuntimeError('트랜잭션 코드가 필요합니다.')
    session = _get_sap_session()
    wnd = session.findById('wnd[0]')
    session.findById('wnd[0]/tbar[0]/okcd').text = '/n' + tcode
    wnd.sendVKey(0)
    time.sleep(1.2)
    return dump_screen_tree(save_dir)


# ── "BOM 조회" (ZPP038) 전용 헬퍼 ──────────────────────────────────────
# ⚠️⚠️ [2026-09-16 신규, 사용자 요청] "SAP ID를 공용으로 쓰는데 다른 팀원이 ALV 레이아웃을
# 바꿔놓으면 원하는 컬럼을 못 받는다 — 항상 이 레이아웃으로 조회하게 하드코딩할 수 있냐"는
# 요청으로 추가. 라이브 진단으로 확인함: ZPP033(단일 자재) BOM 전개 결과 그리드의 툴바
# 버튼 `&MB_VARIANT`("레이아웃 선택")를 누르면 회사 공용 레이아웃 목록(전역 변형, 이름이
# 전부 "/"로 시작 — 예: `/STD_MC`, `/CH_1` 등, 총 56건)이 담긴 팝업이 뜨고, 그 안의 자체
# 그리드(`VARIANT`/`TEXT`/`DEFAULT` 3컬럼)에서 원하는 행을 `DoubleClick(row, 'VARIANT')`
# 하면 그 즉시 팝업이 닫히고 메인 그리드 컬럼 구성이 그 레이아웃으로 바뀐다 — 사용자가 준
# 스크린샷 속 `/STD_MC`(기본 세팅으로 체크돼 있던 것)로 실제 전환해 컬럼이 달라지는 것까지
# 라이브로 확인함(`/CH_1`로 바꿨다가 다시 `/STD_MC`로 복귀시켜 컬럼이 정확히 원래대로
# 돌아오는 것도 확인). **주의: `DoubleClickCell`이 아니라 `DoubleClick`(그리드 전용 메서드
# 이름이 다름, `dir()`로 실제 멤버 확인해서 알아냄)** — 이름이 비슷해서 헷갈리기 쉬움.
# ⚠️ **ZPP038(복수 자재)은 별도 레이아웃 카탈로그를 쓴다** — 같은 진단으로 확인해보니
# ZPP038엔 `/STD_MC`가 아예 없음(23건 중 없음, ZPP033은 56건 중에 있음) — 그래서 이
# 강제 적용은 **그 이름이 없으면 조용히 건너뛰고 지금 화면을 그대로 쓰는** 방어적 설계다
# (강제 레이아웃은 "있으면 좋은" 보조 기능이지, 없다고 조회 자체를 막을 이유가 아님). 앞으로
# ZPP038에도 이런 고정 레이아웃이 필요해지면, 그 화면에 맞는 전역 레이아웃 이름을 별도로
# 확인해서 `_BOM_MULTI_LAYOUT_VARIANT` 같은 새 상수로 추가할 것 — 지금은 사용자가 실제로
# 보여준 화면(ZPP033 단일 자재)만 커버함.
_BOM_LAYOUT_VARIANT = '/STD_MC'  # 이 이름을 바꾸면 그 즉시 새 레이아웃이 강제 적용됨


def _sap_select_alv_layout(session, grid, variant_name):
    """ALV 그리드 툴바의 "레이아웃 선택"(`&MB_VARIANT`) 팝업을 열어, `variant_name`과 정확히
    일치하는 저장된 레이아웃(전역 변형)을 찾아 적용한다.
    반환값: `(성공여부: bool, 진단정보: str)` — 실패해도 예외를 던지지 않고(호출부가 "레이아웃
    강제 실패"를 조회 자체의 실패로 만들지 않기 위함) 지금 화면을 그대로 둔다. 다만 **실패
    사유는 반드시 진단정보로 돌려준다**(2026-09-21, Phase 10) — 예전엔 `bool`만 반환해서
    "고른 레이아웃이 왜 안 먹는지"를 어디서도 알 수 없었다(호출부가 결과 헤더에 남김).
    진단정보: `''`(성공) | `button_failed` | `no_popup` | `no_popup_grid` |
    `not_in_catalog:<이 화면 카탈로그의 실제 레이아웃 이름 최대 15개>` | `doubleclick_failed`"""
    def _cancel():
        try:
            session.findById('wnd[1]').sendVKey(12)
        except Exception:
            pass
    try:
        grid.PressToolbarButton('&MB_VARIANT')
    except Exception:
        return False, 'button_failed'
    time.sleep(0.4)  # 팝업이 뜰 시간
    try:
        popup = session.findById('wnd[1]')
    except Exception:
        return False, 'no_popup'
    try:
        inner = session.findById(popup.Id + '/usr/ssubD0500_SUBSCREEN:SAPLSLVC_DIALOG:0501/cntlG51_CONTAINER/shellcont/shell')
    except Exception:
        inner = None
    if inner is None:
        _cancel()
        return False, 'no_popup_grid'
    names = []
    found_row = None
    try:
        for r in range(inner.RowCount):
            v = (inner.GetCellValue(r, 'VARIANT') or '').strip()
            names.append(v)
            if found_row is None and v == variant_name:
                found_row = r
        if found_row is None:  # 1차 정확 일치 실패 → 대소문자만 다른 경우까지 2차 시도
            for r, v in enumerate(names):
                if v.lower() == (variant_name or '').strip().lower():
                    found_row = r
                    break
    except Exception:
        found_row = None
    if found_row is None:
        _cancel()
        return False, 'not_in_catalog:' + ' | '.join(names[:15])
    try:
        inner.DoubleClick(found_row, 'VARIANT')
        time.sleep(0.5)  # 그리드가 새 레이아웃으로 다시 그려질 시간
        return True, ''
    except Exception:
        _cancel()
        return False, 'doubleclick_failed'


def _navigate_to_bom_screen(session, wnd, materials, plant='1000', use_single_tcode=None,
                             explosion='single', show_price=False, show_location=False):
    """ZPP038("BOM 전개 (Multiple)", 복수 자재) 또는 ZPP033("BOM 전개", 단일 자재 전용)로
    이동해 지정한 자재(들)/플랜트의 BOM을 조회한다.
    **2026-09-15 신규**: 원래는 자재가 몇 개든 항상 ZPP038만 썼는데, 사용자가 실제 SAP 화면
    캡처(ZPP038 초기화면 — 붉은 박스로 "Explosion type"/"Option"을 표시)를 보여주며
    "복수 조회는 ZPP038, 단일 조회는 ZPP033을 쓴다"고 알려줘서 둘 다 지원하도록 확장함.
    라이브 세션에 `/nZPP038`·`/nZPP033`를 각각 띄워 직접 대조 진단한 결과: 자재 입력 필드만
    다르고(ZPP038: `ctxtMATNR-LOW` + "복수 선택" 팝업, ZPP033: `ctxtMATNR` 단일 필드) 나머지
    — 플랜트(`ctxtWERKS`)/대체BOM/계정레벨/효력시작일/기준수량, **Explosion type** 라디오
    버튼(`radR_1`="Single level" 기본선택, `radR_2`="Multi level"), **Option** 체크박스 중
    `chkSHOW_P`="Show price"/`chkSHOW_L`="Location Information" — 는 두 화면에서 완전히
    동일한 필드 ID로 확인됨(ZPP038엔 `chkP_MULTI`/`chkP_CK`가 더 있고 ZPP033엔 `chkP_STD`/
    `chkP_CUS`가 더 있지만, 이 함수가 다루는 세 옵션과는 무관).
    `use_single_tcode`(None|True|False) — None이면 `materials`가 리스트이고 2개 이상일 때
    자동으로 ZPP038(복수), 아니면 ZPP033(단일). 명시적으로 넘기면 자재 개수와 무관하게
    그걸 우선한다(사용자가 "복수"/"단일"을 말로 명시한 경우 `js/04h`가 판정해서 넘김).
    `explosion`은 `'single'`(기본, Single level) 또는 `'multi'`(Multi level).
    `show_price`/`show_location`은 Option 섹션의 두 체크박스 — AI 문답에서 조회 전에
    사람에게 먼저 물어보고(2026-09-15 사용자 요청, `js/04h`의 BOM 옵션 사전질문 참고) 그
    답을 받아 이 값들로 넘겨받는다.
    반환값: 실제로 사용된 `use_single_tcode`(bool, 자동 결정된 경우 호출부가 결과 라벨에
    쓸 수 있도록).
    ⚠️⚠️ ZDMSR004의 "자재코드 복수 선택" 팝업(필드명 `S_MATNR`)은 확인 버튼을 `btn[24]`,
    `btn[8]` 두 번 눌러야 했는데, 이 ZPP038의 팝업(필드명 `MATNR`, 접두사에 `S_` 없음 —
    SELECT-OPTIONS가 아니라 단순 PARAMETERS 필드로 추정)은 `btn[8]` 한 번만으로 충분했다
    (매크로로 확인) — 겉보기엔 같은 SAP 표준 SAPLALDB 팝업이라도 호출 맥락에 따라 필요한
    버튼 수가 다를 수 있다는 뜻이니, 새로운 트랜잭션의 복수 선택 팝업을 자동화할 때 이
    버튼 개수를 당연하게 가정하지 말고 매번 매크로로 확인할 것."""
    mat_list = list(materials) if isinstance(materials, (list, tuple)) else [materials]
    mat_list = [str(m).strip() for m in mat_list if str(m).strip()]
    if not mat_list:
        raise RuntimeError('자재번호를 지정해주세요.')
    if use_single_tcode is None:
        use_single_tcode = len(mat_list) <= 1

    session.findById('wnd[0]/tbar[0]/okcd').text = '/nZPP033' if use_single_tcode else '/nZPP038'
    wnd.sendVKey(0)
    time.sleep(0.6)
    wnd = session.findById('wnd[0]')

    # 💡⚠️ [2026-09-15 실사용에서 확인] "WERKS" 문자열이 "플랜트" 라벨 컨트롤
    # (`txt%_WERKS_%_APP_%-TEXT`)에도 걸려서, 단순 첫 매치(`_find_by_id_substring`)로는
    # 실제 입력칸(`ctxtWERKS`)이 아니라 이 라벨에 값을 넣고 "성공"으로 착각했었다 — 그 결과
    # 플랜트가 실제로는 비어 있어 실행(F8)이 SAP의 "필수 입력 필드" 오류로 조용히 막혔다
    # (사용자가 SAP 화면을 캡처해서 알려줘서 발견). `_set_text_on_best_candidate`로 후보를
    # 전부 모아 입력 가능한 타입부터 시도하도록 수정.
    plant_field = _set_text_on_best_candidate(wnd, 'WERKS', plant)
    # 플랜트 필드를 못 찾거나 값을 못 넣어도 일단 자재번호만으로 실행을 시도한다(플랜트가
    # 필수가 아닌 변형 화면일 수도 있어서) — 필수인데 비면 아래 실행(F8) 단계에서 SAP가
    # 화면에 오류를 표시하고, 그 경우 결과 화면에도 그리드가 없어 최종적으로 실패로 보고된다.

    if use_single_tcode:
        # ZPP033: 자재 필드가 `ctxtMATNR` 하나뿐(범위/복수 선택 없음) — 진단으로 확인됨.
        matnr_field = _find_by_id_substring(wnd, 'ctxtMATNR')
        if matnr_field is None:
            raise RuntimeError('ZPP033 화면에서 자재번호 입력 필드를 찾지 못했습니다 — 화면 구조가 예상과 다를 수 있습니다(트랜잭션 권한이 없을 가능성도 있음).')
        matnr_field.text = str(mat_list[0])
    elif len(mat_list) > 1:
        multi_btn = _find_by_id_substring(wnd, '%_MATNR_%_APP_%-VALU_PUSH')
        if multi_btn is None:
            raise RuntimeError('ZPP038 화면에서 자재코드 "복수 선택" 버튼을 찾지 못했습니다 — 화면 구조가 예상과 다를 수 있습니다.')
        multi_btn.press()
        time.sleep(0.8)
        try:
            table = session.findById(_SAP_MULTI_SELECT_POPUP_TABLE)  # 같은 SAP 표준 팝업 구조(SAPLALDB) 재사용
        except Exception:
            raise RuntimeError('"자재 복수 선택" 팝업의 입력 표를 찾지 못했습니다.')
        try:
            visible_rows = table.VisibleRowCount or 7
        except Exception:
            visible_rows = 7
        idx = 0
        while idx < len(mat_list):
            if idx > 0:
                try:
                    table.FirstVisibleRow = idx
                    time.sleep(0.3)
                except Exception:
                    pass
            batch = mat_list[idx: idx + visible_rows]
            for row_offset, mat in enumerate(batch):
                cell_id = f"{_SAP_MULTI_SELECT_POPUP_TABLE}/ctxtRSCSEL_255-SLOW_I[1,{row_offset}]"
                try:
                    cell = session.findById(cell_id)
                    cell.text = str(mat)
                except Exception as e:
                    raise RuntimeError(f'"자재 복수 선택" 팝업에 {idx + row_offset + 1}번째 자재("{mat}")를 입력하지 못했습니다: {e}')
            idx += len(batch)
        try:
            session.findById('wnd[1]/tbar[0]/btn[8]').press()  # 확인 — 이 팝업은 한 번만 눌러도 됨(위 주석 참고)
        except Exception as e:
            raise RuntimeError(f'"자재 복수 선택" 팝업을 확인하는 중 오류가 발생했습니다: {e}')
        time.sleep(0.5)
        wnd = session.findById('wnd[0]')
    else:
        matnr_field = _find_by_id_substring(wnd, 'MATNR-LOW')
        if matnr_field is None:
            raise RuntimeError('ZPP038 화면에서 자재번호 입력 필드를 찾지 못했습니다 — 화면 구조가 예상과 다를 수 있습니다(트랜잭션 권한이 없을 가능성도 있음).')
        matnr_field.text = str(mat_list[0])

    # Explosion type(Single/Multi level) — 라이브 진단으로 확인된 정확한 라디오버튼 ID.
    try:
        wnd.findById('usr/radR_2' if explosion == 'multi' else 'usr/radR_1').selected = True
    except Exception:
        pass
    # Option: Show price / Location Information 체크박스.
    try:
        wnd.findById('usr/chkSHOW_P').selected = bool(show_price)
    except Exception:
        pass
    try:
        wnd.findById('usr/chkSHOW_L').selected = bool(show_location)
    except Exception:
        pass

    try:
        session.findById('wnd[0]/tbar[1]/btn[8]').press()  # 실행(F8)
    except Exception as e:
        raise RuntimeError(f'BOM 전개 실행(F8) 중 오류가 발생했습니다: {e}')
    time.sleep(1.5)

    return use_single_tcode


def fetch_bom(materials, plant='1000', use_single_tcode=None, explosion='single',
              show_price=False, show_location=False, layout_variant=None):
    """자재 1개 또는 여러 개의 BOM(ZPP033 단일 또는 ZPP038 복수, "BOM 전개")을 조회해 화면을
    그대로 텍스트로 읽어온다. `materials`는 문자열(단일) 또는 리스트/튜플(복수). 결과 화면을
    "그리드 → 트리 → 필드" 순서로 시도해 읽는다(_sap_dump_screen_body) — ZPP038/ZPP033 둘 다
    "부모-자식 계층" 표시 모드에서 ALV가 트리로 나올 수 있음을 실사용으로 확인했고("BOM
    표준가 부모-자식 계층.vbs"), 트리 덤프(_sap_dump_tree)는 아직 실사용 검증 전이다.
    `use_single_tcode`/`explosion`/`show_price`/`show_location`은 그대로
    `_navigate_to_bom_screen`에 전달 — 2026-09-15 신규(사용자가 실제 ZPP038 화면 캡처로
    "Explosion type"/"Option" 옵션과 단일(ZPP033)/복수(ZPP038) 트랜잭션 분기를 요청)."""
    if not materials:
        raise RuntimeError('자재번호를 지정해주세요.')
    plant = (plant or '1000').strip()

    session = _get_sap_session()
    wnd = session.findById('wnd[0]')
    used_single = _navigate_to_bom_screen(session, wnd, materials, plant,
                                           use_single_tcode=use_single_tcode,
                                           explosion=explosion, show_price=show_price,
                                           show_location=show_location)
    wnd = session.findById('wnd[0]')

    # ⚠️⚠️ [2026-09-16 신규] SAP ID를 팀이 공용으로 쓰다 보니 다른 팀원이 ALV 레이아웃을
    # 바꿔놓으면 이 조회가 매번 다른 컬럼 구성을 읽어올 위험이 있다 — 결과를 읽기 전에
    # 항상 고정 레이아웃으로 강제 전환을 시도한다. ZPP033(단일 자재)에서만 실사용
    # 확인됐고, ZPP038(복수)은 이 레이아웃 자체가 카탈로그에 없어 조용히 건너뛴다
    # (_sap_select_alv_layout 참고 — 실패해도 예외를 던지지 않으므로 이 조회 자체를
    # 막지 않음). 🆕 [2026-09-17 신규, 사용자 요청] 예전엔 `_BOM_LAYOUT_VARIANT`
    # (`/STD_MC`)로 무조건 고정했는데, 팀이 실제로 쓰는 레이아웃 목록(60여 개)을 주며
    # "하드코딩하지 말고 매번 물어봐달라"고 요청 — `layout_variant` 인자가 오면 그걸
    # 우선 쓰고, 안 오면(하위호환) 기존 기본값을 그대로 쓴다.
    layout_variant = layout_variant or _BOM_LAYOUT_VARIANT
    _stage('bom_layout')
    layout_applied, layout_diag = None, ''
    grid_for_layout = _sap_find_grid(wnd)
    if grid_for_layout is not None:
        layout_applied, layout_diag = _sap_select_alv_layout(session, grid_for_layout, layout_variant)
        wnd = session.findById('wnd[0]')  # 레이아웃 적용 후 화면이 다시 그려지므로 참조 갱신

    _stage('bom_dump')
    body, source = _sap_dump_screen_body(wnd)

    mat_label = ', '.join(materials) if isinstance(materials, (list, tuple)) else str(materials)
    tcode_label = 'ZPP033' if used_single else 'ZPP038'

    if not body:
        return {'ok': False, 'error': f'자재 "{mat_label}"의 BOM 화면에서 읽을 수 있는 데이터를 찾지 못했습니다 — 자재번호/플랜트가 올바른지 확인해주세요.'}

    header = f'[SAP BOM 전개({tcode_label}): 자재 {mat_label}, 플랜트 {plant}]\n'
    # 🆕 [2026-09-21, Phase 10] 레이아웃 적용 결과를 결과 텍스트에도 남긴다 — 실패해도 조회는
    #    막지 않지만(기본 화면 레이아웃으로 계속) "왜 선택한 레이아웃이 안 먹는지"가 AI 답변과
    #    이슈 수집(layoutApplied 필드) 양쪽에서 보이도록.
    if layout_applied is True:
        header += f'[레이아웃: "{layout_variant}" 적용됨]\n'
    elif layout_applied is False:
        header += f'[레이아웃: "{layout_variant}" 적용 실패({layout_diag}) — 화면 기본값 사용]\n'
    text = header + '\n' + body
    return {'ok': True, 'source': source, 'materials': materials, 'tcode': tcode_label, 'text': text,
            'layoutApplied': layout_applied, 'layoutRequested': layout_variant, 'layoutDiag': layout_diag}


# ── "사용처 조회(역전개)" (CS15) 전용 헬퍼 ─────────────────────────────
def _navigate_to_where_used_screen(session, wnd, material, plant='1000'):
    """CS15("단일레벨 사용처리스트") — BOM 정전개(ZPP038, 이 자재가 뭘로 구성되는지)의 반대
    방향, 즉 "이 자재가 어느 상위 품목에 쓰이는지"를 조회한다. 2026-09-15 실사용 SAP GUI
    "기록 및 재생" 매크로("BOM 역전개(사용처리스트).vbs")로 얻은 컨트롤을 재현한 것 —
    단, 아래 두 가지는 그 매크로에서 확실하지 않아 주의가 필요하다:
    ⚠️⚠️ **자재번호 입력 필드가 이 매크로에 아예 안 나온다** — 녹화 당시 SAP가 이전 값을
    기억하고 있어서 사람이 따로 입력할 필요가 없었던 것으로 추정된다. 그래서 필드 ID는
    매크로에서 직접 확인된 게 아니라, 같은 화면의 체크박스 필드명(`RC29L-DIRKT`)에서
    구조 접두사(`RC29L`)를 유추해 "MATNR" 문자열이 포함된 컨트롤을 찾는 방식으로
    추측했다 — `_find_all_by_id_substring`으로 후보를 전부 모아 실제 입력 가능한 것부터
    시도(MM03 자재번호 필드 찾기와 같은 방어적 패턴). 이 추측이 틀렸다면 RuntimeError로
    명확히 실패한다(엉뚱한 자재로 조용히 조회되는 것보다 낫다).
    ⚠️⚠️ 매크로에는 실행(F8) 이후 `tbar[1]/btn[45]` 클릭 → SAP 표준 선택 팝업(SAPLSPO5)
    응답 → F4 → 다시 응답 → 뒤로가기 3번이 이어지는데, 이 시퀀스가 매크로에 있던 그대로는
    아니지만(정확한 의도는 여전히 불확실) — 2026-09-15 실사용에서 이와 관련된 진짜 필요한
    부분을 확인했다: 첫 F8 실행 뒤 일부 자재는 "사용처 리스트: 자재: 뷰"라는 중간 화면
    (wnd[0] 자체가 바뀜, wnd[1] 팝업 아님)으로 넘어가는데, 거기서 플랜트(`RC29L-WERKS`)를
    한 번 더 넣고 F8을 다시 눌러야 결과 그리드로 진입한다(아래 코드에서 처리) — 사용자가
    "104446 사용처 조회해줘"를 실행했을 때 결과가 비어 있던 실제 원인이었고, 그 사용자의
    멈춰있는 실제 SAP 세션에 직접 접속해 화면을 덤프하고 라이브로 값을 넣어보며 확정함."""
    session.findById('wnd[0]/tbar[0]/okcd').text = '/nCS15'
    wnd.sendVKey(0)
    time.sleep(0.6)

    candidates = _find_all_by_id_substring(wnd, 'MATNR')
    matnr_field = None
    last_err = None
    for cand in candidates:
        try:
            cand.text = str(material)
            matnr_field = cand
            break
        except Exception as e:
            last_err = e
            continue
    if matnr_field is None:
        raise RuntimeError(f'CS15 화면에서 자재번호 입력 필드를 찾지 못했습니다(마지막 오류: {last_err}) — 이 필드 ID는 실사용 녹화로 직접 확인된 게 아니라 추측한 것이라, 화면 구조가 다르면 실패할 수 있습니다.')

    # 💡 같은 함정(WERKS 문자열이 실제 입력칸 `ctxtWERKS`뿐 아니라 라벨 컨트롤에도 걸림) —
    # `_navigate_to_bom_screen`의 플랜트 필드 수정과 동일한 이유로 `_set_text_on_best_candidate` 사용.
    plant_field = _set_text_on_best_candidate(wnd, 'WERKS', plant)
    # 플랜트 필드가 없어도(매크로에도 없었음) 자재번호만으로 실행을 시도한다.

    dirkt_chk = _find_by_id_substring(wnd, 'RC29L-DIRKT')
    if dirkt_chk is not None:
        try:
            dirkt_chk.selected = True  # "직접 사용처만" — 매크로에서 확인된 설정
        except Exception:
            pass

    try:
        session.findById('wnd[0]/tbar[1]/btn[5]').press()  # 매크로에 있던 클릭 — 정확한 기능은 불명, 그대로 재현
    except Exception:
        pass

    try:
        session.findById('wnd[0]/tbar[1]/btn[8]').press()  # 실행(F8)
    except Exception as e:
        raise RuntimeError(f'CS15 실행(F8) 중 오류가 발생했습니다: {e}')
    time.sleep(1.5)

    # 💡⚠️ [2026-09-15 실사용 진단으로 확정] 위 첫 F8 실행 뒤, 일부 자재는(예: 104446)
    # "사용처 리스트: 자재: 뷰"라는 별도 중간 화면으로 넘어간다 — wnd[1] 팝업이 아니라
    # wnd[0] 자체가 이 화면으로 바뀌는 것이라(GuiTitlebar 확인), 아래의 wnd[1] 방어 코드로는
    # 전혀 안 잡혔다. 플랜트(`usr/ctxtRC29L-WERKS`)/품목 범주(`usr/ctxtRC29L-POSTP`)/용도
    # (`usr/ctxtRC29L-STLAN`)를 다시 묻는 화면인데, 사용자가 캡처해준 화면은 상태바에
    # "자재 104446의 용도에 대한 선택을 하지 않았습니다" 오류가 남아 있었다. 그 실제 멈춰있는
    # 세션에 직접 접속해 진단한 결과, "용도"(STLAN) 자체가 필수인 게 아니라 이 화면에서
    # 플랜트(WERKS)를 한 번 더 넣고 실행(F8, 첫 화면과 같은 `tbar[1]/btn[8]`)하면 그 오류 없이
    # 바로 결과 그리드로 정상 진입하는 것을 확인했다(그 오류 메시지는 플랜트도 용도도 둘 다
    # 비어 있던 이전 시도의 잔여 메시지로 추정). 모든 자재에서 이 중간 화면이 뜨는지는
    # 검증 안 됐으므로, 뜰 때만(=RC29L-WERKS 필드가 존재할 때만) 처리하고 안 뜨면 조용히
    # 건너뛴다(이미 결과 그리드로 넘어간 상태이므로).
    second_werks = _find_by_id_substring(wnd, 'RC29L-WERKS', require_type='GuiCTextField')
    if second_werks is not None:
        try:
            _set_text_on_best_candidate(wnd, 'WERKS', plant)
            session.findById('wnd[0]/tbar[1]/btn[8]').press()
            time.sleep(1.5)
        except Exception:
            pass

    # 방어적 팝업 처리(추측성 — 위 함수 설명 참고). 매크로의 SAPLSPO5 팝업 응답 시퀀스는
    # 재현하지 않고, 팝업이 뜨면 Enter만 시도한다.
    try:
        popup = session.findById('wnd[1]')
        if popup is not None:
            popup.sendVKey(0)
            time.sleep(0.5)
    except Exception:
        pass


def fetch_where_used(materials, plant='1000'):
    """자재 1개 또는 여러 개의 "사용처 리스트"(역전개, CS15)를 조회해 화면을 그대로 텍스트로
    읽어온다. `materials`는 문자열(단일) 또는 리스트/튜플(복수, 2026-09-15 신규).
    ⚠️⚠️ **`fetch_bom`(ZPP038)과 달리 복수 조회를 SAP 표준 "복수 선택" 팝업으로 한 번에
    묶지 않고, 자재마다 CS15를 따로 실행해서 결과를 이어붙인다** — 처음엔 회사 커스텀 배치
    리포트 ZPP046("자재 사용처 일괄조회")을 찾아 그 표준 복수 선택 팝업(S_MATNR)으로
    시도해봤고 실제로 4개 자재 전부 SELECT-OPTIONS에 정상 등록되는 것까지 확인했지만,
    실행 결과 자재 1개(104438)만 나오고 나머지 3개(104481/104477/117451)는 전혀 안 나오는
    문제가 발견됐다 — 원인은 `_sap_dump_grid`의 "응답 크기 보호용 500행 캡"이 **여러 자재가
    섞인 전체 결과 1803행 중 앞쪽 500행**만 잘라내는데, SAP이 자재번호(IDNRK)순으로 정렬해
    반환하다 보니 제일 앞선 자재(104438) 혼자 사용처가 500건을 넘어 그 캡을 다 차지해버려
    뒤에 오는 자재들의 결과가 통째로 잘려나간 것이었다(ZPP038 BOM은 자재 1개당 결과가
    보통 수십 행이라 이 문제가 거의 안 드러남 — 자재당 사용처가 수백 건까지 나올 수 있는
    CS15/ZPP046 특유의 문제). 자재마다 따로 실행하면 각자 500행 캡을 온전히 보장받으므로
    이 방식을 택함 — 대신 자재 수만큼 SAP 화면 전환이 필요해 더 느리다(최대 10개로 제한).
    진단 방법: `py -3-32`로 실제 세션에 접속해 `grid.RowCount`(전체 1803)와 `_sap_dump_grid`
    출력 길이(500행에서 끊김, 끝에 "... (총 1803행 중 500행만 표시)" 문구)를 대조해 확정함."""
    if not materials:
        raise RuntimeError('자재번호를 지정해주세요.')
    plant = (plant or '1000').strip()
    mat_list = list(materials) if isinstance(materials, (list, tuple)) else [materials]
    mat_list = [str(m).strip() for m in mat_list if str(m).strip()][:10]
    if not mat_list:
        raise RuntimeError('자재번호를 지정해주세요.')

    session = _get_sap_session()
    sections = []
    ok_count = 0
    for mat in mat_list:
        try:
            wnd = session.findById('wnd[0]')
            _navigate_to_where_used_screen(session, wnd, mat, plant)
            wnd = session.findById('wnd[0]')
            body, _source = _sap_dump_screen_body(wnd)
            if body:
                sections.append(f'[자재 {mat}]\n{body}')
                ok_count += 1
            else:
                sections.append(f'[자재 {mat}]\n(사용처 데이터를 찾지 못했습니다 — 자재번호가 올바른지, 혹은 이 자재를 사용하는 상위 품목이 실제로 없는지 확인해주세요.)')
        except Exception as e:
            sections.append(f'[자재 {mat}]\n(조회 실패: {e})')

    mat_label = ', '.join(mat_list)
    if ok_count == 0:
        return {'ok': False, 'error': f'자재 "{mat_label}"의 사용처 데이터를 찾지 못했습니다.'}

    header = f'[SAP 사용처 리스트(CS15, 역전개): 자재 {mat_label}]\n'
    text = header + '\n' + '\n\n'.join(sections)
    return {'ok': True, 'source': 'grid', 'materials': mat_list, 'text': text}


def fetch_where_used_batch(materials, plant='1000'):
    """ZPP046("자재 사용처 일괄조회" — 회사 커스텀 배치 리포트)으로 여러 자재의 사용처를
    SAP 서버 쪽에서 한 번에 묶어 조회한다. `fetch_where_used`(자재별 CS15 순차 실행)보다
    SAP 화면 전환이 한 번뿐이라 빠르지만, `_sap_dump_grid`의 "응답 크기 보호용 500행 캡"을
    **여러 자재 결과 전체가 공유**한다 — 사용처가 많은 자재 하나가 캡을 다 차지하면 나머지
    자재 결과가 통째로 잘려나갈 수 있다(2026-09-15 실사용 진단으로 확정된 제약, 자세한 내용은
    `fetch_where_used`의 ZPP046 관련 주석/CLAUDE.md 참고 — 실제로 자재 104438 하나가 500건
    넘는 사용처를 갖고 있어서 나머지 3개가 전부 잘리는 걸 재현·확인함). 그래서 이 함수는
    기본 동작이 아니라, 사용자가 "다중/일괄/복수"라고 명시적으로 말해 이 트레이드오프(빠름 vs
    잘릴 위험)를 감수하겠다는 의사를 밝혔을 때만 `js/04h`에서 호출한다 — 기본값은 여전히
    `fetch_where_used`(안전하지만 느림).
    ⚠️ 복수 선택 팝업(`tblSAPLALDBSINGLE`)의 한 화면 입력 행이 8개까지만 확인됐다(그 이상은
    스크롤이 필요한데 실사용 검증 안 됨, ZDMSR004와 동일한 제약) — 그래서 이 함수를 호출하는
    쪽(`kortek_backend.py`)에서 최대 8개로 자른다."""
    if not materials:
        raise RuntimeError('자재번호를 지정해주세요.')
    plant = (plant or '1000').strip()
    mat_list = list(materials) if isinstance(materials, (list, tuple)) else [materials]
    mat_list = [str(m).strip() for m in mat_list if str(m).strip()]
    if not mat_list:
        raise RuntimeError('자재번호를 지정해주세요.')

    session = _get_sap_session()
    session.StartTransaction('ZPP046')
    time.sleep(0.6)
    wnd = session.findById('wnd[0]')

    try:
        wnd.findById('usr/ctxtP_WERKS').text = plant
    except Exception:
        pass  # 플랜트 필드가 없어도 자재번호만으로 실행을 시도한다.

    if len(mat_list) == 1:
        try:
            wnd.findById('usr/ctxtS_MATNR-LOW').text = mat_list[0]
        except Exception as e:
            raise RuntimeError(f'ZPP046 자재번호 입력 필드를 찾지 못했습니다: {e}')
    else:
        try:
            wnd.findById('usr/btn%_S_MATNR_%_APP_%-VALU_PUSH').press()
            time.sleep(0.8)
            base = 'wnd[1]/usr/tabsTAB_STRIP/tabpSIVA/ssubSCREEN_HEADER:SAPLALDB:3010/tblSAPLALDBSINGLE/ctxtRSCSEL_255-SLOW_I[1,%d]'
            for i, mat in enumerate(mat_list):
                session.findById(base % i).text = mat
            session.findById('wnd[1]/tbar[0]/btn[8]').press()  # 실사용 확인 — ZPP038 BOM과 동일하게 단일 버튼으로 충분
            time.sleep(0.5)
        except Exception as e:
            raise RuntimeError(f'ZPP046 복수 자재 입력 중 오류가 발생했습니다: {e}')

    wnd = session.findById('wnd[0]')
    try:
        wnd.findById('tbar[1]/btn[8]').press()  # 실행(F8)
    except Exception as e:
        raise RuntimeError(f'ZPP046 실행(F8) 중 오류가 발생했습니다: {e}')
    time.sleep(2.0)

    wnd = session.findById('wnd[0]')
    body, source = _sap_dump_screen_body(wnd)
    mat_label = ', '.join(mat_list)
    if not body:
        return {'ok': False, 'error': f'자재 "{mat_label}"의 사용처 데이터를 찾지 못했습니다 — 자재번호/플랜트가 올바른지 확인해주세요.'}

    header = f'[SAP 사용처 일괄조회(ZPP046): 자재 {mat_label}]\n'
    text = header + '\n' + body
    return {'ok': True, 'source': source, 'materials': mat_list, 'text': text}


# 🆕 [2026-09-23 신규, 사용자 요청] "SAP 레이아웃을 사람들이 수시로 바꾸니까 코드가 알아서
# 처리해달라" — 팀이 SAP ID를 공용으로 쓰다 보니 ZMM009의 "자재내역2(KO)"(ZTEXT) 컬럼이
# 어떤 사람 세션엔 보이고 어떤 세션엔 안 보인다(기본 레이아웃엔 숨겨진 컬럼이라 컬럼 표시
# 선택 화면에서 "표시"로 옮겨야만 나오는데, 그 변경이 저장 안 하면 세션이 끝나면 사라짐 —
# 2026-09-23 실사용으로 확인). 매번 "표시로 옮기기" 다이얼로그를 자동 클릭하는 건 그
# 다이얼로그 안의 버튼 2개(▶/◀ 중 뭐가 추가인지) 의미가 라이브 검증 없인 불확실해서
# 만들지 않았다(추측 금지 원칙) — 대신 위 BOM(`_sap_select_alv_layout`)이 이미 라이브
# 검증까지 끝낸 "저장된 레이아웃(변형)을 이름으로 강제 적용" 방식을 그대로 재사용한다.
# **전제조건(사람이 한 번만 하면 됨)**: SAP에서 ZMM009 결과 화면 → 헤더 오른쪽클릭 →
# "표시..." → "자재내역2(KO)"를 표시 열로 옮김 → 💾(레이아웃 저장) → 이름을 정확히
# `_ZMM009_LAYOUT_VARIANT` 값으로 저장. 그 뒤로는 이 함수가 매번 그 이름의 레이아웃을
# 강제 적용해서, 세션이 새로 시작되거나 다른 팀원이 기본 레이아웃을 바꿔도 항상 ZTEXT가
# 보이는 상태로 읽는다. 그 이름의 레이아웃이 아직 없으면(저장 전) 조용히 건너뛰고 지금
# 화면(기본 레이아웃)을 그대로 쓴다 — BOM과 동일한 방어적 설계, 조회 자체를 막지 않음.
_ZMM009_LAYOUT_VARIANT = 'ZTEXT'  # SAP에 이 이름으로 저장된 레이아웃이 있어야 자동 적용됨


def _set_windows_clipboard_text(text):
    """윈도우 클립보드에 텍스트를 넣는다(pywin32의 win32clipboard) — SAP 다중값 선택 팝업의
    Shift+F12(클립보드 붙여넣기)를 자동화하기 위한 용도(2026-09-23, 사용자 지적).
    `win32com.client`처럼 함수 안에서 지연 import(32비트 전용 모듈이라 모듈 최상단에 두면
    64비트 백엔드 쪽 정적 분석/린트에서 불필요한 혼란을 줄 수 있어 기존 스타일을 따름)."""
    import win32clipboard
    win32clipboard.OpenClipboard()
    try:
        win32clipboard.EmptyClipboard()
        win32clipboard.SetClipboardText(text, win32clipboard.CF_UNICODETEXT)
    finally:
        win32clipboard.CloseClipboard()


def _clear_windows_clipboard():
    """클립보드를 비운다 — SAP 붙여넣기 후 클립보드에 내용이 남아있으면 Excel이 파일을
    열 때 '클립보드에 많은 양의 내용이 들어 있습니다' 팝업을 띄우는 문제 방지(2026-09-28)."""
    try:
        import win32clipboard
        win32clipboard.OpenClipboard()
        try:
            win32clipboard.EmptyClipboard()
        finally:
            win32clipboard.CloseClipboard()
    except Exception:
        pass  # 클립보드 정리 실패는 치명적이지 않음 — 조용히 무시


def fetch_zmm009_material_list(materials, storage_location='1000', layout_variant=None):
    """ZMM009("자재 List(복수조회)")로 여러 자재를 한 번에 조회한다 — 2026-09-17, 사용자가
    "SAP에서 자재번호+엑셀 출력해줘"류 요청을 할 때 ZMM009를 기본 경로로 써달라고 요청해서
    추가함. 사용자가 직접 준 SAP GUI "기록 및 재생" 매크로(ZMM009.vbs)에서 그대로 가져온
    정확한 필드 ID·버튼 시퀀스(추측 아님):
    ① `/nZMM009` 진입 → ② `ctxtP_LGORT-LOW`(저장위치, 매크로에서 "1000") 입력 →
    ③ 자재코드 "복수 선택" 버튼(`btn%_P_MATNR_%_APP_%-VALU_PUSH`) → ④ 팝업 입력 표
    (`_SAP_MULTI_SELECT_POPUP_TABLE` — ZDMSR004/ZPP046이 이미 쓰고 있는 것과 **완전히 동일한
    SAP 표준 팝업 구조**임을 이번 매크로의 버튼 시퀀스가 정확히 일치하는 것으로 확인: 아래 ⑤)
    에 자재번호를 채우고 → ⑤ `wnd[1]/tbar[0]/btn[24]` → `wnd[1]/tbar[0]/btn[8]`(순서대로,
    ZDMSR004와 동일) → ⑥ `tbar[1]/btn[8]`(실행/F8). 결과는 특정 트랜잭션 전용 파서를 만들지
    않는다는 이 코드베이스의 기존 설계 원칙대로 `_sap_dump_screen_body`(그리드→트리→필드
    순서로 시도하는 범용 덤프)로 그대로 읽는다.
    ⚠️⚠️ 매크로에는 이 뒤로 결과 그리드의 특정 행(자재 하나)을 더블클릭해 MM03 문서 화면까지
    드릴다운하는 단계가 이어지는데, 그건 이미 별도로 구현된 "ZMM009 리스트에서 바로 문서
    열기" 기능(`_open_material_from_current_list` 등)의 몫이라 여기서는 재현하지 않는다 —
    이 함수는 "여러 자재를 리스트로 조회"하는 부분(매크로의 앞부분)까지만 담당한다.
    🐛 [2026-09-23 실사용 버그수정] "8개 이상 자재를 넣으면 8개만 조회된다"는 실사용 제보로
    확인 — 원래 이 아래 있던 `table.FirstVisibleRow = idx`로 스크롤한 뒤 같은 8칸(visible_rows)
    에 계속 덮어쓰는 방식이었는데, `FirstVisibleRow`가 이 GuiTableControl에서 실제로 스크롤을
    일으키지 않아(그런데 `try/except: pass`로 조용히 삼켜져서 티가 안 났음) 매 배치가 똑같은
    화면 위치에 다시 쓰기만 하고 스크롤은 안 돼서, 마지막 배치(8개)만 남고 나머지는 덮어써
    사라진 것이었다. **사용자 지적대로 Shift+F12(클립보드에서 붙여넣기)로 교체** — SAP가
    내부적으로 스크롤까지 알아서 처리해서, 몇 개를 넣든(팝업 한 화면에 보이는 행 수와 무관)
    안전하다. `_set_windows_clipboard_text`(win32clipboard) 참고."""
    session = _get_sap_session()
    wnd = session.findById('wnd[0]')
    mat_list = list(materials) if isinstance(materials, (list, tuple)) else [materials]
    mat_list = [str(m).strip() for m in mat_list if str(m).strip()]
    if not mat_list:
        raise RuntimeError('자재번호를 지정해주세요.')
    storage_location = (storage_location or '1000').strip()

    session.findById('wnd[0]/tbar[0]/okcd').text = '/nZMM009'
    wnd.sendVKey(0)
    time.sleep(0.8)
    wnd = session.findById('wnd[0]')

    loc_field = _set_text_on_best_candidate(wnd, 'P_LGORT-LOW', storage_location)
    if loc_field is None:
        raise RuntimeError('ZMM009 화면에서 저장위치 입력 필드(P_LGORT)를 찾지 못했습니다 — 화면 구조가 예상과 다를 수 있습니다.')

    multi_btn = _find_by_id_substring(wnd, '%_P_MATNR_%_APP_%-VALU_PUSH')
    if multi_btn is None:
        raise RuntimeError('ZMM009 화면에서 "자재코드 복수 선택" 버튼을 찾지 못했습니다.')
    multi_btn.press()
    time.sleep(0.8)

    try:
        table = session.findById(_SAP_MULTI_SELECT_POPUP_TABLE)
    except Exception:
        raise RuntimeError('"자재코드 복수 선택" 팝업의 입력 표를 찾지 못했습니다.')
    # 사용자 지적대로 Shift+F12(클립보드 붙여넣기)로 채운다 — 몇 줄이든 SAP가 알아서 스크롤하며
    # 다 채워주므로, 팝업 한 화면에 보이는 행 수(visible_rows)에 갇히지 않는다.
    try:
        _set_windows_clipboard_text('\r\n'.join(mat_list))
    except Exception as e:
        raise RuntimeError(f'자재번호 목록을 클립보드에 넣지 못했습니다: {e}')
    try:
        table.SetFocus()
        session.findById('wnd[1]').sendVKey(24)  # Shift+F12 = 클립보드에서 붙여넣기
    except Exception as e:
        raise RuntimeError(f'"자재코드 복수 선택" 팝업에 클립보드 붙여넣기(Shift+F12)를 실행하지 못했습니다: {e}')
    time.sleep(0.5 + 0.05 * len(mat_list))  # 자재 수가 많으면 SAP가 표를 채우는 데도 시간이 더 걸림
    _clear_windows_clipboard()  # 붙여넣기 후 클립보드 비움 — 나중에 Excel이 열릴 때 팝업 방지

    try:
        session.findById('wnd[1]/tbar[0]/btn[24]').press()
        time.sleep(0.3)
        session.findById('wnd[1]/tbar[0]/btn[8]').press()
    except Exception as e:
        raise RuntimeError(f'"자재코드 복수 선택" 팝업을 확인하는 중 오류가 발생했습니다: {e}')
    time.sleep(0.8)

    wnd = session.findById('wnd[0]')
    try:
        wnd.findById('tbar[1]/btn[8]').press()  # 실행(F8)
    except Exception as e:
        raise RuntimeError(f'ZMM009 실행(F8) 중 오류가 발생했습니다: {e}')
    time.sleep(1.5)

    wnd = session.findById('wnd[0]')
    layout_variant = layout_variant or _ZMM009_LAYOUT_VARIANT
    grid_for_layout = _sap_find_grid(wnd)
    if grid_for_layout is not None:
        _sap_select_alv_layout(session, grid_for_layout, layout_variant)  # 실패해도 조용히 무시 — 위 상수 선언부 주석 참고
        wnd = session.findById('wnd[0]')  # 레이아웃 적용 후 화면이 다시 그려지므로 참조 갱신

    body, source = _sap_dump_screen_body(wnd)
    mat_label = ', '.join(mat_list)
    if not body:
        # 🐛 [2026-09-22 버그수정, 실사용 이슈 리포트로 확인] 결과가 없으면 SAP이 "정보" 팝업(wnd[1])에
        #    실제 사유(예: 그 저장위치엔 이 자재 마스터가 없음)를 담아 띄우는데, 기존 코드는 wnd[0]만
        #    읽어서 이 팝업을 읽지도 닫지도 않았다 — 그래서 ① 사용자는 진짜 사유를 모른 채 뭉뚱그린
        #    안내만 받고 ② 팝업이 열린 채로 남아 다음 조회 시도까지 씹히는 2차 문제가 있었다(이슈
        #    리포트가 "③ 코드: 팝업 잔존 처리"로 정확히 짚어낸 사례 — docs/phase10-issue-learning-design.md).
        popup_msg = ''
        try:
            if int(session.Children.Count) > 1:
                for fid in ('wnd[1]/usr/txtMESSTXT1', 'wnd[1]/usr/txtMESSTXT2', 'wnd[1]/usr/txtIK1'):
                    try:
                        txt = (session.findById(fid).Text or '').strip()
                        if txt and txt not in popup_msg:
                            popup_msg = (popup_msg + ' ' + txt).strip()
                    except Exception:
                        pass
        except Exception:
            pass
        _sap_close_stray_popups(session)   # 팝업을 남겨두면 다음 조회 시도가 여기 막힌다 — 항상 정리하고 반환
        reason = f' SAP 안내: "{popup_msg}"' if popup_msg else ''
        return {'ok': False, 'error': f'자재 "{mat_label}"의 조회 결과를 찾지 못했습니다 — 자재번호/저장위치가 올바른지 확인해주세요.{reason}'}

    header = f'[SAP 자재 List(ZMM009): 자재 {mat_label}]\n'
    text = header + '\n' + body
    return {'ok': True, 'source': source, 'materials': mat_list, 'text': text}


# ── "승인원 표지 생성" 전용 헬퍼 ────────────────────────────────────────
# 💡 [2026-09-15 신규] 사용자가 회사에서 쓰던 별도 데스크톱 앱("연구소 가이드 시스템",
# PyInstaller로 배포된 Python/Tkinter 앱)의 exe를 주고 "이 기능을 AI 문답에도 추가해달라"고
# 요청해서, 그 exe를 pyinstxtractor-ng로 풀고 main.pyc를 marshal로 읽어 바이트코드/상수를
# 분석해서(디컴파일러가 Python 3.13을 지원 안 해서 완전한 소스 복원은 안 됐지만, 함수
# docstring·상수 풀·바이트코드 흐름만으로 로직을 충분히 재구성함) 그 앱의 "승인원 표지 생성"
# 기능(GuiApp._approval_* 메서드들)을 그대로 재현한 것. 아래 로직은 원본 앱의 실제 동작과
# 최대한 동일하게 맞췄다 — 필드 ID(`wnd[0]/usr/ctxtRMMG1-MATNR`)·VKey(30)·탭 ID
# (`tabpZU05`)·소트박스 타입 목록(`_APV_VALUE_TYPES`)까지 전부 원본 바이트코드에서 그대로
# 확인한 값이다.
_APV_VALUE_TYPES = ('GuiTextField', 'GuiCTextField', 'GuiComboBox', 'GuiTextEdit')


def _approval_find_value(root, needles):
    """화면을 훑어서 needles 중 하나가 ID에 들어간 '입력칸'을 찾아 값을 돌려준다(원본 앱의
    `_approval_find_value`를 그대로 재현). 요소 ID 전체 경로를 코드에 박지 않는 이유: SAP
    화면이 회사마다 커스터마이징되어 있어 경로가 제각각이고, 화면이 바뀌어도 필드 이름
    (MAKTX, MATKL 등)만 그대로면 계속 동작하게 하려는 것 — needles는 앞에 올수록 우선순위가
    높다(예: 'MARA-MATKL'을 먼저 찾고, 없으면 'MATKL'로 넓혀서 찾는다)."""
    hits = {}

    def walk(obj, depth=0):
        if depth > 14:
            return
        try:
            otype = obj.Type
            oid = obj.Id
        except Exception:
            return
        if otype in _APV_VALUE_TYPES:
            up = (oid or '').upper()
            for n in needles:
                if n.upper() in up and n not in hits:
                    try:
                        hits[n] = (obj.Text or '').strip()
                    except Exception:
                        pass
        try:
            cnt = obj.Children.Count
        except Exception:
            return
        for i in range(cnt):
            try:
                walk(obj.Children.Item(i), depth + 1)
            except Exception:
                continue

    walk(root)
    for n in needles:
        if n in hits:
            return hits[n]
    return ''


def _approval_read_long_text(session):
    """'기본 데이터 텍스트' 탭(tabpZU05)의 여러 줄 설명(Sub-Description)을 읽는다. 화면
    전체를 뒤지면 상단 툴바 같은 엉뚱한 Shell을 잡아서 'SAP.Toolbar.1' 같은 값이 나올 수
    있어(원본 앱 주석 그대로), `wnd[0]/usr` 안쪽만 훑고 Id가 'SAP.'로 시작하는 툴바류는
    걸러낸다."""
    try:
        usr = session.findById('wnd[0]/usr')
    except Exception:
        return ''
    shell = _sap_find_shell_any(usr)
    if shell is None:
        return ''
    try:
        if (shell.Id or '').startswith('SAP.'):
            return ''
    except Exception:
        pass
    try:
        return (shell.Text or '').strip()
    except Exception:
        return ''


def _approval_read_one_material(session, wnd, material):
    """자재 하나의 승인원 표지 정보를 SAP에서 읽어온다(원본 앱 `_approval_read_one` 재현).
    반환: {'code','ok','desc','sub','matkl','sap_group','err'}."""
    out = {'code': material, 'ok': False, 'desc': '', 'sub': '', 'matkl': '', 'sap_group': '', 'err': ''}
    try:
        try:
            session.StartTransaction('MM03')
        except Exception:
            # StartTransaction이 없는 구버전 SAP GUI 대비 폴백(이 프로젝트의 기존 방식).
            session.findById('wnd[0]/tbar[0]/okcd').text = '/nMM03'
            wnd.sendVKey(0)
        time.sleep(0.6)

        candidates = _find_all_by_id_substring(wnd, 'RMMG1-MATNR')
        matnr_field = None
        for cand in candidates:
            try:
                cand.text = str(material)
                matnr_field = cand
                break
            except Exception:
                continue
        if matnr_field is None:
            out['err'] = '자재번호 입력 필드를 찾지 못했습니다.'
            return out
        wnd.sendVKey(0)
        time.sleep(1.0)

        # 뷰 선택 팝업 등 방어적 처리(추측성 — MM03 직접조회 경로와 동일 패턴).
        try:
            popup = session.findById('wnd[1]')
            if popup is not None:
                popup.sendVKey(0)
                time.sleep(0.6)
        except Exception:
            pass

        try:
            sbar = session.findById('wnd[0]/sbar')
            if getattr(sbar, 'MessageType', '') in ('E', 'A'):
                out['err'] = (sbar.Text or '자재를 찾을 수 없습니다.').strip() or '자재를 찾을 수 없습니다.'
                return out
        except Exception:
            pass

        usr = session.findById('wnd[0]/usr')
        out['desc'] = _approval_find_value(usr, ['MAKT-MAKTX', 'MAKTX'])
        out['matkl'] = _approval_find_value(usr, ['MARA-MATKL', 'MATKL'])
        out['sap_group'] = _approval_find_value(usr, ['T023T-WGBEZ', 'WGBEZ'])

        wnd.sendVKey(30)  # 원본 앱이 쓰는 정확한 VKey — "추가 데이터" 화면을 버튼 클릭 없이 곧장 연다.
        time.sleep(0.9)
        _select_tab_if_present(wnd, 'tabpZU05')  # "기본 데이터 텍스트" 탭(tabpZU04 "문서 데이터"와는 다름)
        time.sleep(0.8)
        out['sub'] = _approval_read_long_text(session)

        out['ok'] = True
        return out
    except Exception as e:
        out['err'] = f'자재 조회 실패 ({e})'
        return out


def fetch_approval_info(materials):
    """여러 자재의 승인원 표지 정보를 SAP에서 순서대로 읽어온다. materials는 자재번호
    문자열 리스트(최대 30개 — 원본 앱과 동일한 상한)."""
    materials = [str(m).strip() for m in (materials or []) if str(m).strip()][:30]
    if not materials:
        raise RuntimeError('자재번호를 지정해주세요.')

    session = _get_sap_session()
    wnd = session.findById('wnd[0]')

    results = []
    for material in materials:
        results.append(_approval_read_one_material(session, wnd, material))
    return {'ok': True, 'results': results}


def fetch_vendor_by_stcd2(stcd2):
    """ZMM005(공급업체 리스트)에서 사업자등록번호(STCD2)로 협력사를 조회해 반환한다.
    결과 ALV 컬럼은 동적으로 읽으며, NAME1(업체명)·LIFNR(코드)·STCD2(사번)를 우선 추출.
    회사코드는 기본값 1000을 사용(선택화면에 이미 채워져 있음).
    2026-09-29 신규 — 덤프 기반 구현(필드ID: S_STCD2-LOW=GuiTextField, F8=tbar[1]/btn[8])."""
    stcd2 = str(stcd2).strip().replace('-', '')  # 하이픈 제거
    if not stcd2:
        raise RuntimeError('사업자등록번호를 입력해주세요.')

    session = _get_sap_session()
    # ZMM005 선택 화면으로 이동
    session.findById('wnd[0]/tbar[0]/okcd').Text = '/nZMM005'
    session.findById('wnd[0]').sendVKey(0)
    time.sleep(1.0)

    wnd = session.findById('wnd[0]')
    # S_STCD2-LOW는 GuiTextField (덤프 확인 — GuiCTextField가 아님)
    wnd.findById('usr/txtS_STCD2-LOW').Text = stcd2
    # 회사코드 1000이 기본으로 채워져 있으니 건드리지 않음

    # F8 실행
    wnd.findById('tbar[1]/btn[8]').press()
    time.sleep(1.5)

    wnd = session.findById('wnd[0]')
    grid = _sap_find_grid(wnd)
    if grid is None:
        # 결과 화면에서 그리드를 못 찾으면 fields 덤프로 오류 확인
        body, _ = _sap_dump_screen_body(wnd)
        raise RuntimeError(f'ZMM005 결과 그리드를 찾을 수 없습니다. 화면: {(body or "")[:200]}')

    total_rows = grid.RowCount
    if total_rows == 0:
        return {'ok': True, 'rows': [], 'message': f'사업자번호 {stcd2}로 조회된 업체가 없습니다.'}

    col_ids = list(grid.ColumnOrder)
    rows = []
    for r in range(min(total_rows, 50)):
        row = {}
        for cid in col_ids:
            try:
                row[cid] = str(grid.GetCellValue(r, cid))
            except Exception:
                row[cid] = ''
        rows.append(row)

    # NAME1(업체명) 컬럼 자동 탐색 — 대소문자 무관
    name_col = next((c for c in col_ids if c.upper() in ('NAME1', 'NAME')), None)
    lifnr_col = next((c for c in col_ids if c.upper() == 'LIFNR'), None)
    stcd2_col = next((c for c in col_ids if 'STCD' in c.upper()), None)

    # 결과를 간결한 형태로 정리
    vendors = []
    for row in rows:
        v = {
            'lifnr': (row.get(lifnr_col, '') if lifnr_col else '').strip(),
            'name':  (row.get(name_col, '')  if name_col  else '').strip(),
            'stcd2': (row.get(stcd2_col, '') if stcd2_col else '').strip(),
        }
        if v['lifnr'] or v['name']:
            vendors.append(v)

    return {
        'ok': True, 'vendors': vendors, 'total': total_rows,
        'cols': col_ids,  # 디버깅용
    }


def fetch_lifnr_from_zmm006(material):
    """ZMM006(자재별 공급업체 조회)에서 자재번호로 공급업체 코드(LIFNR 6자리)를 반환한다.
    2026-09-29 — VBS 기반(ctxtS_MATNR-LOW = GuiCTextField, F8 실행 후 ALV 첫 행 LIFNR 컬럼)."""
    material = str(material).strip()
    if not material:
        return None
    session = _get_sap_session()
    session.findById('wnd[0]/tbar[0]/okcd').Text = '/nZMM006'
    session.findById('wnd[0]').sendVKey(0)
    time.sleep(1.0)

    wnd = session.findById('wnd[0]')
    try:
        wnd.findById('usr/ctxtS_MATNR-LOW').Text = material
    except Exception as e:
        raise RuntimeError(f'ZMM006 자재번호 입력 필드를 찾지 못했습니다: {e}')
    wnd.findById('tbar[1]/btn[8]').press()
    time.sleep(1.5)

    wnd = session.findById('wnd[0]')
    grid = _sap_find_grid(wnd)
    if grid is None or grid.RowCount == 0:
        return None

    col_ids = list(grid.ColumnOrder)
    lifnr_col = next((c for c in col_ids if c.upper() == 'LIFNR'), None)
    if not lifnr_col:
        return None
    return str(grid.GetCellValue(0, lifnr_col)).strip() or None


def fetch_vendor_by_lifnr(lifnr):
    """ZMM005(공급업체 리스트)에서 LIFNR(공급업체 코드)로 협력사 상세 정보를 반환한다.
    2026-09-29 — 결과 ALV 덤프 기반(ctxtS_LIFNR-LOW = GuiCTextField, 결과 grid = wnd[0]/shellcont/shell).
    반환: {'lifnr', 'name', 'address'(ORT01+STRAS), 'tel'(TELF1), 'representative'(J_1KFREPRE)}"""
    lifnr = str(lifnr).strip()
    if not lifnr:
        return None
    session = _get_sap_session()
    session.findById('wnd[0]/tbar[0]/okcd').Text = '/nZMM005'
    session.findById('wnd[0]').sendVKey(0)
    time.sleep(1.0)

    wnd = session.findById('wnd[0]')
    try:
        wnd.findById('usr/ctxtS_LIFNR-LOW').Text = lifnr
    except Exception as e:
        raise RuntimeError(f'ZMM005 LIFNR 입력 필드를 찾지 못했습니다: {e}')
    wnd.findById('tbar[1]/btn[8]').press()
    time.sleep(1.5)

    wnd = session.findById('wnd[0]')
    grid = _sap_find_grid(wnd)
    if grid is None or grid.RowCount == 0:
        return None

    col_ids = list(grid.ColumnOrder)

    def _get(col_names, row=0):
        for n in col_names:
            col = next((c for c in col_ids if c.upper() == n.upper()), None)
            if col:
                val = str(grid.GetCellValue(row, col)).strip()
                if val:
                    return val
        return ''

    city   = _get(['ORT01'])
    street = _get(['STRAS'])
    address = (city + ' ' + street).strip()
    return {
        'lifnr':          lifnr,
        'name':           _get(['NAME1', 'NAME']),
        'address':        address,
        'tel':            _get(['TELF1', 'TEL_NUMBER']),
        'representative': _get(['J_1KFREPRE']),
        'stcd2':          _get(['STCD2']),
        'email':          _get(['SMTP_ADDR', 'SMTP']),
    }


def fetch_lifnr_from_mm03(material):
    """MM03 구매 탭(SP09) MARA-ZLIFNR 필드에서 공급사코드를 읽어 반환한다.
    ZMM006보다 안정적 — 구매 이력 없어도 자재마스터에 등록된 공급사코드를 그대로 반환.
    2026-09-29, 화면 덤프(132995 구매탭)로 MARA-ZLIFNR(GuiTextField) 확인.
    반환: LIFNR 문자열 또는 None."""
    material = str(material).strip()
    if not material:
        return None
    session = _get_sap_session()
    wnd = session.findById('wnd[0]')
    _navigate_to_material_screen(session, wnd, material)
    wnd = session.findById('wnd[0]')

    # 구매 탭(SP09) 선택 — _select_tab_with_retry는 ID substring으로 재시도
    found = _select_tab_with_retry(wnd, 'tabpSP09')
    if not found:
        return None
    time.sleep(0.4)
    wnd = session.findById('wnd[0]')

    # MARA-ZLIFNR 읽기 — 'txt' 접두사로 라벨(lblMARA-ZLIFNR, text="공급사코드")이 아닌
    # 값 필드(txtMARA-ZLIFNR, text="100503")를 명시적으로 찾는다.
    try:
        lifnr_field = _find_by_id_substring(wnd, 'txtMARA-ZLIFNR')
        if lifnr_field is None:
            return None
        return lifnr_field.Text.strip() or None
    except Exception:
        return None


def fetch_vendor_info_by_material(material):
    """MM03 구매탭→LIFNR→ZMM005 순서로 자재의 협력사 상세 정보를 조회한다.
    2026-09-29: ZMM006 대신 MM03 구매탭(MARA-ZLIFNR)으로 변경 — 구매이력 없는 자재도 조회 가능.
    반환: {'ok': True, 'vendor': {...}} 또는 {'ok': False, 'error': ...}"""
    material = str(material).strip()
    lifnr = fetch_lifnr_from_mm03(material)
    if not lifnr:
        return {'ok': False, 'error': f'MM03 구매 탭에서 자재 {material}의 공급사코드(MARA-ZLIFNR)를 찾지 못했습니다.'}
    vendor = fetch_vendor_by_lifnr(lifnr)
    if not vendor:
        return {'ok': False, 'error': f'ZMM005에서 LIFNR {lifnr}의 공급업체 정보를 찾지 못했습니다.'}
    return {'ok': True, 'vendor': vendor}


# ── "문서 열기" (open_document) 전용 헬퍼 ─────────────────────────────
def _find_by_id_substring(container, substring, depth=0, max_depth=30, require_type=None):
    """창 트리를 재귀 탐색해 .Id에 특정 문자열이 포함된 첫 번째 컨트롤을 찾는다.
    절대경로(예: .../subSUB2:SAPLZ38MM_MATERIAL:3400/...)는 자재 유형에 따라 서브구조
    번호가 달라질 수 있어 깨지기 쉽다 — 대신 "그 컨트롤 고유의 기술 이름"만 알면 화면
    어디에 있든 찾아내는 이 방식이 더 안정적이다(2026-09-14, 실사용 녹화로 얻은 정확한
    ID의 마지막 구성요소만 잘라서 검색어로 사용).
    💡 [2026-09-14] "원본" 트리 컨트롤을 찾을 때, 같은 이름을 포함한 바깥쪽 컨테이너
    (예: GuiCustomControl `cntlCTL_FILES2`)가 실제 기능이 있는 안쪽 GuiShell보다 먼저
    걸려서 잘못 반환되는 문제가 실사용 테스트로 확인됨 — require_type='GuiShell'처럼
    타입까지 맞아야만 반환하도록 해서 이 문제를 막는다(다른 호출부는 기존과 동일하게
    타입 무관하게 첫 매치를 반환)."""
    try:
        cid = container.Id or ''
        type_ok = (require_type is None) or (getattr(container, 'Type', None) == require_type)
        if substring in cid and type_ok:
            return container
    except Exception:
        pass
    if depth > max_depth:
        return None
    try:
        children = container.Children
    except Exception:
        return None
    if children is None:
        return None
    for i in range(children.Count):
        try:
            child = children.Item(i)
        except Exception:
            continue
        found = _find_by_id_substring(child, substring, depth + 1, max_depth, require_type)
        if found is not None:
            return found
    return None


def _find_all_by_id_substring(container, substring, depth=0, max_depth=30, results=None):
    """`_find_by_id_substring`과 달리 첫 매치에서 멈추지 않고 .Id에 substring이 포함된
    모든 컨트롤을 순서대로 모아 반환한다. 같은 ID 문자열이 실제 입력 필드가 아닌 다른
    컨트롤(매치코드/히스토리 아이콘 등)에도 들어있어 첫 매치가 틀릴 수 있는 경우, 호출부가
    "찾은 것들을 순서대로 하나씩 시도"할 수 있게 하기 위한 용도(2026-09-15 신규 —
    자재번호 필드 자동 입력 중 첫 매치가 .text를 설정할 수 없는 컨트롤이라 COM 오류
    "Property 'Item.text' can not be set."가 난 문제를 방어하려고 추가)."""
    if results is None:
        results = []
    try:
        cid = container.Id or ''
        if substring in cid:
            results.append(container)
    except Exception:
        pass
    if depth > max_depth:
        return results
    try:
        children = container.Children
    except Exception:
        return results
    if children is None:
        return results
    for i in range(children.Count):
        try:
            child = children.Item(i)
        except Exception:
            continue
        _find_all_by_id_substring(child, substring, depth + 1, max_depth, results)
    return results


def _set_text_on_best_candidate(wnd, substring, value, prefer_types=('GuiCTextField', 'GuiTextField')):
    """`_find_all_by_id_substring`로 후보를 전부 모아, `prefer_types` 순서로 우선 정렬한 뒤
    실제로 `.text` 대입이 되는 첫 번째 후보를 찾아 값을 넣는다(2026-09-15 신규 — 실사용
    진단으로 확정된 함정: SAP 선택화면은 입력 필드 ID 옆에 "라벨" 역할을 하는 컴패니언
    컨트롤(예: `txt%_WERKS_%_APP_%-TEXT`, 실제 입력칸 `ctxtWERKS`와 별개)을 같은 ID
    문자열로 만들어두는 경우가 흔하다 — 첫 매치(보통 이 라벨)에 값을 넣으면 예외 없이
    "성공"하지만 실제 입력칸은 계속 비어 있어, 이후 실행(F8)이 "필수 입력 필드가 비어
    있다"는 SAP 오류로 조용히 막히는 버그가 실사용에서 확인됨(ZPP038 BOM 조회의 플랜트
    필드) — MM03 자재번호 필드에서 먼저 겪었던 것과 같은 종류의 함정이라 그 해결 패턴
    (`_navigate_to_material_document_tab`)을 공용 헬퍼로 뽑아 재사용한다. 성공하면 실제로
    값을 넣은 컨트롤을, 후보가 없거나 전부 실패하면 None을 반환한다."""
    candidates = _find_all_by_id_substring(wnd, substring)
    if not candidates:
        return None

    def sort_key(c):
        try:
            t = c.Type
        except Exception:
            t = None
        return prefer_types.index(t) if t in prefer_types else len(prefer_types)

    candidates.sort(key=sort_key)
    for cand in candidates:
        try:
            cand.text = str(value)
            return cand
        except Exception:
            continue
    return None


def _select_tab_if_present(wnd, id_substring):
    tab = _find_by_id_substring(wnd, id_substring)
    if tab is not None:
        try:
            tab.select()
        except Exception:
            pass


def _select_tab_with_retry(wnd, id_substring, attempts=6, delay=0.5):
    """`_select_tab_if_present`의 재시도 버전. 2026-09-15 신규 — 자재번호를 직접 입력해 MM03을
    처음부터 여는 경로(`_navigate_to_material_document_tab`)는 "이미 열려 있는 화면"을
    전제하던 기존 `_select_tab_if_present`와 달리 화면이 아직 다 그려지지 않았을 수 있어
    짧게 여러 번 재시도한다. 그래도 끝내 못 찾으면 False를 반환하는데, 이 경우는 "타이밍
    문제"가 아니라 그 자재에 저장된 "뷰 선택(Select View(s))" 이력에 해당 뷰 자체가 없어서
    탭이 애초에 화면에 존재하지 않는 것일 가능성이 있다(실사용 테스트로 확인 — 자재
    106188은 "문서 데이터" 탭 없이 "기본 데이터" 탭으로만 열렸음). 호출부가 True/False를
    보고 구체적인 안내 메시지를 낼 수 있도록 `_select_tab_if_present`(무조건 조용히 통과)와
    분리했다."""
    for _attempt in range(attempts):
        tab = _find_by_id_substring(wnd, id_substring)
        if tab is not None:
            try:
                tab.select()
            except Exception:
                pass
            return True
        time.sleep(delay)
    return False


def _table_find_cell_by_exact_row_text(table, target_text):
    """GuiTableControl에 지금 화면에 렌더링된 셀들(GuiTableControl.Children)을 훑어서,
    텍스트가 target_text와 정확히 일치하는 셀을 찾는다. 컬럼의 정확한 필드명(DRAT-DOKAR
    등)을 몰라도 동작하도록 모든 셀을 다 검사 — "Ty." 컬럼이 몇 번째인지 몰라도 된다."""
    try:
        children = table.Children
    except Exception:
        return None
    if children is None:
        return None
    for i in range(children.Count):
        try:
            child = children.Item(i)
            text = (child.Text or '').strip()
        except Exception:
            continue
        if text.upper() == target_text.upper():
            return child
    return None


def _find_material_row_in_grid(grid, material):
    """현재 화면의 ALV 그리드(GuiShell/GridView, 예: ZMM009 "자재 List" 결과)에서 "자재"라는
    제목의 컬럼을 찾아, 지정한 material과 정확히 일치하는 행 번호를 찾는다(2026-09-15 신규).
    특정 트랜잭션의 내부 필드명(MATNR 등) 대신 화면에 보이는 컬럼 제목으로 찾아서, ZMM009뿐
    아니라 "자재"라는 컬럼이 있는 다른 다중조회 화면에도 재사용 가능하게 했다 — 기존
    `_sap_dump_grid`가 컬럼 제목을 읽는 것과 같은 패턴. 못 찾으면 (None, None)."""
    try:
        col_ids = list(grid.ColumnOrder)
    except Exception:
        return None, None
    matnr_col = None
    for cid in col_ids:
        try:
            title = (grid.GetColumnTitle(cid) or '').strip()
        except Exception:
            title = ''
        if title in ('자재', 'Material'):
            matnr_col = cid
            break
    if matnr_col is None:
        return None, None
    try:
        total_rows = grid.RowCount
    except Exception:
        return None, None
    target = str(material).strip().upper()
    for r in range(total_rows):
        try:
            val = str(grid.GetCellValue(r, matnr_col)).strip().upper()
        except Exception:
            continue
        if val == target:
            return r, matnr_col
    return None, None


def _open_material_from_current_list(wnd, material):
    """지금 화면에 이미 떠 있는 자재 목록 ALV 그리드(ZMM009 "자재 List" 등)에서 지정한
    자재번호 행을 찾아 그 "자재" 셀을 더블클릭해서 그 자재의 MM03 조회 화면으로
    drill-down한다(2026-09-15 신규 — 실사용 화면 녹화로 확인: ZMM009 결과 그리드의 "자재"
    컬럼 값을 더블클릭하면 바로 "자재 NNN 조회(원자재)" 화면으로 이동하고, 그 뒤부터는
    자재번호를 직접 입력해 MM03을 새로 여는 경로와 완전히 동일한 화면이 이어진다). 이미
    여러 자재를 조회해둔 화면을 재사용하므로 `/nMM03`을 매번 새로 여는 것보다 빠르다.
    성공하면 True, 이 화면에 그리드가 없거나 그 자재를 못 찾으면 False를 반환(호출부가
    `/nMM03`을 새로 여는 경로로 폴백할 수 있게 하기 위함 — 이 화면이 ZMM009 리스트가
    아니어도(예: MM03을 막 새로 연 직후) 안전하게 실패하고 넘어간다)."""
    grid = _sap_find_grid(wnd)
    if grid is None:
        return False
    row, col = _find_material_row_in_grid(grid, material)
    if row is None:
        return False
    try:
        grid.doubleClickCell(row, col)
        time.sleep(1.0)
    except Exception:
        return False
    return True


def _is_material_already_open(wnd, material):
    """현재 화면이 이미 MM03에서 해당 자재를 열어둔 탭 화면인지 확인한다.
    RMMG1-MATNR 필드 값이 요청 자재번호와 일치하면 True — 탭만 전환하면 되므로 재진입 불필요.
    /nMM03 재진입 시 "뷰 선택" 팝업이 뜨면 SAP가 차단되는 문제 방지(2026-10-01)."""
    try:
        field = _find_by_id_substring(wnd, 'RMMG1-MATNR')
        if field is None:
            return False
        current = str(field.Text).strip().lstrip('0')
        target = str(material).strip().lstrip('0')
        return current == target and current != ''
    except Exception:
        return False


def _navigate_to_material_screen(session, wnd, material):
    """MM03으로 이동해 지정한 자재번호를 조회한다(탭 선택은 호출부 몫) — 아래
    `_navigate_to_material_document_tab`의 "자재 열기" 부분만 떼어낸 공용 함수(2026-09-23,
    `fetch_material_price`에도 똑같은 열기 로직이 필요해서 분리했다). 나머지 동작·이유는
    그 함수 docstring 그대로."""
    # ⚡ [2026-10-01] 이미 그 자재의 MM03 탭 화면이면 탭 전환만 하면 됨 — /nMM03 재진입 시
    # "뷰 선택" 팝업이 뜨면 SAP 화면이 차단되어 35초 타임아웃으로 실패하던 문제 방지
    if _is_material_already_open(wnd, material):
        return

    if not _open_material_from_current_list(wnd, material):
        session.findById('wnd[0]/tbar[0]/okcd').text = '/nMM03'
        wnd.sendVKey(0)
        time.sleep(0.6)

        candidates = _find_all_by_id_substring(wnd, 'RMMG1-MATNR')
        if not candidates:
            raise RuntimeError('MM03 자재번호 입력 필드를 찾지 못했습니다 — SAP GUI가 예상과 다른 화면(예: 이미 다른 트랜잭션 진행 중)일 수 있습니다.')
        candidates.sort(key=lambda c: 0 if getattr(c, 'Type', None) == 'GuiCTextField' else 1)
        matnr_field = None
        last_err = None
        for cand in candidates:
            try:
                cand.text = str(material)
                matnr_field = cand
                break
            except Exception as e:
                last_err = e
                continue
        if matnr_field is None:
            raise RuntimeError(f'MM03 자재번호 입력 필드를 찾았지만 값을 설정하지 못했습니다. (마지막 오류: {last_err})')
        wnd.sendVKey(0)
        time.sleep(0.8)

        # 방어적 팝업 처리(추측성 — _navigate_to_material_document_tab 원래 주석 참고).
        try:
            popup = session.findById('wnd[1]')
            if popup is not None:
                popup.sendVKey(0)
                time.sleep(0.5)
        except Exception:
            pass


def _navigate_to_material_document_tab(session, wnd, material):
    """MM03으로 이동해 지정한 자재번호를 조회하고 "문서 데이터"(tabpZU04) 탭까지 연다.
    2026-09-15 실사용 화면 녹화(SAP Easy Access 메인 메뉴에서 시작 → 명령창에 MM03 입력 →
    자재번호 입력 → Enter → 기본 데이터 탭 → "문서 데이터" 탭 선택)로 얻은 정확한 컨트롤을
    일반화한 것 — `ctxtRMMG1-MATNR` 절대경로 대신 `_find_by_id_substring`로 찾아 화면
    서브구조가 달라져도 버티게 했다.
    ⚠️ 녹화 당시엔 자재번호 입력 후 곧바로 기본 데이터 화면으로 넘어갔고 "뷰 선택(Select
    View(s))" 팝업은 뜨지 않았다 — 그 자재에 최근 조회 이력이 있어 SAP가 뷰를 기억하고
    있었을 가능성이 있다. 뷰 선택 이력이 없는 자재는 이 팝업이 뜰 수 있어, 방어적으로
    wnd[1]이 나타나면 Enter(기본 선택 확정)를 한 번 시도한다 — 이 경로는 실사용 녹화가
    없어 추측성 코드이니, 만약 특정 자재에서 계속 실패하면 그 팝업이 뜬 상태로 화면을
    캡처해서 정확한 컨트롤을 다시 녹화해야 한다.
    ⚠️⚠️ [2026-09-15 실사용에서 확인] "RMMG1-MATNR" 문자열을 포함한 컨트롤이 화면에 하나가
    아닐 수 있다(예: 매치코드/히스토리 드롭다운 버튼 등) — 첫 매치가 실제 입력 필드가 아니면
    `.text = ...`가 COM 오류("Property 'Item.text' can not be set.")로 실패한다. 그래서
    `_find_by_id_substring`(첫 매치만 반환) 대신 `_find_all_by_id_substring`으로 후보를 전부
    모아, 녹화에서 확인된 타입(GuiCTextField, ID 접두사 `ctxt`)을 우선순위로 정렬한 뒤 실제로
    값을 설정할 수 있는 첫 번째 후보를 채택한다.
    💡 [2026-09-15 신규] 지금 화면에 이미 자재 목록 그리드(ZMM009 "자재 List" 등)가 떠 있으면
    `/nMM03`을 매번 새로 여는 대신 그 그리드에서 바로 drill-down한다(`_open_material_from_
    current_list`) — 여러 자재를 한 번에 조회해둔 상태에서 하나씩 문서를 열 때 더 빠르고,
    이미 그 자재가 그 리스트에 있다는 걸 사람이 확인한 셈이라 더 안전하다. 그 화면에 그리드가
    없거나 그 자재가 없으면 조용히 실패하고 아래 `/nMM03` 새로 열기 경로로 폴백한다."""
    _navigate_to_material_screen(session, wnd, material)

    # 💡⚠️ [2026-09-15 실사용 스크린샷으로 확정] "문서 데이터" 탭은 메인 화면(기본 데이터 1/2 등)의
    # 탭 스트립에 없다 — 화면 하단 "기본 데이터 텍스트" 섹션의 버튼(기술 ID에 GRUNDDATENTEXT
    # 포함)을 눌러야만 열리는 별도 "추가 데이터" 서브화면 안에 있다(그 서브화면 자체의 탭:
    # 문서 데이터/기본 데이터 텍스트/검사 텍스트/내부 주석/소비). 처음 받은 SAP GUI "기록 및
    # 재생" 매크로에 이 버튼 클릭이 있었는데 "부수적인 클릭"으로 잘못 판단해 자동화 코드에서
    # 빠뜨렸던 게 자재 106188에서 계속 실패한 진짜 원인이었다 — 반드시 눌러야 한다.
    extra_data_btn = _find_by_id_substring(wnd, 'GRUNDDATENTEXT')
    if extra_data_btn is not None:
        try:
            extra_data_btn.press()
            time.sleep(0.8)
        except Exception:
            pass

    found = _select_tab_with_retry(wnd, 'tabpZU04')
    time.sleep(0.4)
    if not found:
        raise RuntimeError(f'자재 "{material}" 화면에서 "문서 데이터" 탭을 찾지 못했습니다 — SAP GUI에서 직접 MM03으로 이 자재를 조회했을 때도 (자재 화면 하단의 "기본 데이터 텍스트" 버튼을 눌러 들어간 서브화면에서도) "문서 데이터" 탭이 안 보인다면, 그 자재에 저장된 "뷰 선택(View)" 이력에 문서 데이터 뷰가 빠져 있을 수 있습니다.')


def fetch_material_documents(material):
    """자재번호만 주어지고 문서 타입(P01 등)은 모를 때 — 그 자재의 "문서 데이터" 탭까지
    이동한 뒤, 특정 문서를 열지 않고 화면에 보이는 문서 목록을 fetch_current_screen()과
    똑같은 범용 덤프 로직(_sap_find_grid/_sap_dump_fields)으로 그대로 읽어온다(2026-09-15
    신규). "문서 데이터" 탭의 문서 목록은 GuiShell 그리드가 아니라 classic GuiTableControl
    이라 _sap_find_grid는 못 찾고 _sap_dump_fields 경로를 타는데, 이 함수가 이미
    GuiTextField/GuiCTextField 타입 텍스트를 traversal 순서대로 모으므로 각 문서 행의
    타입/설명 텍스트가 그대로 딸려온다 — 이 화면 전용 파서를 새로 만들지 않고 기존 범용
    덤프를 재사용한 것(CLAUDE.md의 "특정 트랜잭션 전용 파서를 만들지 않는다" 설계 원칙을
    그대로 따름). 사람이 이 덤프를 보고 원하는 문서 타입을 골라 다시 "OO 문서 열어줘"라고
    말하면 open_document()가 그 타입을 찾아 연다."""
    if not material:
        raise RuntimeError('자재번호를 지정해주세요.')

    session = _get_sap_session()
    wnd = session.findById('wnd[0]')
    _navigate_to_material_document_tab(session, wnd, material)

    body, source = _sap_dump_screen_body(wnd)

    if not body:
        return {'ok': False, 'error': f'자재 "{material}"의 "문서 데이터" 화면에서 읽을 수 있는 데이터를 찾지 못했습니다 — 자재번호가 올바른지 확인해주세요.'}

    header = f'[SAP MM03 문서 데이터: 자재 {material}]\n'
    text = header + '\n' + body
    return {'ok': True, 'source': source, 'material': material, 'text': text}


# ── "표준가격/기간별단가" 조회 (MM03 "회계 1" 탭, 2026-09-23 신규, 사용자 요청) ──────────
# "표준가격 기간별 단가 확인해줘"가 안 된다는 실사용 제보 → 새 `dump_screen_tree` 도구로
# 사용자가 직접 자재 106437의 MM03 "회계 1" 탭을 덤프해줘서, 매크로 없이 정확한 필드 ID를
# 그 자리에서 확인해 구현(추측 없음, docs/sap-lookup.md "화면 트리 덤프" 절 참고).
# ⚠️ 표준가격(STPRS)/기간별단가(PVPRS)는 **가격단위(PEINH)당** 금액이다 — 가격단위가
# 100이면 화면 숫자는 "100개당 가격"이라, 실제 개당 단가는 그 값을 가격단위로 나눠야
# 한다(사용자 지적: "가격 단위 수량이 있어, 나누기 해서 알려줘야해"). 예: 가격단위 100,
# 표준가격 10,800 → 실제 단가 108.
# 🐛🐛 [2026-10-02 실화면 덤프로 원인 확정] 검색어에 컨트롤 접두어(txt/ctxt)를 반드시 포함할 것.
#   _find_by_id_substring은 타입 구분 없이 깊이우선 "첫 매치"를 돌려주는데, SAP 화면 트리에는
#   같은 이름의 GuiLabel(lblXXX)이 실제 값이 든 GuiTextField(txtXXX)보다 **먼저** 나온다.
#   접두어 없이 'CKMMAT_DISPLAY-STPRS_1'로 찾으면 라벨(.Text="표준 가격")이 잡혀서
#   숫자 파싱이 실패하고 "가격 필드를 찾지 못했습니다"로 끝났다(실사용 제보).
#   ⚠️ 새 필드를 추가할 때도 반드시 덤프에서 실제 접두어를 확인할 것 — 값 필드가
#      txt(GuiTextField)인지 ctxt(GuiCTextField)인지는 필드마다 다르다.
_MATERIAL_PRICE_FIELD_IDS = {
    'stprs': 'txtCKMMAT_DISPLAY-STPRS_1',   # 표준 가격        예: 44,950
    'pvprs': 'txtCKMMAT_DISPLAY-PVPRS_1',   # 기간별 단가      예: 37,044
    'peinh': 'txtCKMMAT_DISPLAY-PEINH_1',   # 가격단위         예: 100
    'vprsv': 'ctxtCKMMAT_DISPLAY-VPRSV_1',  # 가격 관리(S/V)   ← ctxt 주의
    'stprv': 'txtCKMMAT_DISPLAY-STPRV_1',   # 이전가격
    # [2026-10-02] 같은 화면에 이미 있어 추가 조회 없이 얻는 값들
    'waers': 'txtCKMMAT_DISPLAY-WAERS_1',   # 통화             예: KRW
    'salk3': 'txtCKMMAT_DISPLAY-SALK3_1',   # 재고 값
    'zkprs': 'txtCKMMAT_DISPLAY-ZKPRS_1',   # 미래가격
    'laepr': 'ctxtCKMMAT_DISPLAY-LAEPR_1',  # 최종 가격변경일  ← ctxt
    'lbkum': 'txtCKMLPP-LBKUM',             # 총 재고
    'meins': 'ctxtMARA-MEINS',              # 기본단위         ← ctxt
}


def _parse_sap_number(text):
    """SAP 숫자 표기("10,800", "8,796 ")를 float로 변환. 실패/빈 값이면 None."""
    if text is None:
        return None
    t = str(text).strip().replace(',', '')
    if not t:
        return None
    try:
        return float(t)
    except ValueError:
        return None


def fetch_material_price(material):
    """MM03 "회계 1" 탭에서 표준가격(STPRS)/기간별단가(PVPRS)/가격단위(PEINH)를 읽어,
    가격단위로 나눈 실제 개당 단가까지 계산해 돌려준다."""
    if not material:
        raise RuntimeError('자재번호를 지정해주세요.')

    session = _get_sap_session()
    wnd = session.findById('wnd[0]')
    _navigate_to_material_screen(session, wnd, material)

    found = _select_tab_with_retry(wnd, 'tabpSP24')  # "회계 1"
    if not found:
        raise RuntimeError(f'자재 "{material}" 화면에서 "회계 1" 탭을 찾지 못했습니다 — 이 자재에 회계 뷰가 없을 수 있습니다.')

    # 🐛 [2026-09-23 실사용 버그수정] "회계 1" 탭 안에 다시 중첩된 기간 탭스트립(PPLF 등)의
    # 서브화면(가격 필드들이 실제로 들어있는 곳)이 탭 전환 직후 바로 안 잡혀서(0.4초 고정
    # 대기로는 부족) "가격 필드를 찾지 못했습니다"로 실패하던 문제 — 고정 대기 한 번 대신
    # `_select_tab_with_retry`와 같은 패턴으로 짧게 여러 번 재시도한다.
    values = {}
    stprs = pvprs = None
    for _attempt in range(6):
        time.sleep(0.5)
        wnd = session.findById('wnd[0]')
        values = {}
        for key, id_sub in _MATERIAL_PRICE_FIELD_IDS.items():
            field = _find_by_id_substring(wnd, id_sub)
            values[key] = str(field.Text).strip() if field is not None else None
        stprs = _parse_sap_number(values.get('stprs'))
        pvprs = _parse_sap_number(values.get('pvprs'))
        if stprs is not None or pvprs is not None:
            break

    if stprs is None and pvprs is None:
        raise RuntimeError(f'자재 "{material}"의 "회계 1" 탭에서 가격 필드를 찾지 못했습니다 — 화면 구성이 다를 수 있습니다.')

    peinh = _parse_sap_number(values.get('peinh')) or 1.0
    if peinh <= 0:
        peinh = 1.0

    vprsv = values.get('vprsv')
    vprsv_label = {'S': '표준가', 'V': '이동평균가'}.get(vprsv, vprsv)

    unit = values.get('meins') or ''
    cur  = values.get('waers') or ''
    lines = [f'[SAP MM03 회계1: 자재 {material}]']
    if cur:
        lines.append(f'통화: {cur}')
    if vprsv:
        lines.append(f'가격 관리: {vprsv}' + (f' ({vprsv_label})' if vprsv_label != vprsv else ''))
    lines.append(f'가격단위(PEINH): {values.get("peinh") or "1"}')
    if stprs is not None:
        lines.append(f'표준 가격: {values["stprs"]} (가격단위 {peinh:g}개당) → 실제 단가: {stprs / peinh:,.4f}')
    if pvprs is not None:
        lines.append(f'기간별 단가: {values["pvprs"]} (가격단위 {peinh:g}개당) → 실제 단가: {pvprs / peinh:,.4f}')
    if values.get('stprv'):
        lines.append(f'이전가격: {values["stprv"]}')
    if values.get('zkprs') and _parse_sap_number(values.get('zkprs')):
        lines.append(f'미래가격: {values["zkprs"]}')
    if values.get('laepr'):
        lines.append(f'최종 가격변경: {values["laepr"]}')
    if values.get('salk3'):
        lines.append(f'재고 값: {values["salk3"]}')
    if values.get('lbkum'):
        lines.append(f'총 재고: {values["lbkum"]}' + (f' {unit}' if unit else ''))
    text = '\n'.join(lines)

    return {
        'ok': True, 'material': material,
        'priceUnit': peinh,
        'standardPrice': stprs, 'standardPricePerUnit': (stprs / peinh) if stprs is not None else None,
        'periodPrice': pvprs, 'periodPricePerUnit': (pvprs / peinh) if pvprs is not None else None,
        'priceControl': vprsv,
        'currency': cur or None,
        'baseUnit': unit or None,
        'stockValue': values.get('salk3'),
        'futurePrice': values.get('zkprs'),
        'lastPriceChange': values.get('laepr'),
        'totalStock': _parse_sap_number(values.get('lbkum')),
        'text': text,
    }


def open_document(doc_type, material=None):
    """MM03에서 이미 열려 있는(또는 material이 주어지면 직접 조회해서 여는) 자재의
    "문서 데이터" 탭에서, 지정한 문서 타입(예: 'P01')과 일치하는 행을 찾아 열고, 그 문서의
    "원본(Originals)" 파일을 더블클릭해서 연결된 프로그램(Acrobat 등)으로 바로 연다."""
    doc_type = (doc_type or '').strip().upper()
    if not doc_type:
        raise RuntimeError('문서 타입을 지정해주세요 (예: P01).')

    session = _get_sap_session()
    wnd = session.findById('wnd[0]')

    if material:
        # 자재번호가 주어졌으면 직접 MM03으로 이동해 조회 — 사람이 미리 화면을 열어둘
        # 필요가 없다(2026-09-15부터 지원).
        _navigate_to_material_document_tab(session, wnd, material)
    else:
        # 자재번호 없이 호출되면 기존 방식대로 "이미 열려 있는 화면"을 그대로 사용.
        _select_tab_if_present(wnd, 'tabpZU04')
        time.sleep(0.3)

    # 2) 문서 목록 테이블 컨트롤을 화면 어디에 있든 찾는다.
    table = _find_by_id_substring(wnd, 'tblSAPLCV140SUB_DOC')
    if table is None:
        raise RuntimeError('"문서 데이터" 탭의 문서 목록을 화면에서 찾지 못했습니다 — MM03에서 해당 자재를 조회하고 "문서 데이터" 탭을 열어둔 상태인지 확인해주세요.')

    # 3) 화면에 보이는 행(스크롤 포함)을 훑어 어느 컬럼이든 doc_type과 정확히 일치하는
    #    셀을 찾는다 — 여러 페이지에 걸쳐 있을 수 있어 스크롤하며 반복 탐색.
    target_cell = None
    try:
        total_rows = table.RowCount
        visible_rows = table.VisibleRowCount or total_rows or 1
    except Exception:
        total_rows, visible_rows = 0, 1
    seen_positions = set()
    pos = 0
    while target_cell is None:
        if pos in seen_positions:
            break
        seen_positions.add(pos)
        try:
            table.FirstVisibleRow = pos
        except Exception:
            pass
        target_cell = _table_find_cell_by_exact_row_text(table, doc_type)
        if target_cell is not None:
            break
        pos += visible_rows
        if not total_rows or pos >= total_rows:
            break

    if target_cell is None:
        raise RuntimeError(f'"문서 데이터" 목록에서 문서 타입 "{doc_type}"를 찾지 못했습니다 — 화면에 보이는 Ty. 열 값과 정확히 일치해야 합니다.')

    # 4) 해당 셀에 포커스를 준 뒤 F2(VKey 2)로 "연다" — 실사용 녹화에서 확인한 패턴
    #    (setFocus → caretPosition → sendVKey 2, 더블클릭과 동일 효과).
    try:
        target_cell.setFocus()
        target_cell.caretPosition = 0
    except Exception:
        pass
    wnd.sendVKey(2)
    time.sleep(1.2)  # 새 문서 조회 화면이 그려질 시간

    # 5) "원본(Originals)" 탭(tabpTSFILES — 실사용 테스트로 확인, "전표 데이터" 탭인
    #    tabpTSMAIN과는 다름)이 기본으로 선택돼 있지 않을 수 있어 명시적으로 선택 시도
    #    (이전에 다른 탭을 보고 있었으면 문서를 새로 열어도 그 탭이 그대로 유지돼, 원본 탭
    #    하위 컨트롤이 아예 렌더링 트리에 없어 못 찾는 경우가 실제로 있었음).
    _select_tab_if_present(wnd, 'tabpTSFILES')

    # 💡 [2026-09-14] 실사용 테스트로 확인: 탭 전환 직후 곧바로 하위 컨트롤을 찾으면 화면이
    #    아직 다 그려지지 않았거나(찾지 못함) SAP GUI가 일시적으로 바쁜 상태라 COM 예외가
    #    나는 경우가 있었다 — 짧게 여러 번 재시도한다.
    tree = None
    last_err = None
    for attempt in range(5):
        time.sleep(0.6)
        try:
            tree = _find_by_id_substring(wnd, 'CTL_FILES', require_type='GuiShell')
        except Exception as e:
            last_err = e
            continue
        if tree is not None:
            break

    # "원본(Originals)" 트리 컨트롤을 찾아 첫 번째 첨부파일을 더블클릭 — SAP가 임시폴더
    #    (C:\temp)에 내려받은 뒤 연결된 프로그램(Acrobat 등)으로 자동으로 연다. 이 동작에
    #    수반되던 "SAP GUI 보안" 확인 팝업은 사용자가 SAP GUI 옵션에서 C:/temp/* 읽기+실행
    #    허용 규칙을 추가해서 더 이상 뜨지 않는 것을 실사용으로 확인함(2026-09-14).
    if tree is None:
        extra = f' (마지막 오류: {last_err})' if last_err else ''
        raise RuntimeError(f'문서 "{doc_type}"는 열었지만, "원본(Originals)" 파일 목록을 화면에서 찾지 못했습니다 — 이 문서에 첨부파일이 없거나 화면이 아직 그려지는 중일 수 있습니다.{extra}')

    try:
        node_keys = list(tree.GetAllNodeKeys())
    except Exception as e:
        raise RuntimeError(f'원본 파일 목록을 읽는 중 오류가 발생했습니다: {e}')
    if not node_keys:
        raise RuntimeError(f'문서 "{doc_type}"에 연결된 원본 파일이 없습니다.')

    first_key = node_keys[0]
    tree.selectNode(first_key)
    tree.doubleClickNode(first_key)

    return {'ok': True, 'docType': doc_type, 'message': f'문서 "{doc_type}"의 원본 파일을 열도록 요청했습니다. 잠시 후 연결된 프로그램(Acrobat 등)이 열립니다.'}


# ── "여러 자재 문서 일괄 다운로드" (ZDMSR004) 전용 헬퍼 ──────────────────
# 💡 [2026-09-15 신규] 지금까지의 open_document()는 자재 1개씩 MM03을 드릴다운하는 방식이었는데,
# 사용자가 "여러 개를 한 번에" 처리하고 싶다고 해서 확인해보니 — 회사 SAP에 이미 "DMS 첨부파일
# 일괄 다운로드 프로그램"(트랜잭션 ZDMSR004)이라는 전용 커스텀 리포트가 있었다. 이 리포트의
# 선택화면에서 자재코드를 복수 선택(SAP 표준 "복수 선택" 팝업, 함수그룹 SAPLALDB)으로 여러 개
# 넣고 문서유형(P01 등)을 지정해 실행하면, 그 자재들의 해당 문서가 ALV 그리드로 뜨고, 전체
# 선택 후 "다운로드" 버튼을 누르면 `C:\SAP_DMS\<문서번호>\<원본파일명>` 구조로 로컬에 한 번에
# 다운로드된다 — MM03 드릴다운을 반복하는 것보다 훨씬 빠르고 신뢰도 높은 방식이라 이쪽을
# 기본 경로로 추가했다. 2026-09-15 실사용 SAP GUI "기록 및 재생" 매크로로 정확한 컨트롤 ID를
# 확보했고, **폴더 선택 창이 전혀 뜨지 않았다**(다운로드 경로가 ABAP 리포트 내부에
# `C:\SAP_DMS\`로 고정돼 있는 것으로 추정) — 그래서 이 함수는 순수 SAP GUI 컨트롤 조작만으로
# 끝까지 완결된다(네이티브 Windows 다이얼로그 처리가 필요 없음).
# SAP 표준 "복수 선택" 팝업(함수그룹 SAPLALDB)의 "단일 값 선택" 탭 입력 표 — 여러 트랜잭션의
# SELECT-OPTIONS/PARAMETERS "복수 선택" 버튼이 공통으로 이 구조를 쓴다(2026-09-15 실사용
# 매크로 2건 — ZDMSR004의 S_MATNR 필드, ZPP038의 MATNR 필드 — 으로 동일 구조 확인). 새
# 트랜잭션에서도 재사용 가능성이 높지만, 확인 버튼 개수는 호출 맥락마다 다를 수 있었다
# (`_navigate_to_bom_screen`의 관련 주석 참고) — 새로 쓸 때 버튼 동작까지 자동으로 같다고
# 가정하지 말 것.
_SAP_MULTI_SELECT_POPUP_TABLE = "wnd[1]/usr/tabsTAB_STRIP/tabpSIVA/ssubSCREEN_HEADER:SAPLALDB:3010/tblSAPLALDBSINGLE"


def download_documents_batch(materials, doc_type='P01'):
    """ZDMSR004("DMS 첨부파일 일괄 다운로드 프로그램")을 실행해 여러 자재의 문서를 한 번에
    C:\\SAP_DMS\\<문서번호>\\ 아래로 다운로드한다. materials는 자재번호 문자열 리스트."""
    materials = [str(m).strip() for m in (materials or []) if str(m).strip()]
    if not materials:
        raise RuntimeError('다운로드할 자재번호가 없습니다.')
    doc_type = (doc_type or 'P01').strip().upper()

    session = _get_sap_session()
    wnd = session.findById('wnd[0]')

    session.findById('wnd[0]/tbar[0]/okcd').text = '/nZDMSR004'
    wnd.sendVKey(0)
    time.sleep(0.8)

    # 자재코드 "복수 선택" 팝업 열기(실사용 매크로에서 확인된 정확한 버튼 ID).
    multi_btn = _find_by_id_substring(wnd, '%_S_MATNR_%_APP_%-VALU_PUSH')
    if multi_btn is None:
        raise RuntimeError('ZDMSR004 화면에서 "자재코드 복수 선택" 버튼을 찾지 못했습니다 — 화면 구조가 예상과 다를 수 있습니다(트랜잭션 권한이 없을 가능성도 있음).')
    multi_btn.press()
    time.sleep(0.8)

    # 값 입력 — 한 화면에 보이는 행 수를 넘으면 스크롤(FirstVisibleRow)해서 이어서 입력한다.
    # ⚠️ 실사용 매크로에서는 7개까지만 확인됐고(한 화면에 다 보임) 스크롤 자체는 검증 안 됨 —
    # 8개 이상 넣을 때 문제가 있으면 이 부분을 의심할 것.
    try:
        table = session.findById(_SAP_MULTI_SELECT_POPUP_TABLE)
    except Exception:
        raise RuntimeError('"자재코드 복수 선택" 팝업의 입력 표를 찾지 못했습니다.')
    try:
        visible_rows = table.VisibleRowCount or 7
    except Exception:
        visible_rows = 7
    idx = 0
    while idx < len(materials):
        if idx > 0:
            try:
                table.FirstVisibleRow = idx
                time.sleep(0.3)
            except Exception:
                pass
        batch = materials[idx: idx + visible_rows]
        for row_offset, mat in enumerate(batch):
            cell_id = f"{_SAP_MULTI_SELECT_POPUP_TABLE}/ctxtRSCSEL_255-SLOW_I[1,{row_offset}]"
            try:
                cell = session.findById(cell_id)
                cell.text = mat
            except Exception as e:
                raise RuntimeError(f'"자재코드 복수 선택" 팝업에 {idx + row_offset + 1}번째 자재("{mat}")를 입력하지 못했습니다: {e}')
        idx += len(batch)

    # 팝업 확인(실사용 매크로에서 확인된 정확한 두 버튼 — 순서 그대로 재현).
    try:
        session.findById('wnd[1]/tbar[0]/btn[24]').press()
        time.sleep(0.3)
        session.findById('wnd[1]/tbar[0]/btn[8]').press()
    except Exception as e:
        raise RuntimeError(f'"자재코드 복수 선택" 팝업을 확인하는 중 오류가 발생했습니다: {e}')
    time.sleep(0.8)

    # 문서유형 필터.
    try:
        dokar_field = session.findById('wnd[0]/usr/ctxtS_DOKAR-LOW')
        dokar_field.text = doc_type
    except Exception:
        pass  # 이 필드가 없어도(트랜잭션 화면이 다르면) 실행 자체는 시도한다.

    # 실행(F8, 애플리케이션 툴바의 실행 버튼).
    try:
        session.findById('wnd[0]/tbar[1]/btn[8]').press()
    except Exception as e:
        raise RuntimeError(f'ZDMSR004 실행(F8) 중 오류가 발생했습니다: {e}')
    time.sleep(1.5)

    # ⚠️⚠️ [2026-09-16 실사용 버그수정] 아래 "결과 그리드 전체 선택 후 다운로드" 직전에 그리드를
    # 먼저 읽어 "문서번호(DOKNR)→자재번호(MATNR)" 매핑을 확보해둔다 — 이 함수가 원래 반환하던
    # 메시지("자재별 하위 폴더 자동 생성")는 사실이 아니었다: ZDMSR004는 폴더를 **문서번호**로
    # 만들지 자재번호로 만들지 않는다(실사용 제보로 확인 — 사용자가 캡처해준 C:\SAP_DMS\ 화면에
    # `P01202101796`류 문서번호 폴더만 잔뜩 있고, 그 6자리 자재번호와 어떻게 매칭되는지, 같은
    # 자재의 문서가 여러 건(리비전)일 때 어느 게 "내역(1)"/"내역(2)"인지 전혀 알 수 없다는
    # 지적). 라이브 진단으로 그리드 컬럼을 확인해보니 `MATNR`/`DOKNR` 필드가 그대로 있어(표시
    # 라벨은 SAP GUI Scripting 한글 인코딩 버그로 깨지지만 — CLAUDE.md의 "ALV 그리드 한글이
    # 깨진다" 절 참고 — 기술 필드명 `GetCellValue(row, 'MATNR')`는 정상 작동), 다운로드 전에
    # 이 매핑을 미리 읽어둘 수 있다는 걸 확인함. 그리드는 다음 조회에서 초기화되므로 반드시
    # "다운로드 버튼을 누르기 전"인 지금 읽어야 한다.
    matnr_by_doknr = {}
    try:
        grid_probe = session.findById('wnd[0]/shellcont/shell')
        for r in range(grid_probe.RowCount):
            try:
                doknr = str(grid_probe.GetCellValue(r, 'DOKNR')).strip()
                matnr = str(grid_probe.GetCellValue(r, 'MATNR')).strip()
                if doknr and matnr and doknr not in matnr_by_doknr:
                    matnr_by_doknr[doknr] = matnr
            except Exception:
                continue
    except Exception:
        pass  # 매핑 확보에 실패해도 다운로드 자체는 계속 진행 — 폴더명 개선은 최선노력일 뿐

    # 결과 그리드 전체 선택 후 다운로드.
    try:
        grid = session.findById('wnd[0]/shellcont/shell')
        grid.setCurrentCell(-1, '')
        grid.selectAll()
        time.sleep(0.3)
        session.findById('wnd[0]/tbar[1]/btn[13]').press()
    except Exception as e:
        raise RuntimeError(f'결과 목록에서 전체 선택 후 다운로드하는 중 오류가 발생했습니다(자재를 찾지 못해 결과가 비어 있을 수도 있습니다): {e}')
    time.sleep(1.5)

    # 💡 [2026-09-16 신규] 위에서 확보한 매핑으로 다운로드된 <문서번호> 폴더를
    # <자재번호>_<문서번호>로 이름을 바꾼다 — 이러면 폴더명만 보고도 바로 어느 자재의 문서인지
    # 알 수 있고, 같은 자재가 문서번호(리비전)만 다르게 여러 개 있는 경우도 전부 같은 자재번호
    # 접두사를 공유해 한눈에 같은 자재 것임을 알 수 있다. SAP 리포트가 서버 쪽에서 이미
    # <문서번호> 폴더를 만들어버리므로(경로가 ABAP 내부에 고정돼 있어 SAP 쪽 파일명 자체는
    # 바꿀 방법이 없음 — CLAUDE.md의 ZDMSR004 절 참고) 다운로드 직후 로컬 파일시스템에서
    # 후처리로 이름을 바꾸는 방식을 택함. 이미 그 이름으로 폴더가 있으면(재실행 등) 건드리지
    # 않고, 실패해도(폴더가 아직 안 생겼거나 권한 문제) 다운로드 자체는 이미 끝난 뒤이므로
    # 조용히 넘어간다.
    renamed_map = {}  # {원래 문서번호 폴더명: 새 폴더명}
    try:
        base_dir = r'C:\SAP_DMS'
        for doknr, matnr in matnr_by_doknr.items():
            src = os.path.join(base_dir, doknr)
            if not os.path.isdir(src):
                continue
            dst_name = f'{matnr}_{doknr}'
            dst = os.path.join(base_dir, dst_name)
            if os.path.isdir(dst):
                continue
            try:
                os.rename(src, dst)
                renamed_map[doknr] = dst_name
            except Exception:
                continue
    except Exception:
        pass

    # 자재번호 → 문서번호(들) 역매핑 — 이름 변경이 실패했어도 채팅 응답 문구로 매칭 정보를
    # 그대로 전달할 수 있게 대비(벨트 앤 서스펜더스: 폴더명 개선이 안 돼도 최소한 텍스트로는
    # 사용자가 알 수 있어야 한다).
    doknrs_by_matnr = {}
    for doknr, matnr in matnr_by_doknr.items():
        doknrs_by_matnr.setdefault(matnr, []).append(doknr)
    mapping_lines = [f'{matnr}: ' + ', '.join(doknrs) for matnr, doknrs in doknrs_by_matnr.items()]
    mapping_text = ' / '.join(mapping_lines)

    if renamed_map:
        folder_note = f'폴더명을 <자재번호>_<문서번호> 형태로 바꿔뒀습니다({len(renamed_map)}건) — 폴더명만 보고 바로 매칭됩니다.'
    else:
        folder_note = f'폴더는 여전히 문서번호로 표시됩니다 — 자재번호 매칭: {mapping_text}' if mapping_text else '자재-문서 매칭 정보를 확보하지 못했습니다(그리드 조회 실패).'

    return {
        'ok': True,
        'materials': materials,
        'docType': doc_type,
        'matnrByDoknr': matnr_by_doknr,
        'renamedFolders': renamed_map,
        'savedFolder': r'C:\SAP_DMS',
        'message': f'{len(materials)}개 자재의 "{doc_type}" 문서를 C:\\SAP_DMS\\ 폴더로 다운로드했습니다. {folder_note}',
    }


# ── DMS 문서번호 조회 전용 (ZDMSR004 read-only, 다운로드 없음) (2026-10-01 신규) ──────────
# "501362 P02 문서번호 확인해줘" / "501362,501363 P02 문서 없는지 확인해줘" 처럼
# 자재 목록에 대해 특정 문서 타입의 문서번호가 있는지만 확인하고 파일은 다운로드하지 않는다.
# download_documents_batch()와 ZDMSR004 진입/팝업/실행 흐름은 동일하고,
# 결과 그리드를 읽은 뒤 다운로드 버튼(tbar[1]/btn[13])을 누르지 않는 점만 다르다.
def lookup_documents_batch(materials, doc_type='P02'):
    """ZDMSR004를 실행해 자재 목록의 문서번호 유무를 조회한다(다운로드하지 않음)."""
    materials = [str(m).strip() for m in (materials or []) if str(m).strip()]
    if not materials:
        raise RuntimeError('조회할 자재번호가 없습니다.')
    doc_type = (doc_type or 'P02').strip().upper()

    session = _get_sap_session()
    wnd = session.findById('wnd[0]')

    session.findById('wnd[0]/tbar[0]/okcd').text = '/nZDMSR004'
    wnd.sendVKey(0)
    time.sleep(0.8)

    multi_btn = _find_by_id_substring(wnd, '%_S_MATNR_%_APP_%-VALU_PUSH')
    if multi_btn is None:
        raise RuntimeError('ZDMSR004 화면에서 자재코드 입력 버튼을 찾지 못했습니다.')
    multi_btn.press()
    time.sleep(0.8)

    try:
        table = session.findById(_SAP_MULTI_SELECT_POPUP_TABLE)
    except Exception:
        raise RuntimeError('"자재코드 복수 선택" 팝업의 입력 표를 찾지 못했습니다.')
    try:
        visible_rows = table.VisibleRowCount or 7
    except Exception:
        visible_rows = 7

    idx = 0
    while idx < len(materials):
        if idx > 0:
            try:
                table.FirstVisibleRow = idx
                time.sleep(0.3)
            except Exception:
                pass
        batch = materials[idx: idx + visible_rows]
        for row_offset, mat in enumerate(batch):
            cell_id = f"{_SAP_MULTI_SELECT_POPUP_TABLE}/ctxtRSCSEL_255-SLOW_I[1,{row_offset}]"
            try:
                cell = session.findById(cell_id)
                cell.text = mat
            except Exception as e:
                raise RuntimeError(f'{idx + row_offset + 1}번째 자재("{mat}") 입력 실패: {e}')
        idx += len(batch)

    try:
        session.findById('wnd[1]/tbar[0]/btn[24]').press()
        time.sleep(0.3)
        session.findById('wnd[1]/tbar[0]/btn[8]').press()
    except Exception as e:
        raise RuntimeError(f'팝업 확인 중 오류: {e}')
    time.sleep(0.8)

    try:
        session.findById('wnd[0]/usr/ctxtS_DOKAR-LOW').text = doc_type
    except Exception:
        pass

    try:
        session.findById('wnd[0]/tbar[1]/btn[8]').press()
    except Exception as e:
        raise RuntimeError(f'ZDMSR004 실행 중 오류: {e}')
    time.sleep(1.5)

    mat_to_docs = {m: [] for m in materials}
    try:
        grid = session.findById('wnd[0]/shellcont/shell')
        row_count = grid.RowCount
        for r in range(row_count):
            try:
                doknr = str(grid.GetCellValue(r, 'DOKNR')).strip()
                matnr = str(grid.GetCellValue(r, 'MATNR')).strip()
                if not matnr or not doknr:
                    continue
                dktxt = ''
                try:
                    dktxt = str(grid.GetCellValue(r, 'DKTXT')).strip()
                except Exception:
                    pass
                if matnr in mat_to_docs:
                    mat_to_docs[matnr].append({'doknr': doknr, 'dktxt': dktxt})
            except Exception:
                continue
    except Exception as e:
        raise RuntimeError(f'결과 그리드 읽기 실패(자재를 찾지 못해 결과가 비어 있을 수도 있습니다): {e}')

    has_doc = {m: docs for m, docs in mat_to_docs.items() if docs}
    no_doc_list = [m for m in materials if not mat_to_docs.get(m)]

    lines = [f'[SAP ZDMSR004 {doc_type} 문서 조회: {len(materials)}건]']
    if no_doc_list:
        lines.append(f'\n■ {doc_type} 문서 없음 ({len(no_doc_list)}건):')
        lines.append('  ' + ', '.join(no_doc_list))
    if has_doc:
        lines.append(f'\n■ {doc_type} 문서 있음 ({len(has_doc)}건):')
        for mat, docs in sorted(has_doc.items()):
            doc_strs = [d['doknr'] + (f' ({d["dktxt"]})' if d['dktxt'] else '') for d in docs]
            lines.append(f'  {mat}: ' + ', '.join(doc_strs))

    return {
        'ok': True,
        'doc_type': doc_type,
        'total': len(materials),
        'has_doc': {m: [d['doknr'] for d in docs] for m, docs in has_doc.items()},
        'no_doc': no_doc_list,
        'text': '\n'.join(lines)
    }


# ── 자재내역 와일드카드 패턴으로 자재번호 조회 + 승인원(P01) 일괄 다운로드 (2026-09-16 신규) ──
# "*01+01*500*로 조회된 아이템 승인원 다운로드해줘" 요청을 지원한다. 사용자가 준 매크로
# ("디스크립션 검색.vbs")는 ZMM009 화면에서 자재(MATNR) "복수 선택" 팝업을 열고 그 안에서
# F4로 자재 검색도움말(SAPLSDH4, "M: 자재 번호/자재 내역" 탭)을 띄워 와일드카드로 검색한 뒤,
# 결과에서 원하는 항목을 더블클릭으로 하나씩 골라 담는 방식이었다 — 여러 건을 한 번에
# 뽑는 방법은 아니었다(매크로 자체가 사람이 결과를 보면서 3건을 수동으로 고른 기록).
# **2026-09-16 실사용 라이브 진단으로 훨씬 단순한 경로를 확인함**:
#   1. 이 검색도움말은 ZMM009의 "복수 선택" 팝업을 거칠 필요가 없다 — MM60("자재 목록
#      표시")처럼 훨씬 단순한 화면의 평범한 단일값 자재번호 필드에서 그냥 F4만 눌러도
#      똑같은 "값 범위 제한" 팝업(TAB001="M: 자재 번호/자재 내역")이 바로 뜬다. 그래서
#      ZMM009의 필수 입력 3개(플랜트/판매조직/유통경로)를 전혀 거칠 필요가 없다 — MM60은
#      실행(F8)조차 하지 않고 이 팝업을 여는 용도로만 쓴다.
#   2. 결과 화면은 GuiGridView가 아니라 "라벨 매트릭스"이지만(진단 스크립트로 `_sap_find_grid`/
#      `_sap_find_shell_any` 둘 다 실패해서 확인함) 구조가 아주 규칙적이다 — 매치 1건이
#      행(row) 하나에 대응하고(`lbl[열,행]` 형태의 GuiLabel들, 자재내역=1열/언어/자재번호
#      순서로 배치), row는 3부터 시작해 매치 개수만큼 이어진다. 팝업 제목 자체(`wnd[1].Text`)
#      에도 "자재 번호 N 엔트리"로 건수가 그대로 나온다. **더블클릭으로 하나씩 고를 필요 없이
#      행을 순서대로 읽기만 하면 전체 매치를 한 번에 뽑을 수 있다** — 매크로보다 훨씬
#      간단해짐. 실제 라이브 테스트: `*01+01*500*` → 2건(115505/114347),
#      `*01+01*150*`(매크로 원본 패턴) → 4건(129305/108918/124887/114347) — 둘 다 컬럼
#      순회로 정확히 추출 성공함.
#   3. 검색 후에는 굳이 값을 "채택"(복사 버튼)할 필요가 없다 — 그냥 읽기만 하고
#      취소(F12)로 닫으면 된다(ZMM009 자체를 실행할 필요가 없으므로 SELECT-OPTIONS에
#      값을 채워 넣는 것 자체가 불필요).
# ⚠️⚠️ [2026-09-16 실사용 버그수정] 자재번호 열 위치(처음 발견 당시 `lbl[44,row]`)는
# **고정값이 아니다** — 실제로는 결과의 자재내역 텍스트 길이에 따라 화면이 열 너비를
# 동적으로 재배치해서, "*06+06*200*"처럼 실제로는 SAP에 9건이 매치되는데도(팝업 제목이
# "자재 번호 9 엔트리"로 정확히 뜨는 것까지 라이브로 확인함) 자재번호가 `lbl[46,row]`로
# 두 칸 밀려 있어 하드코딩된 44번 열에서 `col=3`부터 연속 2회 실패로 즉시 포기하고 빈
# 배열을 반환 — "패턴에 매치되는 자재가 없습니다"로 조용히 실패했다(실제로는 SAP 쪽엔
# 데이터가 멀쩡히 있었음). 처음 발견 당시 테스트한 두 패턴(2건/4건, 짧은 자재내역)은
# 우연히 44번 열이었을 뿐, 자재내역이 길어지는 케이스(이번처럼 9건, "HN BTB>06+06,0200,
# #28,HD05+YH47,V1,LB01" 등 긴 문자열)에서는 열이 밀린다는 걸 놓쳤던 것 — **열 번호를
# 하드코딩하지 말고, 헤더 행(row=1)의 "자재"/"자재내역" 라벨 텍스트를 매번 직접 읽어
# 그 열 위치를 동적으로 찾아내도록 수정**(`_sap_read_material_label_matrix`). 앞으로 이
# 라벨 매트릭스 구조를 가진 다른 SAP 검색도움말을 자동화할 때도, 열 번호를 한 번 발견
# 했다고 고정값으로 믿지 말고 항상 헤더 행에서 동적으로 찾을 것.
_SEARCHHELP_TAB1_BASE = ('wnd[1]/usr/tabsG_SELONETABSTRIP/tabpTAB001/'
                         'ssubSUBSCR_PRESEL:SAPLSDH4:0220/sub:SAPLSDH4:0220')


def _sap_searchhelp_field_by_keyword(session, keyword, max_rows=12):
    """검색도움말(SAPLSDH4) 첫 탭에서 **라벨(KEYWORD) 텍스트로** 짝이 되는 입력칸을 찾는다
    (2026-09-28 신규). 이 팝업은 각 줄이 `txtG_SELFLD_TAB-KEYWORD[N,0]`(라벨) +
    `txt|ctxtG_SELFLD_TAB-LOW[N,24]`(입력칸) 쌍으로 돼 있다 — 실사용 덤프로 확인:
    0=관리회계 영역, 1=처리그룹, 2=오더 유형, **3=오더**, **4=내역**.
    줄 번호를 하드코딩하면 검색도움말이 바뀔 때 엉뚱한 칸에 값을 넣게 되므로(이 코드베이스의
    "좌표 대신 라벨로 동적 탐색" 원칙) 항상 라벨로 찾는다. 입력칸 접두사가 줄마다 `ctxt`/`txt`로
    다른 것도 실측으로 확인돼 둘 다 시도한다."""
    labels = {}
    for i in range(max_rows):
        try:
            kw = (session.findById(f'{_SEARCHHELP_TAB1_BASE}/txtG_SELFLD_TAB-KEYWORD[{i},0]').Text or '').strip()
        except Exception:
            continue
        if kw:
            labels[i] = kw

    # ⚠️ [2026-09-28 실사용 버그수정] 부분일치만 쓰면 "오더"가 **"오더 유형"**(바로 윗줄)에 먼저
    #    걸려서 엉뚱한 칸에 값을 넣는다("Property '<unknown>.text' can not be set."로 실패).
    #    반드시 **완전일치 우선 → 그다음 부분일치** 순서로 찾을 것.
    order = ([i for i, kw in labels.items() if kw == keyword]
             + [i for i, kw in labels.items() if kw != keyword and keyword in kw])
    for i in order:
        for prefix in ('txt', 'ctxt'):
            try:
                fld = session.findById(f'{_SEARCHHELP_TAB1_BASE}/{prefix}G_SELFLD_TAB-LOW[{i},24]')
                if fld is not None:
                    return fld
            except Exception:
                continue
    return None


def _sap_read_searchhelp_matrix(session, max_results=300, header_row=1, first_data_row=3, header_hints=None):
    """검색도움말(SAPLSDH4) 결과 라벨 매트릭스를 **열 이름 그대로** 통째로 읽는 범용 리더
    (2026-09-28 신규 — `_sap_read_material_label_matrix`가 자재 전용으로 열 이름을 하드코딩
    해둔 것을, "프로젝트 코드 조회"처럼 다른 검색도움말에도 쓸 수 있게 일반화한 것).
    ⚠️ 결과가 한 화면을 넘으면 스크롤해야 다 보인다(사용자 매크로도 position=469까지 내렸음)
    — `wnd[1]/usr`의 세로 스크롤바를 한 화면씩 내리며 중복 없이 모은다.
    반환: (헤더목록:[str], 행목록:[[str]]) — 헤더 순서와 각 행의 셀 순서가 서로 대응한다."""
    id_re = re.compile(r'lbl\[(\d+),(\d+)\]$')

    def _scan_visible():
        """지금 화면에 보이는 라벨을 {행: {열: 텍스트}}로 모은다."""
        out = {}
        try:
            usr = session.findById('wnd[1]/usr')
            children = usr.Children
        except Exception:
            return out
        for i in range(children.Count):
            try:
                child = children.ElementAt(i)
                m = id_re.search(str(child.Id))
                if not m:
                    continue
                col, row = int(m.group(1)), int(m.group(2))
                out.setdefault(row, {})[col] = (child.Text or '').strip()
            except Exception:
                continue
        return out

    visible = _scan_visible()
    if not visible:
        return [], []
    # 🆕 [2026-09-28] 결과 목록의 진짜 헤더 행은 검색도움말마다 다르다(내부오더 검색은 1행이
    # 필터 영역이고 "유형/오더/내역" 헤더는 그 아래에 있다) — 기대하는 열 이름(header_hints)이
    # 있으면 그 단어가 들어있는 행을 헤더로 삼는다. 없으면 기존처럼 header_row를 쓴다.
    if header_hints:
        for row_no in sorted(visible.keys()):
            texts = {(v or '').strip() for v in visible[row_no].values()}
            if any(h in texts for h in header_hints):
                header_row, first_data_row = row_no, row_no + 1
                break
    header_cells = visible.get(header_row, {})
    cols = sorted(header_cells.keys())
    headers = [header_cells[c] for c in cols]
    if not cols:
        return [], []

    rows, seen = [], set()

    def _collect(snapshot):
        for row_no in sorted(snapshot.keys()):
            if row_no < first_data_row:
                continue
            cells = snapshot[row_no]
            vals = [cells.get(c, '') for c in cols]
            if not any(v for v in vals):
                continue
            key = '\x01'.join(vals)
            if key in seen:
                continue
            seen.add(key)
            rows.append(vals)

    _collect(visible)
    # 스크롤하며 나머지 페이지 수집 — 위치가 더 안 내려가면(끝) 중단.
    last_pos = -1
    while len(rows) < max_results:
        try:
            sb = session.findById('wnd[1]/usr').verticalScrollbar
            pos, page, maximum = int(sb.position), int(sb.pageSize or 10), int(sb.maximum)
        except Exception:
            break
        if pos >= maximum or pos == last_pos:
            break
        last_pos = pos
        try:
            sb.position = min(maximum, pos + max(1, page))
        except Exception:
            break
        time.sleep(0.15)
        _collect(_scan_visible())

    rows = rows[:max_results]

    # 🧹 [2026-09-28] 검색도움말마다 헤더가 몇 번째 행인지 다르다 — 내부오더 검색도움말은
    # 1행이 필터 영역("처리그룹"/"00")이고 진짜 헤더("오더")가 데이터 첫 행으로 잡혔다(실사용
    # 확인). 행 번호를 더 하드코딩하는 대신, ① 전부 비어 있는 열을 버리고 ② 헤더가 비었으면
    # 첫 행을 헤더로 승격시켜 정리한다 — 어떤 검색도움말이든 같은 규칙으로 깔끔해진다.
    keep = [i for i in range(len(cols))
            if (i < len(headers) and headers[i]) or any(r[i] for r in rows)]
    if keep and len(keep) != len(cols):
        headers = [headers[i] if i < len(headers) else '' for i in keep]
        rows = [[r[i] for i in keep] for r in rows]
    if rows and not any(headers):
        headers, rows = rows[0], rows[1:]
    # 헤더와 똑같은 내용이 데이터 행으로 또 잡힌 경우 제거
    rows = [r for r in rows if r != headers]
    return headers, rows


def _sap_read_material_label_matrix(session, max_results=200):
    """자재 검색도움말(SAPLSDH4 "M: 자재 번호/자재 내역") 결과 화면의 라벨 매트릭스에서
    자재번호/자재내역을 읽는다. 열 위치를 하드코딩하지 않고, 헤더 행(row=1)의 GuiLabel
    텍스트("자재"/"자재내역")를 직접 매칭해 그 열 번호를 매번 새로 찾아낸다 — 위 주석
    참고, 열 위치는 결과 텍스트 폭에 따라 화면마다 달라질 수 있다."""
    usr = session.findById('wnd[1]/usr')
    id_re = re.compile(r'lbl\[(\d+),(\d+)\]$')
    header = {}  # {열번호: 헤더텍스트}
    for i in range(usr.Children.Count):
        child = usr.Children.ElementAt(i)
        try:
            child_id = child.Id
        except Exception:
            continue
        m = id_re.search(child_id)
        if not m:
            continue
        col, row = int(m.group(1)), int(m.group(2))
        if row == 1:
            try:
                header[col] = (child.Text or '').strip()
            except Exception:
                pass

    matnr_col = None
    desc_col = None
    for col, text in header.items():
        if text in ('자재', 'Material', 'Material Number'):
            matnr_col = col
        elif text in ('자재내역', 'Material Description', 'Description'):
            desc_col = col
    if matnr_col is None:
        raise RuntimeError('검색 결과 화면에서 "자재" 열 위치를 찾지 못했습니다 — 화면 레이아웃이 예상과 다를 수 있습니다.')

    materials = []
    row = 3
    consecutive_misses = 0
    while consecutive_misses < 2 and len(materials) < max_results:
        try:
            mat_lbl = session.findById(f'wnd[1]/usr/lbl[{matnr_col},{row}]')
            desc = ''
            if desc_col is not None:
                try:
                    desc = session.findById(f'wnd[1]/usr/lbl[{desc_col},{row}]').Text
                except Exception:
                    pass
            materials.append({'matnr': mat_lbl.Text.strip(), 'desc': desc})
            consecutive_misses = 0
        except Exception:
            consecutive_misses += 1
        row += 1

    return materials


def resolve_materials_by_description_pattern(pattern, max_results=200):
    """자재내역(MAKT-MAKTX) 와일드카드 패턴으로 매치되는 자재번호 목록을 조회한다.
    MM60의 평범한 자재번호 필드에서 F4로 연 검색도움말(TAB001)에 패턴을 넣고, 결과
    라벨 매트릭스를 컬럼 순서대로 읽어 전부 추출한다 — 어떤 값도 선택/채택하지 않고
    읽기만 하므로 SAP 데이터에 아무 영향이 없다.
    ⚠️ max_results는 실사용 UX 요구사항이 아니라(사용자가 "건수가 많아도 그냥 다운로드"를
    선택함, 2026-09-16) 패턴이 사실상 전체 자재를 매치하는 극단적인 경우(예: "*" 단독)에
    무한정 컬럼을 순회하며 멈추지 않는 사고를 막기 위한 기술적 안전장치일 뿐이다."""
    pattern = (pattern or '').strip()
    if not pattern:
        raise RuntimeError('검색할 자재내역 패턴이 없습니다.')

    session = _get_sap_session()
    wnd = session.findById('wnd[0]')
    _sap_close_stray_popups(session)

    session.findById('wnd[0]/tbar[0]/okcd').text = '/nMM60'
    wnd.sendVKey(0)
    time.sleep(0.8)

    matnr_field = _find_by_id_substring(wnd, 'ctxtMS_MATNR-LOW')
    if matnr_field is None:
        raise RuntimeError('MM60 화면에서 자재번호 입력 필드를 찾지 못했습니다 — 화면 구조가 예상과 다를 수 있습니다.')
    matnr_field.text = ''
    matnr_field.setFocus()
    matnr_field.caretPosition = 0
    wnd.sendVKey(4)
    time.sleep(0.8)

    popup = None
    for _ in range(10):
        try:
            popup = session.findById('wnd[1]')
            break
        except Exception:
            time.sleep(0.4)
    if popup is None:
        raise RuntimeError('자재 검색도움말 팝업이 뜨지 않았습니다.')

    tabstrip = _find_by_id_substring(popup, 'G_SELONETABSTRIP')
    if tabstrip is None:
        raise RuntimeError('자재 검색도움말에 예상한 "M: 자재 번호/자재 내역" 탭 구조가 없습니다 — SAP 화면 구성이 바뀌었을 수 있습니다.')

    field_id = "wnd[1]/usr/tabsG_SELONETABSTRIP/tabpTAB001/ssubSUBSCR_PRESEL:SAPLSDH4:0220/sub:SAPLSDH4:0220/txtG_SELFLD_TAB-LOW[0,24]"
    try:
        field = session.findById(field_id)
    except Exception as e:
        raise RuntimeError(f'자재내역 검색 입력 필드를 찾지 못했습니다: {e}')
    field.text = pattern
    field.caretPosition = len(pattern)
    popup.sendVKey(0)
    time.sleep(1.2)

    try:
        popup = session.findById('wnd[1]')
    except Exception:
        raise RuntimeError('검색 실행 후 결과 팝업이 사라졌습니다 — 매치가 없거나 오류가 발생했을 수 있습니다.')

    # [2026-09-29 버그수정] _sap_read_material_label_matrix → _sap_read_searchhelp_matrix
    # 구 함수는 스크롤 없이 첫 화면 분량만 읽어 "*MLCC*" 같은 다건 패턴에서 결과가 잘렸다.
    headers, data_rows = _sap_read_searchhelp_matrix(session, max_results)

    # 결과는 읽기만 하고 아무것도 채택하지 않음 — 취소(F12)로 팝업을 닫는다.
    try:
        session.findById('wnd[1]').sendVKey(12)
    except Exception:
        pass

    # (headers, data_rows) → [{'matnr': ..., 'desc': ...}] 형식으로 변환
    def _col_idx(names):
        for n in names:
            try:
                return headers.index(n)
            except ValueError:
                pass
        return None

    matnr_idx = _col_idx(['자재', 'Material', 'Material Number'])
    desc_idx  = _col_idx(['자재내역', 'Material Description', 'Description'])
    if matnr_idx is None:
        raise RuntimeError('검색 결과에서 "자재" 열을 찾지 못했습니다 — 헤더: ' + str(headers))

    materials = []
    for r in data_rows:
        matnr = r[matnr_idx] if matnr_idx < len(r) else ''
        desc  = (r[desc_idx] if desc_idx < len(r) else '') if desc_idx is not None else ''
        if matnr:
            materials.append({'matnr': matnr, 'desc': desc})

    if len(materials) >= max_results:
        raise RuntimeError(f'패턴 "{pattern}"이 너무 광범위합니다(최소 {max_results}건 이상 매치) — 더 구체적인 패턴으로 다시 시도해주세요.')

    return materials


# ── "프로젝트 코드(내부오더) 패턴 조회" (MB21, 2026-09-28 신규, 사용자 요청) ──────────
# ℹ️ **MB21의 사내 본 용도는 "계정대체청구"**(2026-09-28 사용자 지정) — 개발용 자재를 청구(출고,
# 이동유형 **951**)하거나 반납(입고, **907**)해 계정을 대체하는 업무다. 아래 프로젝트 코드 조회는
# 그 화면의 내부오더 검색도움말을 빌려 쓰는 **부수 용도**일 뿐이며, 청구 자체(실제 예약 생성)는
# 아직 미구현이다 — 구현할 때 이 함수(조회, 저장 없음)와 반드시 분리하고 사람 확인 단계를 둘 것.
# 어휘(계정대체청구서/자재청구/자재반납 등)→이동유형 표는 코드가 아니라 데이터로 관리한다:
# `window.SAP_MB21_MOVEMENT_TYPES`(js/32-sap-capabilities.js), docs/sap-lookup.md 참고.
# 사용자가 준 매크로(`프로젝트 코드확인.vbs`) 기반. 프로젝트코드는 MB21(예약 생성) 화면의
# 계정지정 블록에 있는 **내부오더(COBL-AUFNR) 검색도움말**에서 패턴으로 찾는다 — 이 검색도움말
# 팝업은 이미 이 코드베이스가 쓰고 있는 자재내역 패턴 조회(SAPLSDH4:0220)와 **완전히 같은 구조**라
# 입력 필드/결과 읽기 로직을 그대로 재사용한다(다른 점은 패턴 입력칸의 행 번호뿐: 자재는
# `[0,24]`, 여기는 매크로 기준 `[3,24]` — 검색도움말마다 달라서 못 찾으면 후보를 훑는다).
# ⚠️ 매크로는 기준일자/이동유형/플랜트를 **F4 목록에서 좌표(lbl[1,32] 등)로** 골랐는데, 그 좌표는
# 목록 내용이 바뀌면 엉뚱한 값을 고르게 되므로 재현하지 않는다(화면 좌표 하드코딩 금지 원칙).
# 대신 **화면에 이미 들어있는 값(SAP이 기억하는 직전 입력값)을 그대로 두고**, 인자로 명시했을
# 때만 덮어쓴다 — 조회는 어차피 아무것도 저장하지 않으므로 헤더 값이 무엇이든 상관없다.
# ⚠️ 읽기 전용: 어떤 값도 선택/채택하지 않고, 끝나면 팝업을 F12로 닫고 `/n`으로 빠져나온다.
def fetch_project_codes(pattern, bwart=None, werks=None, max_results=300, rsdat=None, by='code'):
    """프로젝트 코드(내부오더 AUFNR)를 와일드카드 패턴으로 조회한다.
    `by='code'`(기본) — "오더" 칸으로 코드 검색(예: "*G26*").
    `by='desc'`        — "내역" 칸으로 **프로젝트명** 검색(예: "*STELLAR*", 2026-09-28 추가).
    ⚠️ SAP 검색은 **대소문자를 구분**한다 — "stellar"로는 안 찾아지고 "STELLAR"로 해야 한다.
    호출부(AI 문답)가 이 사실을 사용자에게 안내하도록 결과에 `caseSensitive: True`를 싣는다."""
    pattern = (pattern or '').strip()
    if not pattern:
        raise RuntimeError('조회할 프로젝트 코드 패턴을 지정해주세요. 예: *G26*')
    if '*' not in pattern:
        pattern = f'*{pattern}*'  # 사람이 "G26"만 말해도 부분일치로 찾아준다

    session = _get_sap_session()
    _sap_close_stray_popups(session)
    wnd = session.findById('wnd[0]')

    session.findById('wnd[0]/tbar[0]/okcd').text = '/nMB21'
    wnd.sendVKey(0)
    time.sleep(0.8)
    wnd = session.findById('wnd[0]')

    # 🐛 [2026-09-28 실사용 확인] MB21 초기화면의 필요일(RSDAT)/이동유형(BWART)/플랜트(WERKS)는
    # 셋 다 필수인데 SAP이 직전 값을 기억하지 않아 비어 있었다("모든 필수 입력 필드에 값을
    # 입력하십시오"). 조회는 아무것도 저장하지 않으므로 이 값들은 **검색도움말까지 가기 위한
    # 통과용**일 뿐이다 — 이동유형은 **사용자가 알려준 951**을 기본으로 쓴다(2026-09-28).
    # 처음엔 표준 SAP 관례대로 261(오더에 대한 출고)을 넣었다가 SAP이 "261에 대한 예약이
    # 불가능합니다 (다른 이동유형을 선택하십시오)"로 거절한 것을 실사용에서 확인했다 — 이
    # 시스템에서 예약 가능한 이동유형은 사내 설정을 따르므로 추측하지 말 것.
    _PC_DEFAULT_BWART = '951'
    _set_text_on_best_candidate(wnd, 'RM07M-RSDAT', str(rsdat or time.strftime('%Y%m%d')))
    _set_text_on_best_candidate(wnd, 'RM07M-BWART', str(bwart or _PC_DEFAULT_BWART))
    _set_text_on_best_candidate(wnd, 'RM07M-WERKS', str(werks or '1000'))

    try:
        session.findById('wnd[0]/tbar[1]/btn[7]').press()  # 매크로와 동일 — 품목(계정지정) 화면으로
    except Exception as e:
        raise RuntimeError(f'MB21에서 다음 화면으로 넘어가지 못했습니다: {e}')
    time.sleep(1.0)
    wnd = session.findById('wnd[0]')

    # 상태표시줄에 필수입력 오류가 떠서 화면이 안 넘어갔을 수 있다 — 사유를 그대로 전달한다.
    # ⚠️ `_find_by_id_substring`은 같은 이름의 **라벨**(lblCOBL-AUFNR)을 먼저 잡는다(CLAUDE.md의
    #    알려진 함정) — 라벨에 setFocus()해도 F4가 안 열려서 "팝업이 뜨지 않았습니다"로 실패했다
    #    (2026-09-28 실사용 확인). 반드시 입력칸(ctxt…)을 골라야 한다.
    aufnr_field = None
    for cand in _find_all_by_id_substring(wnd, 'COBL-AUFNR'):
        try:
            if str(getattr(cand, 'Type', '')) in ('GuiCTextField', 'GuiTextField') and cand.Changeable:
                aufnr_field = cand
                break
        except Exception:
            continue
    if aufnr_field is None:
        sbar = ''
        try:
            sbar = (session.findById('wnd[0]/sbar').Text or '').strip()
        except Exception:
            pass
        detail = f' [SAP 상태표시줄: "{sbar}"]' if sbar else ''
        raise RuntimeError(
            'MB21 화면에서 내부오더(COBL-AUFNR) 입력칸을 찾지 못했습니다.' + detail +
            ' — 기준일자/이동유형/플랜트 같은 필수 항목이 비어 있어 다음 화면으로 넘어가지 못했을 수 있습니다'
            ' (이동유형을 bwart 인자로 지정해보세요).')

    def _close_popups():
        for _ in range(3):
            try:
                session.findById('wnd[1]').sendVKey(12)
                time.sleep(0.2)
            except Exception:
                break

    def _search_once(search_by):
        """F4 팝업을 열어 지정한 칸('오더' 또는 '내역')에 패턴을 넣고 결과를 읽은 뒤 팝업을 닫는다."""
        # ⚠️ [2026-09-28] 매번 화면/필드를 **다시 찾는다** — 첫 검색이 끝나면 화면이 다시 그려져서
        #    처음에 잡아둔 COM 참조가 무효가 된다(자동 폴백 2차 검색이 "서버에서 예외 오류"로
        #    실패했던 원인). SAP 자동화에서 화면 전환 뒤 참조 재사용은 항상 이런 식으로 깨진다.
        cur_wnd = session.findById('wnd[0]')
        fld_aufnr = None
        for cand in _find_all_by_id_substring(cur_wnd, 'COBL-AUFNR'):
            try:
                if str(getattr(cand, 'Type', '')) in ('GuiCTextField', 'GuiTextField') and cand.Changeable:
                    fld_aufnr = cand
                    break
            except Exception:
                continue
        if fld_aufnr is None:
            raise RuntimeError('MB21 화면에서 내부오더(COBL-AUFNR) 입력칸을 찾지 못했습니다.')
        try:
            fld_aufnr.setFocus()
            fld_aufnr.caretPosition = 0   # 매크로와 동일
            cur_wnd.sendVKey(4)  # F4 = 검색도움말
        except Exception as e:
            raise RuntimeError(f'내부오더 검색도움말(F4)을 열지 못했습니다: {e}')

        popup = None
        for _ in range(8):   # 팝업이 뜰 때까지 짧게 재시도(화면이 무거우면 1초로는 부족)
            time.sleep(0.4)
            try:
                popup = session.findById('wnd[1]')
                break
            except Exception:
                continue
        if popup is None:
            raise RuntimeError('내부오더 검색도움말 팝업이 뜨지 않았습니다.')

        # 패턴 입력칸 — 줄 번호를 박지 않고 **라벨(KEYWORD)로 찾는다**: 코드 검색은 "오더",
        # 프로젝트명 검색은 "내역". 못 찾으면 매크로에서 확인된 좌표로 폴백.
        want_keyword = '내역' if search_by == 'desc' else '오더'
        fld = _sap_searchhelp_field_by_keyword(session, want_keyword)
        if fld is None:
            fallback_row = 4 if search_by == 'desc' else 3
            for prefix in ('txt', 'ctxt'):
                try:
                    fld = session.findById(f'{_SEARCHHELP_TAB1_BASE}/{prefix}G_SELFLD_TAB-LOW[{fallback_row},24]')
                    break
                except Exception:
                    continue
        if fld is None:
            raise RuntimeError(f'내부오더 검색도움말에서 "{want_keyword}" 입력칸을 찾지 못했습니다.')
        try:
            fld.text = pattern
            fld.setFocus()
            fld.caretPosition = len(pattern)
        except Exception as e:
            raise RuntimeError(f'검색 패턴을 입력하지 못했습니다: {e}')

        session.findById('wnd[1]').sendVKey(0)  # 검색 실행
        time.sleep(1.2)

        h, r = [], []
        try:
            session.findById('wnd[1]')
            h, r = _sap_read_searchhelp_matrix(
                session, max_results, header_hints=('오더', '내역', '유형'))
        except Exception:
            pass
        _close_popups()
        return h, r

    # 🆕 [2026-09-28 사용자 지적] 예전엔 사용자가 "프로젝트 **코드**"라고 말했다는 이유로 무조건
    # "오더" 칸을 썼는데, `*STELLAR*`처럼 **문자만 있는 패턴**은 오더 칸으로는 절대 안 나온다
    # (오더는 G2610OB 같은 코드값). 호출부가 패턴 모양으로 먼저 고르고(숫자 포함=코드), 여기서는
    # **고른 쪽에서 0건이면 반대쪽도 자동으로 한 번 더 찾아본다** — 사람이 "코드/이름" 중 뭘로
    # 검색되는지 몰라도 그냥 찾아지게 하기 위함(예: "STELLAR_32"처럼 숫자가 섞인 이름도 구제).
    headers, rows = _search_once(by)
    used_by = by
    if not rows:
        other = 'code' if by == 'desc' else 'desc'
        headers, rows = _search_once(other)
        if rows:
            used_by = other

    try:
        session.findById('wnd[0]/tbar[0]/okcd').text = '/n'
        session.findById('wnd[0]').sendVKey(0)
    except Exception:
        pass
    by = used_by

    # 🧹 결과 정리 — 헤더에서 "오더"/"내역" 열 위치를 찾아 코드+프로젝트명 짝으로 만든다.
    # 헤더를 못 찾는 경우(검색도움말 레이아웃이 다를 때)에는 예전처럼 "코드처럼 생긴 값"만 뽑는다.
    label_like = {h.strip() for h in headers if h.strip()} | {'오더', 'Order', '내부오더', '유형', '내역'}
    code_col = next((i for i, h in enumerate(headers) if h.strip() == '오더'), None)
    desc_col = next((i for i, h in enumerate(headers) if h.strip() == '내역'), None)

    items, seen = [], set()
    if code_col is not None:
        for r in rows:
            code = (r[code_col] if code_col < len(r) else '').strip()
            if not code or code in label_like or code in seen:
                continue
            seen.add(code)
            desc = (r[desc_col] if desc_col is not None and desc_col < len(r) else '').strip()
            items.append({'code': code, 'desc': desc})
    else:
        for r in rows:
            for cell in r:
                v = (cell or '').strip()
                if not v or v in label_like or v in seen:
                    continue
                if not re.match(r'^[A-Za-z0-9][A-Za-z0-9_\-/.]{2,19}$', v):
                    continue  # 공백/한글이 섞인 설명 문구 등은 코드가 아님
                seen.add(v)
                items.append({'code': v, 'desc': ''})

    if not items:
        return {'ok': False, 'pattern': pattern, 'by': by, 'caseSensitive': True,
                'error': f'"{pattern}"에 맞는 항목을 **코드(오더)와 프로젝트명(내역) 양쪽 모두에서** '
                         f'찾지 못했습니다 — SAP 검색은 대소문자를 구분하니 영문을 대문자로 바꿔보시고'
                         f'(예: *STELLAR*), 패턴도 넓혀보세요.'}

    codes = [it['code'] for it in items]
    lines = [(f"{it['code']}\t{it['desc']}" if it['desc'] else it['code']) for it in items]
    how_label = '프로젝트명(내역)' if by == 'desc' else '프로젝트 코드(오더)'
    text = (f'[SAP {how_label} 조회(MB21 "계정대체청구" 화면의 내부오더 검색): '
            f'패턴 "{pattern}" — {len(items)}건]\n\n' + '\n'.join(lines))
    return {'ok': True, 'pattern': pattern, 'by': by, 'caseSensitive': True,
            'count': len(items), 'codes': codes, 'items': items,
            'headers': headers, 'rows': rows, 'text': text,
            'truncated': len(rows) >= max_results}


def _migo_post_by_reservation(session, rsnum, posting_date):
    """F00151(예약 기반 반납 전기) Phase 2 — VBS 반납입고.vbs lines 216-234 재현."""
    nav_ok = False
    try:
        session.findById(
            'wnd[0]/usr/cntlIMAGE_CONTAINER/shellcont/shell/shellcont[0]/shell'
        ).doubleClickNode('F00151')
        time.sleep(1.0)
        nav_ok = True
    except Exception:
        pass
    if not nav_ok:
        raise RuntimeError(
            f'예약번호 {rsnum} 전기를 위해 F00151 즐겨찾기를 찾지 못했습니다. '
            'SAP Easy Access에서 F00151 즐겨찾기가 있는지 확인해주세요.')

    wnd = session.findById('wnd[0]')
    try:
        rsnum_field = wnd.findById('usr/txtRSNUM-LOW')
        rsnum_field.text = str(rsnum)
        rsnum_field.setFocus()
        rsnum_field.caretPosition = len(str(rsnum))
    except Exception as e:
        raise RuntimeError(f'예약번호(RSNUM-LOW) 입력칸을 찾지 못했습니다: {e}')

    session.findById('wnd[0]/tbar[1]/btn[8]').press()   # F8 실행
    time.sleep(1.2)

    # 전기일자 F4 설정 (VBS line 220-222)
    try:
        session.findById('wnd[0]').sendVKey(4)
        time.sleep(0.5)
        cal = session.findById('wnd[1]/usr/cntlCONTAINER/shellcont/shell')
        cal.focusDate = posting_date
        cal.selectionInterval = f'{posting_date},{posting_date}'
        time.sleep(0.3)
    except Exception:
        pass

    session.findById('wnd[0]/tbar[1]/btn[8]').press()   # F8 재실행 (VBS line 223)
    time.sleep(1.2)

    # 전체 선택 후 전기 (VBS lines 224-232)
    try:
        grid = session.findById('wnd[0]/shellcont/shell')
        grid.setCurrentCell(-1, '')
        grid.selectAll()
        session.findById('wnd[0]/tbar[1]/btn[13]').press()   # 전기
        time.sleep(1.0)
    except Exception as e:
        raise RuntimeError(f'전기 버튼 실행 실패: {e}')

    # 확인 팝업 (VBS lines 231-232)
    try:
        session.findById('wnd[1]/tbar[0]/btn[13]').press()
        time.sleep(0.5)
        session.findById('wnd[1]/tbar[0]/btn[86]').press()
        time.sleep(1.0)
    except Exception:
        pass

    sbar = ''
    mat_doc = None
    try:
        sbar = (session.findById('wnd[0]/sbar').Text or '').strip()
        import re as _re
        m = _re.search(r'(\d{9,10})', sbar)
        if m:
            mat_doc = m.group(1)
    except Exception:
        pass

    # 뒤로 2번 (VBS lines 233-234)
    for _ in range(2):
        try:
            session.findById('wnd[0]/tbar[0]/btn[3]').press()
            time.sleep(0.3)
        except Exception:
            break

    return {
        'ok': True,
        'material_document': mat_doc,
        'sbar': sbar,
        'text': (f'반납 입고 전기 완료 — 자재 문서번호: {mat_doc}'
                 if mat_doc else f'전기 후 문서번호 확인 필요. (상태바: {sbar})')
    }


def _sap_status_text(session):
    """상태바 문구 — 실패했을 때 SAP이 실제로 뭐라고 했는지가 가장 중요한 단서다."""
    try:
        return (session.findById('wnd[0]/sbar').Text or '').strip()
    except Exception:
        return ''


def _sap_open_popups(session, max_windows=4):
    """지금 열려 있는 팝업(wnd[1] 이상)을 [(인덱스, 제목)] 로 돌려준다."""
    out = []
    for i in range(1, max_windows + 1):
        try:
            w = session.findById(f'wnd[{i}]')
        except Exception:
            continue
        try:
            out.append((i, str(w.Text or '').strip()))
        except Exception:
            out.append((i, ''))
    return out


def _sap_screen_info(session):
    """"지금 어느 화면에 있나"를 한 줄로 — 실패 보고에 반드시 같이 실어야 다음 수를 둘 수 있다.

    [2026-10-02] MB21 저장이 "유효한 기능을 선택하십시오"로 막혔을 때, 그 메시지만으로는
    **어느 화면에서 막혔는지** 알 수 없어 두 번이나 추측으로 고치다 실패했다. 트랜잭션/프로그램/
    화면번호/제목과 **열려 있는 팝업 목록**까지 같이 보면 원인이 바로 좁혀진다
    (대표적으로 코딩 블록 팝업이 안 닫혀 wnd[0] 조작이 전부 막히는 경우).
    """
    tcode = program = screen = title = ''
    try:
        info = session.Info
        tcode, program, screen = str(info.Transaction), str(info.Program), str(info.ScreenNumber)
    except Exception:
        pass
    try:
        title = str(session.findById('wnd[0]').Text or '').strip()
    except Exception:
        pass
    pops = _sap_open_popups(session)
    s = f'{tcode}/{program}/{screen} "{title}"'
    if pops:
        s += ' · 열린 팝업: ' + ', '.join(f'wnd[{i}]"{t}"' for i, t in pops)
    else:
        s += ' · 팝업 없음'
    return s


def humanize_sap_error(exc, session=None, step=''):
    """COM 예외를 사람이 바로 알아보는 한국어로 바꾼다.

    [2026-10-02 실사용 제보] 사용자가 받은 메시지:
      "(-2147352567, '예외가 발생했습니다.', (617, 'SAP Frontend Server',
        'The virtual key is not enabled.', None, 0, 0), None)"
    → 이 문자열만으로는 무엇을 해야 하는지 알 수 없다. "그 화면에서 그 기능키가 비활성"이라는
      뜻이고, MB21에서는 **필수 입력(특히 품목 텍스트)이 비어 저장키가 잠긴 경우**가 대표적이다.
      그래서 상태바 문구를 같이 실어 보낸다.
    """
    raw = str(exc)
    sbar = _sap_status_text(session) if session is not None else ''
    where = f'[{step}] ' if step else ''
    if 'virtual key is not enabled' in raw.lower():
        msg = (f'{where}SAP이 그 단축키를 지금 화면에서 받지 않았습니다(저장/확인 키가 잠긴 상태). '
               '보통 **필수 입력 항목이 비어 있을 때** 이렇게 됩니다 — MB21이라면 품목 텍스트(사유)를 '
               '확인해주세요.')
    elif 'element id' in raw.lower() or 'not be found' in raw.lower():
        msg = f'{where}SAP 화면에서 필요한 입력칸을 찾지 못했습니다(화면이 예상과 다릅니다).'
    elif 'rejected' in raw.lower() or 'busy' in raw.lower():
        msg = f'{where}SAP GUI가 다른 작업을 처리 중이라 요청을 거부했습니다. 잠시 후 다시 시도해주세요.'
    else:
        msg = f'{where}SAP 조작 중 오류가 발생했습니다.'
    if sbar:
        msg += f'\n  SAP 상태바: "{sbar}"'
    msg += f'\n  (원본: {raw[:300]})'
    return msg


def _sap_send_vkey(session, key, wnd_id='wnd[0]', fallback_btn=None, step=''):
    """sendVKey를 보내되, 그 키가 잠겨 있으면 같은 기능의 툴바 버튼으로 한 번 더 시도한다.

    둘 다 실패하면 humanize_sap_error로 번역한 RuntimeError를 던진다 — 원시 COM 문자열이
    사용자에게 그대로 나가지 않게 하기 위함(2026-10-02 제보).
    """
    try:
        session.findById(wnd_id).sendVKey(key)
        return True
    except Exception as e1:
        if fallback_btn:
            try:
                session.findById(wnd_id + '/' + fallback_btn).press()
                return True
            except Exception:
                pass
        raise RuntimeError(humanize_sap_error(e1, session, step))


_MB21_ERROR_HINTS = ('오류', '필수', '유효한', '입력하십시오', '선택하십시오',
                     '없습니다', '불가', '허용되지')


def _mb21_extract_rsnum(sbar):
    """상태바에서 예약번호를 뽑는다 — 오류 문구에 섞인 숫자를 번호로 오인하지 않게 거른다."""
    if not sbar:
        return None
    if any(h in sbar for h in _MB21_ERROR_HINTS):
        return None
    import re as _re
    m = _re.search(r'(\d{7,10})', sbar)
    return m.group(1) if m else None


def _sap_screen_no(session):
    """현재 화면번호(문자열). MB21은 500=초기화면 / 521=품목입력 / 510=품목상세."""
    try:
        return str(session.Info.ScreenNumber).strip()
    except Exception:
        return ''


def _mb21_read_last_rsnum(session):
    """방금 만든 예약번호를 회수한다.

    ✅ [2026-10-02 사용자 설명 + 녹화 매크로] MB21은 저장이 끝나면 **초기화면(500)으로 돌아가고**,
      예약번호는 상태바에 남지 않을 수 있다. 사람은 이때 **MB23(예약조회)을 열어** 확인한다 —
      SAP이 "바로 전에 처리한 문서번호"를 그 칸에 기억해 두기 때문이다(녹화에서도 F00198로 이동).

    순서: ① 지금 화면의 RM07M-RSNUM(참조 칸) → ② MB23으로 가서 같은 칸 →
          ③ 그래도 비어 있으면 F5(마지막 값 가져오기) 후 다시 읽기.
    """
    def _read(path='wnd[0]/usr/ctxtRM07M-RSNUM'):
        try:
            v = str(session.findById(path).Text or '').strip()
            return v if v and v.strip('0') else None
        except Exception:
            return None

    # ① 지금 화면(저장 후 MB21 초기화면)에 이미 들어 있는 경우
    v = _read()
    if v:
        return v

    # ② MB23으로 이동해서 읽는다 — 조회 전용이라 데이터를 건드리지 않는다
    try:
        session.findById('wnd[0]/tbar[0]/okcd').text = '/nMB23'
        session.findById('wnd[0]').sendVKey(0)
        time.sleep(1.2)
    except Exception as e:
        print(f'[MB21] 예약번호 확인용 MB23 이동 실패: {e}', file=sys.stderr)
        return None

    v = _read()
    if v:
        return v

    # ③ 칸이 비어 있으면 "마지막 값 가져오기"(F5)
    try:
        fld = session.findById('wnd[0]/usr/ctxtRM07M-RSNUM')
        fld.setFocus()
        try:
            fld.caretPosition = 0
        except Exception:
            pass
        session.findById('wnd[0]').sendVKey(5)
        time.sleep(0.9)
    except Exception:
        pass
    return _read()


def _mb21_fill_texts_and_save(session, items, fallback_text=None, purpose=None):
    """MB21을 저장하되, SAP이 "필수 입력"으로 되물으면 그 화면에서 바로 채우고 다시 저장한다.

    ⚠️⚠️ [2026-10-02 두 번 데인 자리] 처음엔 "btn[11] → 텍스트 → btn[19] 다음품목 → btn[3] → F11"
      이라는 **고정 순서**로 짰다가 두 번 실패했다.
        1차: "The virtual key is not enabled" — 필수 입력이 비어 저장키가 잠김
        2차: "유효한 기능을 선택하십시오" — `tbar[0]/btn[11]`이 SAP 표준에서 **저장**이라,
             텍스트를 다 채운 순간 거기서 이미 저장이 끝났는데 뒤에서 F11을 또 보냄
      화면 전환 순서를 코드가 미리 안다고 가정한 게 잘못이었다. 그래서 **SAP이 지금 무엇을
      요구하는지 읽고 거기에 반응하는 루프**로 바꿨다:

        저장 시도 → 상태바 확인
          ├ 예약번호가 보이면            → 끝
          ├ 텍스트(RESB-SGTXT) 칸이 보이면 → 그 화면의 자재번호로 사유를 찾아 채우고 Enter → 다시 저장
          └ 그 외                        → 상태바 문구를 그대로 담아 중단

      화면이 몇 번 바뀌든, 품목 순서가 어떻든 상관없다(자재번호로 짝을 찾으므로).
    반환: (rsnum, warning) — rsnum이 None이면 warning에 사유.
    """
    def _norm(m):
        return str(m or '').strip().lstrip('0')

    by_mat = {}
    for it in (items or []):
        t = str((it or {}).get('sgtxt', '') or '').strip()
        if t:
            by_mat[_norm((it or {}).get('matnr'))] = t
    default_txt = (fallback_text or '').strip() or (next(iter(by_mat.values())) if by_mat else '')

    filled, last_sbar, popup_note = 0, '', ''
    max_rounds = len(items or []) * 3 + 8
    for _ in range(max_rounds):
        # ── 열린 팝업이 있으면 먼저 치운다 ───────────────────────────────────
        #   [2026-10-02] 코딩 블록(목적) 팝업이 안 닫힌 채 남으면 wnd[0]의 저장이 전부
        #   "유효한 기능을 선택하십시오"로 막힌다. 확인(Enter) → 확인버튼 → 취소(F12) 순으로 시도.
        pops = _sap_open_popups(session)
        if pops:
            popup_note = '열려 있던 팝업: ' + ', '.join(f'wnd[{i}]"{t}"' for i, t in pops)
            idx = pops[-1][0]
            for closer in ('btn0', 'enter', 'cancel'):   # ✓ 계속 버튼이 먼저(녹화 매크로 기준)
                try:
                    w = session.findById(f'wnd[{idx}]')
                except Exception:
                    break
                try:
                    if closer == 'enter':
                        w.sendVKey(0)
                    elif closer == 'btn0':
                        w.findById('tbar[0]/btn[0]').press()
                    else:
                        w.sendVKey(12)
                except Exception:
                    pass
                time.sleep(0.5)
                if not _sap_open_popups(session):
                    break

        # ── 저장 시도 (키가 잠겼으면 툴바 버튼으로) ──
        try:
            _sap_send_vkey(session, 11, fallback_btn='tbar[0]/btn[11]', step='MB21 저장')
        except Exception as e:
            # 저장키 자체가 막혔다면 보통 지금 화면에 못 채운 필수 입력이 있다는 뜻 — 아래에서 찾아본다
            print(f'[MB21] 저장 시도 실패(계속 진행): {e}', file=sys.stderr)
        time.sleep(1.1)

        last_sbar = _sap_status_text(session)
        rsnum = _mb21_extract_rsnum(last_sbar)
        if rsnum:
            return rsnum, None

        # ★★ [2026-10-02] **MB21이 초기화면(500)으로 돌아왔으면 저장이 끝난 것이다.**
        #    예전엔 이걸 모르고 거기서 또 저장을 보내 "유효한 기능을 선택하십시오"를 맞았다.
        #    예약번호는 상태바에 안 남을 수 있으므로 MB23에서 회수한다(사용자 설명: 직전 번호가 거기 남음).
        if _sap_screen_no(session) == '500':
            got = _mb21_read_last_rsnum(session)
            if got:
                return got, None
            return None, ('저장은 끝난 것으로 보입니다(MB21 초기화면으로 복귀). '
                          '다만 예약번호를 자동으로 읽지 못했습니다 — MB23(예약조회)에서 직접 확인한 뒤 '
                          '"<예약번호> 청구서 출력해줘"로 이어가 주세요.\n'
                          f'    상태바: "{last_sbar}"\n'
                          f'    화면: {_sap_screen_info(session)}')

        # ── SAP이 되물었다: 지금 화면에 텍스트 칸이 있나? ──
        try:
            wnd = session.findById('wnd[0]')
        except Exception as e:
            return None, f'SAP 화면을 읽지 못했습니다: {e}'
        fld = _find_by_id_substring(wnd, 'txtRESB-SGTXT')
        if fld is None:
            # 채울 것도 없고 되묻지도 않는다 = 더 보낼 게 없다. 저장이 이미 끝났을 수 있으니
            # 예약번호를 한 번 더 회수해 본다(화면번호가 500이 아니어도 완료 화면일 수 있다).
            got = _mb21_read_last_rsnum(session)
            if got:
                return got, None
            return None, (f'저장이 끝나지 않았고 텍스트 입력칸도 없습니다.\n'
                          f'    상태바: "{last_sbar}"\n'
                          f'    화면: {_sap_screen_info(session)}'
                          + (f'\n    {popup_note}' if popup_note else ''))

        # 이 화면이 어느 품목인지 — 자재번호로 짝을 찾는다(품목 순서에 의존하지 않음)
        mat = ''
        mfld = _find_by_id_substring(wnd, 'ctxtRESB-MATNR')
        if mfld is not None:
            try:
                mat = _norm(mfld.Text)
            except Exception:
                mat = ''
        txt = by_mat.get(mat) or default_txt
        if not txt:
            return None, (f'자재 {mat or "?"}의 사유(텍스트)가 비어 있어 저장할 수 없습니다. '
                          f'(상태바: "{last_sbar}")')
        try:
            if str(fld.Text or '').strip() == txt:
                # 이미 같은 값이 들어 있는데도 또 물어본다 = 다른 필수 항목이 비었다는 뜻
                return None, (f'자재 {mat or "?"}에 사유를 넣었는데도 SAP이 계속 되묻습니다 — '
                              f'다른 필수 항목이 비어 있을 수 있습니다.\n'
                              f'    상태바: "{last_sbar}"\n'
                              f'    화면: {_sap_screen_info(session)}')
            fld.text = txt
            wnd.sendVKey(0)
            time.sleep(0.5)
            filled += 1
        except Exception as e:
            return None, f'자재 {mat or "?"} 텍스트 입력 실패: {e} (앞 {filled}건 입력됨)'

    return None, (f'저장을 {max_rounds}회 시도했지만 예약번호를 받지 못했습니다.\n'
                  f'    상태바: "{last_sbar}" (텍스트 {filled}건 입력됨)\n'
                  f'    화면: {_sap_screen_info(session)}')


def _mb21_set_purpose(session, purpose):
    """MB21 신규품목 화면에서 " 기타"(COBL_MORE) → "코딩 블록" 팝업의 **목적**(YYDEVTYPE)을 채운다.

    [2026-10-02 사용자 확인] 오더·코스트센터만으로는 부족하고 "기타"까지 필수 선택이다.
    목적 값은 ZMM019 결과의 YYDEVTYPE 컬럼으로 그대로 나온다(P01 유상샘플 … P05 기타).
    ⚠️ 팝업(wnd[1]) 안 필드의 정확한 id는 아직 덤프로 확인되지 않았다(덤프가 8초 제한에 걸려
       wnd[1]까지 못 갔다) — 그래서 'YYDEVTYPE' 부분일치로 찾는다. 실패해도 예외로 죽이지 않고
       사유를 돌려주어 호출부가 "목적 미입력"을 사람에게 알릴 수 있게 한다.
    """
    if not purpose:
        return None
    try:
        wnd = session.findById('wnd[0]')
        btn = _find_by_id_substring(wnd, 'btnCOBL_MORE')
        if btn is None:
            return 'COBL_MORE(" 기타") 버튼을 찾지 못했습니다.'
        btn.press()
        time.sleep(0.8)
    except Exception as e:
        return f'" 기타" 버튼 클릭 실패: {e}'

    # ✅ [2026-10-02 녹화 매크로로 확정] 코딩 블록 팝업의 목적 필드 절대경로:
    #      wnd[1]/usr/subBLOCK1:SAPLKACB:9999/ctxtCOBL-YYDEVTYPE
    #    절대경로를 먼저 쓰고, 화면 구성이 다를 때만 부분일치로 폴백한다.
    fld = None
    try:
        fld = session.findById('wnd[1]/usr/subBLOCK1:SAPLKACB:9999/ctxtCOBL-YYDEVTYPE')
    except Exception:
        fld = None
    if fld is None:
        for wid in ('wnd[1]', 'wnd[0]'):
            try:
                w = session.findById(wid)
            except Exception:
                continue
            for cand in _find_all_by_id_substring(w, 'YYDEVTYPE'):
                try:
                    if str(getattr(cand, 'Type', '')) in ('GuiCTextField', 'GuiTextField') and cand.Changeable:
                        fld = cand
                        break
                except Exception:
                    continue
            if fld is not None:
                break
    if fld is None:
        # 팝업을 열어만 두고 못 채우면 이후 저장이 막히므로 닫고 사유를 돌려준다
        try:
            session.findById('wnd[1]').sendVKey(12)   # 취소
        except Exception:
            pass
        return '코딩 블록에서 "목적"(YYDEVTYPE) 입력칸을 찾지 못했습니다.'
    try:
        fld.text = str(purpose).strip()
    except Exception as e:
        return f'"목적" 입력 실패: {e}'

    # ⚠️ [2026-10-02 녹화 매크로로 확정] 코딩 블록은 **wnd[1]/tbar[0]/btn[0](✓ 계속)**으로 닫는다.
    #    Enter가 아니다 — Enter를 먼저 보내면 F4 검색도움이 뜨거나 아무 일도 안 일어나고,
    #    팝업이 열린 채 남아 이후 wnd[0] 저장이 전부 "유효한 기능을 선택하십시오"로 막힌다.
    for closer in ('btn0', 'enter', 'cancel'):
        pops = _sap_open_popups(session)
        if not pops:
            return None
        idx = pops[-1][0]
        try:
            w = session.findById(f'wnd[{idx}]')
            if closer == 'enter':
                w.sendVKey(0)
            elif closer == 'btn0':
                w.findById('tbar[0]/btn[0]').press()
            else:
                w.sendVKey(12)
        except Exception:
            pass
        time.sleep(0.6)
    pops = _sap_open_popups(session)
    if pops:
        return ('코딩 블록 팝업이 닫히지 않았습니다: '
                + ', '.join(f'wnd[{i}]"{t}"' for i, t in pops))
    return None


def create_reservation(items, bwart='951', order_number=None, cost_center=None,
                       werks='1000', lgort_default=None, rsdat=None, wempf=None, text=None,
                       purpose=None):
    """MB21 예약(계정대체 청구서) 생성 — 전기(MIGO)는 하지 않는다.

    [2026-10-02 신규, 사용자 요청] 자재 보관함(js/35)에 담아둔 자재를 모아 한 번에 청구서를
    만들기 위한 진입점. 사용자 확인: **최종 산출물은 ZMM019(계정대체청구서) PDF이고 MIGO는
    거의 쓰지 않는다** — 그래서 예약 생성에서 끝낸다.

    bwart: 951=연구개발 출고(자재청구) / 907=개발 입고(자재반납). 기본 저장위치는 호출부가
           lgort_default로 넘긴다(951→1000, 907→5000 — js/32 SAP_MB21_MOVEMENT_TYPES가 원본).
    items: [{matnr, qty, unit?, lgort?}] — MB21 신규품목 화면(521)은 **한 화면에 28행**이므로
           그보다 많으면 호출부가 나눠서 여러 번 부른다(js/35가 분할 처리).
    order_number/cost_center: 오더·코스트센터 모두 필수(사용자 확인).

    ⚠️ 실제 SAP 예약이 생성된다 — 사람이 확인한 뒤에만 호출할 것.
    반환: {ok, rsnum, bwart, itemCount, text}
    """
    if not items:
        raise RuntimeError('자재 목록(items)이 비어 있습니다.')
    if not order_number:
        raise RuntimeError('오더번호(order_number)를 지정해주세요.')
    if lgort_default is None:
        lgort_default = '1000' if str(bwart) == '951' else '5000'

    session = _get_sap_session()
    _sap_close_stray_popups(session)
    posting_date = str(rsdat or time.strftime('%Y%m%d'))

    # ── Phase 1: MB21 반납 예약 생성 (이동유형 907) ───────────────────────────
    nav_ok = False
    try:
        session.findById(
            'wnd[0]/usr/cntlIMAGE_CONTAINER/shellcont/shell/shellcont[0]/shell'
        ).doubleClickNode('F00150')
        time.sleep(1.0)
        nav_ok = True
    except Exception:
        pass
    if not nav_ok:
        session.findById('wnd[0]/tbar[0]/okcd').text = '/nMB21'
        session.findById('wnd[0]').sendVKey(0)
        time.sleep(1.0)

    wnd = session.findById('wnd[0]')
    _set_text_on_best_candidate(wnd, 'RM07M-RSDAT', posting_date)
    _set_text_on_best_candidate(wnd, 'RM07M-BWART', str(bwart))
    _set_text_on_best_candidate(wnd, 'RM07M-WERKS', werks)

    try:
        session.findById('wnd[0]/tbar[1]/btn[7]').press()
    except Exception as e:
        raise RuntimeError(f'MB21 다음 화면(계정지정) 이동 실패: {e}')
    time.sleep(1.0)

    wnd = session.findById('wnd[0]')
    sbar_check = ''
    try:
        sbar_check = (session.findById('wnd[0]/sbar').Text or '').strip()
    except Exception:
        pass
    if sbar_check and ('오류' in sbar_check or '필수' in sbar_check):
        raise RuntimeError(f'MB21 화면 이동 중 오류: {sbar_check}')

    # 원가센터
    if cost_center:
        try:
            _set_text_on_best_candidate(wnd, 'COBL-KOSTL', cost_center)
            wnd.sendVKey(0)
            time.sleep(0.3)
        except Exception:
            pass
    else:
        # F4 → 첫번째 항목 (VBS line 65-68)
        try:
            kostl_fld = None
            for cand in _find_all_by_id_substring(wnd, 'COBL-KOSTL'):
                if str(getattr(cand, 'Type', '')) in ('GuiCTextField', 'GuiTextField') and cand.Changeable:
                    kostl_fld = cand
                    break
            if kostl_fld:
                kostl_fld.setFocus()
                kostl_fld.caretPosition = 0
                wnd.sendVKey(4)
                time.sleep(0.8)
                try:
                    session.findById('wnd[1]/usr/lbl[1,3]').caretPosition = 9
                    session.findById('wnd[1]').sendVKey(2)
                    time.sleep(0.4)
                except Exception:
                    try:
                        session.findById('wnd[1]').sendVKey(12)
                    except Exception:
                        pass
        except Exception:
            pass

    # 내부오더
    wnd = session.findById('wnd[0]')
    aufnr_fld = None
    for cand in _find_all_by_id_substring(wnd, 'COBL-AUFNR'):
        if str(getattr(cand, 'Type', '')) in ('GuiCTextField', 'GuiTextField') and cand.Changeable:
            aufnr_fld = cand
            break
    if aufnr_fld is None:
        raise RuntimeError('MB21에서 내부오더(COBL-AUFNR) 입력칸을 찾지 못했습니다.')
    aufnr_fld.text = str(order_number)
    aufnr_fld.setFocus()
    wnd.sendVKey(0)
    time.sleep(0.5)

    # 수령인
    if wempf:
        try:
            _set_text_on_best_candidate(wnd, 'WEMPF', wempf)
        except Exception:
            pass

    # YYDEVTYPE (개발유형) — F4 첫번째 항목 (VBS lines 131-136)
    try:
        wnd = session.findById('wnd[0]')
        more_btn = _find_by_id_substring(wnd, 'COBL_MORE')
        if more_btn:
            more_btn.press()
            time.sleep(0.8)
            wnd1 = session.findById('wnd[1]')
            devtype_fld = None
            try:
                devtype_fld = _find_by_id_substring(wnd1, 'YYDEVTYPE')
            except Exception:
                pass
            if devtype_fld and devtype_fld.Changeable:
                devtype_fld.setFocus()
                devtype_fld.caretPosition = 0
                wnd1.sendVKey(4)
                time.sleep(0.8)
                try:
                    session.findById('wnd[2]').sendVKey(2)  # 첫번째 선택
                    time.sleep(0.4)
                except Exception:
                    try:
                        session.findById('wnd[2]').sendVKey(12)
                    except Exception:
                        pass
            try:
                session.findById('wnd[1]/tbar[0]/btn[0]').press()
                time.sleep(0.5)
            except Exception:
                try:
                    session.findById('wnd[1]').sendVKey(0)
                except Exception:
                    pass
    except Exception:
        pass

    # 🎯 [2026-10-02] 목적(YYDEVTYPE) — " 기타" → 코딩 블록 팝업. 실패해도 멈추지 않고 사유만 모은다.
    purpose_warn = _mb21_set_purpose(session, purpose)
    if purpose_warn:
        print(f'[MB21 목적 미입력] {purpose_warn}', file=sys.stderr)

    # 자재 입력 (VBS lines 137-199: RESB-MATNR/ERFMG/ERFME/LGORT 테이블)
    wnd = session.findById('wnd[0]')
    sub_path = 'usr/sub:SAPMM07R:0521/'
    for i, item in enumerate(items):
        matnr = str(item.get('matnr', '')).strip()
        qty   = str(item.get('qty', '')).strip()
        unit  = str(item.get('unit', 'EA')).strip()
        ilgort = str(item.get('lgort', lgort_default)).strip()
        if not matnr or not qty:
            continue
        for fld_path, val in [
            (f'{sub_path}ctxtRESB-MATNR[{i},7]',  matnr),
            (f'{sub_path}txtRESB-ERFMG[{i},26]',  qty),
            (f'{sub_path}ctxtRESB-ERFME[{i},44]', unit),
            (f'{sub_path}ctxtRESB-LGORT[{i},53]', ilgort),
        ]:
            try:
                fld = wnd.findById(fld_path)
                fld.text = val
            except Exception:
                try:
                    _set_text_on_best_candidate(wnd, fld_path.split('/')[-1].split('[')[0], val)
                except Exception:
                    pass

    wnd.sendVKey(0)
    time.sleep(0.5)

    # 저장 — SAP이 "필수 입력"으로 되물으면 그 화면에서 채우고 다시 저장하는 자기교정 루프.
    #   (고정 순서로 짰다가 "virtual key not enabled" / "유효한 기능을 선택하십시오"로 두 번 실패)
    rsnum, text_warn = _mb21_fill_texts_and_save(session, items, fallback_text=text, purpose=purpose)
    if not rsnum:
        raise RuntimeError(
            'MB21 저장을 끝내지 못했습니다.\n  ' + (text_warn or '사유 불명')
            + (f'\n  목적(YYDEVTYPE) 입력 경고: {purpose_warn}' if purpose_warn else '')
            + '\n  확인할 것: 품목별 사유(텍스트) · 오더 · 코스트센터 · 목적(기타 코딩블록)'
            + '\n  💡 SAP 화면을 그대로 둔 채 "SAP 화면 덤프해줘"를 실행하면 지금 멈춘 화면을'
              ' 그대로 볼 수 있습니다(팝업부터 덤프됩니다).')
    sbar_save = _sap_status_text(session)

    return {
        'ok': True, 'rsnum': rsnum, 'bwart': str(bwart),
        'itemCount': len([i for i in items if str(i.get('matnr', '')).strip()]),
        'purpose': purpose or '', 'purposeWarning': purpose_warn or '',
        'textWarning': text_warn or '',
        'sbar': sbar_save,
        'text': (f'예약(계정대체청구서) 생성 완료 — 예약번호 {rsnum} '
                 f'(이동유형 {bwart}, 품목 {len(items)}건). ZMM019에서 PDF로 출력하세요.'),
    }


def migo_return_receipt(items, order_number, cost_center=None, werks='1000',
                         lgort_default='5000', text=None, rsdat=None, bwart='907',
                         wempf=None):
    """반납 입고 전체 자동화: MB21 반납 예약(이동유형 907) 생성 + F00151 실전기.
    실사용 VBS "반납입고.vbs" 기반(2026-10-01).
    ⚠️ 실제 SAP 전기(재고/회계 영향) — 사람이 확인 후 호출할 것.

    items: [{matnr, qty, unit?, lgort?}]  ex) [{'matnr':'502573','qty':'2','unit':'EA'}]
    order_number: 내부오더번호 (직접 입력, 필수)
    cost_center: 원가센터 (None이면 F4 첫번째)
    lgort_default: items에 lgort 없을 때 기본 저장위치
    text: 품목텍스트 (ex. 'LNW>STELLAR_32>PROTO B 반납')
    rsdat: 전기일자 YYYYMMDD (None이면 오늘)
    반환: {ok, rsnum, material_document, text}
    """
    if not items:
        raise RuntimeError('자재 목록(items)이 비어 있습니다.')
    if not order_number:
        raise RuntimeError('내부오더번호(order_number)를 지정해주세요.')

    # [2026-10-02 리팩터링] MB21 예약 생성 부분은 create_reservation으로 옮겼다 —
    #   자재 보관함(자재청구/자재입고 청구서)과 이 반납입고가 같은 MB21 조작을 쓰기 때문.
    #   동작은 그대로이고, 아래 Phase 2(F00151 실전기)는 이 함수에만 남는다.
    posting_date = str(rsdat or time.strftime('%Y%m%d'))
    _res = create_reservation(items, bwart=bwart, order_number=order_number,
                              cost_center=cost_center, werks=werks,
                              lgort_default=lgort_default, rsdat=posting_date,
                              wempf=wempf, text=text, purpose=None)
    rsnum = _res['rsnum']
    session = _get_sap_session()

    # ── Phase 2: 예약 기반 실전기 (F00151) ───────────────────────────────────
    result = _migo_post_by_reservation(session, rsnum, posting_date)
    result['rsnum'] = rsnum
    return result


_RSV_PDF_OUT_DIR = os.path.join('C:\\SAP_DMS', '자재청구')


def _win_documents_dir():
    """Windows '문서' 폴더의 실제 경로 — 한글 Windows·폴더 리디렉션까지 대응.

    Adobe PDF 프린터의 기본 출력 위치가 `Documents\\*.pdf`라(사용자 캡처 2026-10-02)
    새로 생긴 PDF를 여기서 찾아야 한다. `~/Documents` 추측은 OneDrive 리디렉션에서
    틀리므로 셸 API(CSIDL_PERSONAL)를 먼저 쓴다.
    """
    try:
        import ctypes as _ct
        buf = _ct.create_unicode_buffer(260)
        # CSIDL_PERSONAL(5) = 내 문서, SHGFP_TYPE_CURRENT(0)
        _ct.windll.shell32.SHGetFolderPathW(None, 5, None, 0, buf)
        if buf.value:
            return buf.value
    except Exception:
        pass
    return os.path.join(os.path.expanduser('~'), 'Documents')


def _pdf_snapshot(dirs):
    """감시 폴더들의 현재 .pdf 목록(절대경로 set)."""
    seen = set()
    for d in dirs:
        try:
            for n in os.listdir(d):
                if n.lower().endswith('.pdf'):
                    seen.add(os.path.join(d, n))
        except Exception:
            pass
    return seen


def _wait_new_pdf(dirs, before, timeout_sec=60):
    """스냅샷 이후 새로 생긴 PDF 1개를 기다렸다가 경로를 돌려준다.

    Adobe PDF Converter는 비동기로 파일을 쓴다 — 생기자마자 가져가면 0바이트거나
    쓰는 중인 파일을 잡는다. 그래서 크기가 멈출 때까지 한 번 더 기다린다.
    """
    deadline = time.time() + timeout_sec
    while time.time() < deadline:
        fresh = list(_pdf_snapshot(dirs) - before)
        if fresh:
            try:
                fresh.sort(key=lambda x: os.path.getmtime(x), reverse=True)
            except Exception:
                pass
            cand, last = fresh[0], -1
            for _ in range(40):          # 최대 ~12초 동안 크기 안정화 대기
                try:
                    sz = os.path.getsize(cand)
                except Exception:
                    sz = -1
                if sz > 0 and sz == last:
                    return cand
                last = sz
                time.sleep(0.3)
            return cand
        time.sleep(0.5)
    return None


def _win_print_dialog_watchdog(save_path, timeout_sec=120):
    """Windows 네이티브 인쇄 대화상자를 대신 눌러주는 워치독(별도 스레드).

    [2026-10-02] ZMM019 "청구서출력"이 띄우는 인쇄 창은 **SAP 창이 아니다** —
    클래스 `#32770`의 Win32 대화상자라 `wnd[1]`로 안 잡히고, 모달이 떠 있는 동안
    SAP COM 호출(press)이 블록된다. 그래서 메인 스레드가 press()에 묶여 있는 사이
    이 스레드가 창을 눌러준다. (같은 Win32 기법을 이 파일의 DMS "사본 저장" 처리에서
    이미 쓰고 있다 — 새 기법이 아니다.)

    ① "인쇄"(#32770) → [확인]
    ② 이어서 Adobe 파일 저장 창이 뜨면 → save_path 입력 후 [저장]
       프린터 속성이 '파일 이름을 묻지 않음'이면 ②는 아예 안 뜨고, 그게 가장 안전한
       상태다(건드릴 창이 하나로 줄어든다). 그래서 ②가 없는 것은 실패가 아니다.

    반환: (thread, state) — state는 스레드가 채우는 dict
    """
    import win32gui as _wg
    import win32con as _wc

    state = {'printClicked': False, 'usedSaveDialog': False,
             'printTitle': '', 'saveTitle': '', 'error': ''}

    def _buttons(hwnd):
        """대화상자 안의 Button 컨트롤을 [(hwnd, 라벨)]로."""
        out = []

        def _cb(ch, _):
            try:
                if _wg.GetClassName(ch) == 'Button':
                    out.append((ch, (_wg.GetWindowText(ch) or '').replace('&', '').strip()))
            except Exception:
                pass
        try:
            _wg.EnumChildWindows(hwnd, _cb, None)
        except Exception:
            pass
        return out

    def _find_dialog(titles, btn_labels):
        """제목과 **버튼 라벨을 둘 다** 만족하는 #32770만 고른다.

        제목만으로 고르면 엉뚱한 창의 [확인]을 눌러버릴 수 있다.
        """
        hits = []

        def _cb(hwnd, _):
            try:
                if _wg.GetClassName(hwnd) != '#32770' or not _wg.IsWindowVisible(hwnd):
                    return
                t = (_wg.GetWindowText(hwnd) or '').strip()
                if not any(k in t for k in titles):
                    return
                for bh, bl in _buttons(hwnd):
                    if bl in btn_labels:
                        hits.append((hwnd, t, bh))
                        return
            except Exception:
                pass

        try:
            _wg.EnumWindows(_cb, None)
        except Exception:
            pass
        return hits[0] if hits else None

    def _filename_edit(hwnd):
        """파일 저장 대화상자의 '파일 이름' Edit 컨트롤.

        구조: 대화상자 → ComboBoxEx32 → ComboBox → Edit.
        y좌표 내림차순 정렬 후 두 번째가 파일이름 — 이 파일의 DMS 저장 코드에서
        이미 실사용 검증된 규칙을 그대로 쓴다.
        """
        found = []

        def _cb(ch, _):
            try:
                if _wg.GetClassName(ch) == 'Edit':
                    found.append((ch, _wg.GetWindowRect(ch)[3]))
            except Exception:
                pass
        try:
            _wg.EnumChildWindows(hwnd, _cb, None)
        except Exception:
            pass
        found.sort(key=lambda x: x[1], reverse=True)
        if len(found) >= 2:
            return found[1][0]
        return found[0][0] if found else None

    def _cancel(hwnd):
        """대화상자를 [취소]로 닫는다 — 실패하고 그냥 빠져나가면 모달이 남아
        SAP COM 호출이 계속 블록되고, 다음 요청까지 전부 막힌다."""
        for bh, bl in _buttons(hwnd):
            if bl in ('취소', 'Cancel'):
                try:
                    _wg.SendMessage(bh, _wc.BM_CLICK, 0, 0)
                    return True
                except Exception:
                    pass
        try:                               # 버튼을 못 찾으면 창 닫기로
            _wg.PostMessage(hwnd, _wc.WM_CLOSE, 0, 0)
            return True
        except Exception:
            return False

    def _run():
        deadline = time.time() + timeout_sec

        # ① 인쇄 대화상자 → [확인]
        while time.time() < deadline:
            hit = _find_dialog(('인쇄', 'Print'), ('확인', 'OK', '인쇄', 'Print'))
            if hit:
                hwnd, title, btn = hit
                state['printTitle'] = title
                try:
                    _wg.SendMessage(btn, _wc.BM_CLICK, 0, 0)
                    state['printClicked'] = True
                except Exception as e:
                    state['error'] = '인쇄 대화상자 [확인] 클릭 실패: %s' % e
                    return
                break
            time.sleep(0.4)
        if not state['printClicked']:
            state['error'] = '인쇄 대화상자를 찾지 못했습니다(%d초 대기).' % timeout_sec
            return

        # ② 파일 저장 창 — 프린터가 '파일 이름 묻기'로 설정된 경우에만 뜬다.
        sub_deadline = time.time() + 10
        while time.time() < sub_deadline:
            hit = _find_dialog(('저장', 'Save', 'PDF'), ('저장', 'Save'))
            if hit:
                hwnd, title, btn = hit
                state['saveTitle'] = title
                edit = _filename_edit(hwnd)
                if edit is None:
                    _cancel(hwnd)
                    state['error'] = ('파일 저장 창("%s")에서 파일이름 칸을 찾지 못해 '
                                      '취소했습니다.' % title)
                    return
                ok = False
                try:                     # ⓐ WM_SETTEXT — 포커스와 무관하게 값을 박는다
                    _wg.SendMessage(edit, _wc.WM_SETTEXT, 0, save_path)
                    time.sleep(0.2)
                    ok = (_wg.GetWindowText(edit) or '').strip().lower() == save_path.lower()
                except Exception:
                    ok = False
                if not ok:               # ⓑ 타이핑 폴백(DMS 저장 코드와 동일한 방식)
                    try:
                        import ctypes as _ct
                        import win32process as _wp
                        from pywinauto.keyboard import send_keys as _sk
                        dlg_tid, _unused = _wp.GetWindowThreadProcessId(hwnd)
                        my_tid = _ct.windll.kernel32.GetCurrentThreadId()
                        _ct.windll.user32.AttachThreadInput(my_tid, dlg_tid, True)
                        _ct.windll.user32.SetForegroundWindow(hwnd)
                        time.sleep(0.2)
                        _ct.windll.user32.SetFocus(edit)
                        time.sleep(0.2)
                        _ct.windll.user32.AttachThreadInput(my_tid, dlg_tid, False)
                        _sk('^a')
                        time.sleep(0.1)
                        # pywinauto send_keys 특수문자 이스케이프
                        _sk(re.sub(r'([{}+^%()~])', r'{\1}', save_path), with_spaces=True)
                        time.sleep(0.3)
                    except Exception as e:
                        _cancel(hwnd)
                        state['error'] = '파일 이름 입력 실패(취소했습니다): %s' % e
                        return
                try:
                    _wg.SendMessage(btn, _wc.BM_CLICK, 0, 0)
                    state['usedSaveDialog'] = True
                except Exception as e:
                    _cancel(hwnd)
                    state['error'] = '파일 저장 창 [저장] 클릭 실패(취소했습니다): %s' % e
                return
            time.sleep(0.4)

    th = threading.Thread(target=_run, name='zmm019-print-watchdog')
    th.daemon = True
    th.start()
    return th, state


def print_reservation_zmm019(rsnum, werks='1000', rsdat=None):
    """🖨 ZMM019(자재 예약 리스트)에서 예약번호로 조회한 뒤 "청구서출력"을 눌러 계정대체청구서를 낸다.

    [2026-10-02 실화면 덤프] 선택화면(1000): RSNUM-LOW/HIGH, WERKS-LOW, R_ALL/R_ME …
    결과화면(100): ALV 그리드 + tbar[1]/btn[13]=" 청구서출력", btn[14]="REFRESH".
    사용자 확인: **계정대체 청구의 최종 산출물이 이 PDF다**(MIGO는 거의 쓰지 않음).

    반환: {ok, rsnum, rowCount, table, sbar, text}
    """
    rsnum = str(rsnum or '').strip()
    if not rsnum:
        raise RuntimeError('예약번호(rsnum)를 지정해주세요.')

    session = _get_sap_session()
    _sap_close_stray_popups(session)
    wnd = session.findById('wnd[0]')
    session.findById('wnd[0]/tbar[0]/okcd').text = '/nZMM019'
    wnd.sendVKey(0)
    time.sleep(1.2)
    wnd = session.findById('wnd[0]')

    def _set(fid, val):
        try:
            wnd.findById('usr/' + fid).text = val
            return True
        except Exception:
            return False

    # 예약번호만으로 좁힌다 — 다른 선택조건이 남아 있으면 0건이 될 수 있어 비운다
    _set('txtRSNUM-LOW', rsnum)
    _set('txtRSNUM-HIGH', '')
    # 녹화 매크로는 요청일(RSDAT)에 당일을 넣는다 — 비워두면 0건이 나오는 계정이 있을 수 있어
    # 호출부가 준 날짜(없으면 오늘)를 넣고, HIGH는 비워 단일일자로 둔다.
    _set('ctxtRSDAT-LOW', str(rsdat or time.strftime('%Y%m%d')))
    _set('ctxtRSDAT-HIGH', '')
    _set('txtWEMPF-LOW', '');   _set('txtWEMPF-HIGH', '')
    _set('ctxtMATNR-LOW', '');  _set('ctxtMATNR-HIGH', '')
    _set('ctxtBWART-LOW', '');  _set('ctxtBWART-HIGH', '')
    _set('ctxtKOSTL-LOW', '');  _set('ctxtKOSTL-HIGH', '')
    _set('ctxtS_AUFNR-LOW', ''); _set('ctxtS_AUFNR-HIGH', '')
    if werks:
        _set('ctxtWERKS-LOW', str(werks).strip())
    try:
        wnd.findById('usr/radR_ALL').select()      # 전체(미출자재만 보기 R_ME 아님)
    except Exception:
        pass

    wnd.findById('tbar[1]/btn[8]').press()         # 실행(F8)
    time.sleep(1.8)
    wnd = session.findById('wnd[0]')

    grid = _sap_find_grid(wnd)
    table, row_count = '', None
    if grid is not None:
        table = _sap_dump_grid(grid)
        try:
            row_count = int(grid.RowCount)
        except Exception:
            row_count = None
    if not row_count:
        sbar0 = ''
        try:
            sbar0 = (session.findById('wnd[0]/sbar').Text or '').strip()
        except Exception:
            pass
        raise RuntimeError(f'ZMM019에서 예약번호 {rsnum} 조회 결과가 없습니다. (상태바: "{sbar0}")')

    # ★★ [2026-10-02 녹화 매크로로 확정] **행을 먼저 선택해야** 청구서출력이 동작한다.
    #    `selectedRows = "0"` 한 줄이 빠져서 출력이 안 먹던 것 — 같은 패턴이 이 파일의
    #    `display_reservation` 쪽에 이미 있었는데 여기선 빠뜨렸다.
    row_warn = None
    try:
        if grid is not None:
            try:
                grid.currentCellColumn = ''
            except Exception:
                pass
            grid.selectedRows = '0'
            time.sleep(0.4)
        else:
            row_warn = '결과 그리드를 찾지 못해 행을 선택하지 못했습니다.'
    except Exception as e:
        row_warn = f'행 선택 실패: {e}'

    # ── PDF 회수 준비 ──────────────────────────────────────────────
    #   Adobe PDF가 어디에 쓰든 잡아내려고 **누르기 전에** 폴더 스냅샷을 찍는다.
    try:
        if not os.path.isdir(_RSV_PDF_OUT_DIR):
            os.makedirs(_RSV_PDF_OUT_DIR)
    except Exception:
        pass
    pdf_target = os.path.join(_RSV_PDF_OUT_DIR,
                              '예약%s_%s.pdf' % (rsnum, time.strftime('%Y%m%d')))
    watch_dirs = [d for d in (_RSV_PDF_OUT_DIR, _win_documents_dir()) if d]
    pdf_before = _pdf_snapshot(watch_dirs)

    # 청구서출력
    # ★ [2026-10-02] 이 버튼이 띄우는 인쇄 창은 **Windows 네이티브(#32770)** 라
    #   SAP 스크립팅으로는 못 누른다. 게다가 모달이 떠 있는 동안 press()가 블록되므로
    #   **누르기 전에** 눌러줄 워치독 스레드를 먼저 띄워야 한다.
    pr_th, pr_state = _win_print_dialog_watchdog(pdf_target, timeout_sec=120)
    try:
        wnd.findById('tbar[1]/btn[13]').press()
        time.sleep(2.0)
    except Exception as e:
        raise RuntimeError(f'ZMM019 "청구서출력" 버튼을 누르지 못했습니다: {e}'
                           + (f' ({row_warn})' if row_warn else ''))

    # SAP 자체 인쇄 팝업(뜨는 계정만) — 녹화 매크로: wnd[1]/tbar[0]/btn[13] → btn[86].
    for _btn in ('tbar[0]/btn[13]', 'tbar[0]/btn[86]'):
        try:
            session.findById('wnd[1]/' + _btn).press()
            time.sleep(1.0)
        except Exception:
            break

    pr_th.join(timeout=125)

    sbar = ''
    try:
        sbar = (session.findById('wnd[0]/sbar').Text or '').strip()
    except Exception:
        pass

    # ⚠️ 인쇄 대화상자를 못 눌렀으면 **성공이라고 하지 않는다**.
    #   예전에는 wnd[1]을 못 찾으면 조용히 break하고 ok:True로 "출력했습니다"가 나가서,
    #   화면에 인쇄 창이 그대로 떠 있는데도 모달은 초록으로 끝났다(2026-10-02 제보).
    if not pr_state.get('printClicked'):
        raise RuntimeError(
            f'예약번호 {rsnum} 조회는 됐지만(품목 {row_count}건) 인쇄를 끝내지 못했습니다. '
            + (pr_state.get('error') or '')
            + ' SAP 화면에 Windows "인쇄" 창이 떠 있으면 거기서 [확인]을 눌러주세요.'
            + (f' (상태바: {sbar})' if sbar else ''))

    # ── PDF 회수 ───────────────────────────────────────────────────
    pdf_path, pdf_note = '', ''
    if pr_state.get('usedSaveDialog'):
        # 저장 창에 경로를 직접 넣었으니 그 자리에 생겨야 한다
        for _ in range(60):
            try:
                if os.path.getsize(pdf_target) > 0:
                    pdf_path = pdf_target
                    break
            except Exception:
                pass
            time.sleep(0.5)
        if not pdf_path:
            # 설정 안내는 **실패했을 때만** — 매번 띄우면 잔소리가 된다.
            pdf_note = ('파일 저장 창에 경로는 넣었는데 파일이 안 생겼습니다. Adobe PDF 속성에서 '
                        '"PDF 파일 이름을 묻습니다"를 끄고 출력 폴더를 고정하면 건드릴 창이 '
                        '하나로 줄어 더 안정적입니다.')
    else:
        got = _wait_new_pdf(watch_dirs, pdf_before, timeout_sec=60)
        if got:
            if os.path.abspath(got).lower() == os.path.abspath(pdf_target).lower():
                pdf_path = got
            else:
                try:
                    import shutil
                    if os.path.exists(pdf_target):
                        os.remove(pdf_target)
                    shutil.move(got, pdf_target)
                    pdf_path = pdf_target
                except Exception as e:
                    pdf_path = got          # 옮기지 못해도 원본 경로는 알려준다
                    pdf_note = f'파일명을 바꾸지 못해 원래 이름 그대로 둡니다: {e}'
    if not pdf_path:
        pdf_note = (('새로 생긴 PDF를 찾지 못했습니다 — 프린터가 Adobe PDF가 아니거나 '
                     '출력 폴더가 %s 밖일 수 있습니다.') % ' / '.join(watch_dirs)
                    + (' ' + pdf_note if pdf_note else ''))

    head = (f'예약번호 {rsnum} 계정대체청구서를 출력했습니다(품목 {row_count}건).'
            if pdf_path else
            f'⚠️ 예약번호 {rsnum} 인쇄는 넘겼지만 PDF 파일을 확인하지 못했습니다(품목 {row_count}건).')

    return {
        'ok': True, 'rsnum': rsnum, 'rowCount': row_count, 'table': table, 'sbar': sbar,
        'rowWarning': row_warn or '',
        'pdfPath': pdf_path, 'pdfNote': pdf_note,
        'printDialog': pr_state.get('printTitle') or '',
        'saveDialog': pr_state.get('saveTitle') or '',
        'text': (head
                 + (f'\n  ⚠️ {row_warn}' if row_warn else '')
                 + (f' (상태바: {sbar})' if sbar else '')
                 + (f'\n  📄 {pdf_path}' if pdf_path else '')
                 + (f'\n  ℹ️ {pdf_note}' if pdf_note else '')),
    }


def download_documents_by_pattern(pattern, doc_type='P01'):
    """자재내역 와일드카드 패턴으로 매치된 자재 전부의 문서를 다운로드한다 —
    `resolve_materials_by_description_pattern`으로 자재번호 목록을 구한 뒤, 이미 검증된
    `download_documents_batch`를 그대로 재사용한다. ZDMSR004의 "복수 선택" 팝업은 한
    화면에 보이는 입력 행이 7개까지만 실사용 확인됐고 8개 이상은 스크롤 코드는 있지만
    미검증이라(CLAUDE.md 참고), 매치가 많을 때는 7개씩 묶어 `download_documents_batch`를
    여러 번(ZDMSR004을 매번 새로 진입) 순차 호출해 이미 검증된 크기 안에서만 동작하게
    한다 — 느리지만 안전한 선택."""
    resolved = resolve_materials_by_description_pattern(pattern)
    if not resolved:
        return {
            'ok': True,
            'pattern': pattern,
            'materials': [],
            'docType': doc_type,
            'message': f'패턴 "{pattern}"에 매치되는 자재가 없습니다.',
        }

    materials = [m['matnr'] for m in resolved]
    chunk_size = 7
    all_results = []
    renamed_map = {}  # {문서번호: 새 폴더명} — 전체 청크 통합
    for i in range(0, len(materials), chunk_size):
        chunk = materials[i:i + chunk_size]
        result = download_documents_batch(chunk, doc_type)
        all_results.append(result)
        renamed_map.update(result.get('renamedFolders') or {})

    # ⚠️⚠️ [2026-09-16 실사용 버그수정] "와일드카드 패턴으로 9건이 매치돼 다운로드됐는데, 폴더가
    # 전부 문서번호(P01202101796류)라 애초에 물어본 패턴(예: *06+06*200*)의 어느 항목이 어느
    # 폴더인지, 같은 자재가 문서번호만 다르게 여러 개("내역(1)(2)")일 때 뭐가 뭔지 전혀 알 수
    # 없다"는 제보 — `download_documents_batch`가 이제 문서번호→자재번호 매핑을 확보해 폴더명을
    # <자재번호>_<문서번호>로 바꿔주므로(위 함수 참고), 여기서는 그 결과를 모아 패턴 검색으로
    # 이미 알고 있는 자재내역(desc)까지 같이 붙여 사람이 바로 알아볼 수 있는 요약 문구를 만든다.
    desc_by_matnr = {m['matnr']: m.get('desc', '') for m in resolved}
    lines = []
    for matnr in materials:
        desc = desc_by_matnr.get(matnr, '')
        folders = sorted(name for doknr, name in renamed_map.items() if name.startswith(matnr + '_'))
        folder_part = ', '.join(folders) if folders else '(폴더명 변경 실패 — 문서번호 폴더 그대로)'
        lines.append(f'{matnr}({desc}) → {folder_part}')
    mapping_summary = '\n'.join(lines)

    return {
        'ok': True,
        'pattern': pattern,
        'materials': materials,
        'matchDetails': resolved,
        'docType': doc_type,
        'chunks': len(all_results),
        'renamedFolders': renamed_map,
        'message': f'패턴 "{pattern}"에 매치된 자재 {len(materials)}건({", ".join(materials)})의 "{doc_type}" 문서를 C:\\SAP_DMS\\ 폴더로 다운로드했습니다. 자재별 매칭:\n{mapping_summary}',
    }


# ── "팀 운영비" 조회 (ZCO021, "코텍 예실레포트") 전용 헬퍼 (2026-09-22 신규) ──────
# 사용자가 직접 준 SAP GUI "기록 및 재생" 매크로(팀분영비.vbs)와 스크린샷 2장을 기반으로
# 구현. ⚠️⚠️ **실환경 미검증(unverified)** — 아래 두 부분은 매크로/스크린샷만으로는 100%
# 확신할 수 없어 실사용 테스트가 꼭 필요하다(추측 금지 원칙, docs/sap-lookup.md 참고):
#   ① 트랜잭션 진입 직후 뜨는 리포트(변형) 선택 팝업 — 매크로의 스크롤바 위치 이동(1~6~0)
#      + F2 시퀀스를 정확한 의미를 다 이해하지 못한 채 그대로 재현한다(실제로 성공했던
#      시퀀스이므로 "왜 되는지"보다 "그대로 재현하는" 쪽을 택함). 팝업이 없는 세션이면
#      try/except로 조용히 건너뛴다.
#   ② "550203 복리후생비-팀운영비(개발)" 행의 값 추출 — 이 화면은 표준 ALV 그리드가 아니라
#      GuiLabel 매트릭스로 렌더링되는 것으로 보여(매크로의 `lbl[97,3]` 같은 ID가 그 근거),
#      `_sap_dump_fields`로 화면의 모든 라벨을 순서대로 모은 뒤 "550203" 라벨을 찾아 그
#      뒤로 이어지는 라벨들을 값으로 읽는다. 계정명 라벨이 코드와 합쳐진 라벨인지 분리된
#      라벨인지 확신이 없어 `_sap_find_team_budget_row`가 두 경우 다 시도한다.
# 기간은 스크린샷에서 "기간시작=1, 기간종료=12"(연간 누적)로 고정 확인됨 — ctxtP_FPERBL/
# ctxtP_TPERBL은 매크로처럼 F4 드롭다운을 재현하지 않고, 같은 GuiCTextField 타입 필드를
# 이미 .text로 직접 설정하고 있는 fetch_where_used_batch의 ctxtP_WERKS와 동일한 방식으로
# 단순화했다(더 안정적).
# 팀 목록(개발1팀/개발2팀/개발3팀/시제품팀)은 코스트 센터 트리 노드 텍스트에 그대로 들어
# 있음이 스크린샷으로 확인됨("1008E030 개발3팀(판)") — 그래서 고정 노드키("000004") 대신
# 트리를 전부 훑어 팀 이름이 포함된 노드를 찾는다(팀이 늘어나도 코드 변경 불필요).
_TEAM_BUDGET_ACCOUNT_CODE = '550203'
_TEAM_BUDGET_COLUMNS = ['예산금액', '전기금액', '임시전표', '전기+임시', '잔여예산']


def _sap_tree_node_search_text(tree, key, col_names):
    """트리 노드 하나의 검색 가능한 텍스트를 모은다. `GetNodeTextByKey`가 계층(키) 컬럼
    텍스트만 주는 트리가 있어(2026-09-22 실사용 확인 — "1008E010"만 나오고 화면에 보이는
    "개발1팀(판)"은 별도 컬럼이었음), `_sap_dump_tree`와 같은 다중 컬럼 시도 패턴으로
    있는 컬럼을 전부 훑어 합친다."""
    parts = []
    try:
        parts.append(str(tree.GetNodeTextByKey(key)))
    except Exception:
        pass
    for col in col_names:
        for attempt in ('GetItemText', 'GetCellValue'):
            try:
                v = str(getattr(tree, attempt)(key, col))
                if v:
                    parts.append(v)
                break
            except Exception:
                continue
    return ' '.join(p for p in parts if p)


_LBL_COORD_RE = re.compile(r'lbl\[(\d+),(\d+)\]$')


def _sap_parse_label_grid(wnd):
    """`usr` 영역의 GuiLabel Id가 `lbl[열,행]` 좌표 패턴인 화면(ZCO021 팀운영비 등)을
    {(col,row): text} 딕셔너리로 파싱한다(2026-09-23, 실사용 화면 트리 덤프로 이 좌표 패턴을
    직접 확인 — `dump_screen_tree` 참고). `_sap_dump_fields`와 달리 **빈 텍스트도 그대로
    딕셔너리에 남긴다** — 값이 0이라 화면에 안 보이는 칸(예: 활동이 없는 기간의 "임시전표")도
    좌표 자체는 존재해야 컬럼이 밀리지 않는다."""
    grid = {}
    try:
        children = wnd.findById('usr').Children
    except Exception:
        return grid
    for i in range(children.Count):
        try:
            child = children.Item(i)
            if child.Type != 'GuiLabel':
                continue
            m = _LBL_COORD_RE.search(str(child.Id))
            if not m:
                continue
            grid[(int(m.group(1)), int(m.group(2)))] = str(child.Text or '').strip()
        except Exception:
            continue
    return grid


def _sap_find_team_budget_row_by_coords(wnd):
    """`_sap_parse_label_grid`로 좌표 격자를 얻어, 헤더 행에서 `_TEAM_BUDGET_COLUMNS` 각각의
    열(column) 위치를 찾고, `_TEAM_BUDGET_ACCOUNT_CODE`가 들어있는 행(row)에서 그 열들의
    값을 좌표로 직접 읽는다 — 순서 기반 슬라이싱(`_sap_find_team_budget_row_sequential`)과
    달리 중간에 빈 칸이 있어도 흔들리지 않는다. 실패하면 None."""
    grid = _sap_parse_label_grid(wnd)
    if not grid:
        return None
    header_row = None
    col_for_label = {}
    for (col, row), text in grid.items():
        if not text:
            continue
        for label in _TEAM_BUDGET_COLUMNS:
            if label in text:
                if header_row is None or row == header_row:
                    header_row = row
                    col_for_label[label] = col
    if header_row is None or len(col_for_label) != len(_TEAM_BUDGET_COLUMNS):
        return None
    account_row = None
    account_label = None
    for (col, row), text in grid.items():
        if _TEAM_BUDGET_ACCOUNT_CODE in text:
            account_row = row
            account_label = text
            break
    if account_row is None:
        return None
    values = [grid.get((col_for_label[label], account_row), '') for label in _TEAM_BUDGET_COLUMNS]
    return {'account_label': account_label, 'values': values}


def _sap_find_team_budget_row_sequential(wnd):
    """[예전 방식, 폴백용] `usr` 영역의 모든 GuiLabel을 화면에 보이는 순서대로 모아
    (`_sap_dump_fields`) `_TEAM_BUDGET_ACCOUNT_CODE`("550203")가 들어있는 라벨을 찾는다.
    ⚠️ 값이 빈 문자열인 칸은 `_sap_dump_fields`가 통째로 건너뛰어 버려서, 임시전표처럼
    0(빈 칸)이 될 수 있는 컬럼이 있으면 순서가 밀려 실패한다(2026-09-23 실사용 버그로 확인
    — `_sap_find_team_budget_row_by_coords`가 그 재발 방지용 1차 경로이고, 이건 좌표 패턴이
    아닌 화면을 위한 안전망으로만 남겨둔다).
    (전체 라벨 목록, {'account_label', 'values'} | None)을 반환."""
    labels = _sap_dump_fields(wnd)
    n = len(_TEAM_BUDGET_COLUMNS)
    for i, text in enumerate(labels):
        if _TEAM_BUDGET_ACCOUNT_CODE not in text:
            continue
        if '팀운영비' in text or '복리후생비' in text:
            # 코드+계정명이 한 라벨에 합쳐진 경우 — 값은 바로 다음부터.
            values = labels[i + 1:i + 1 + n]
            if len(values) == n:
                return labels, {'account_label': text.strip(), 'values': values}
        # 코드만 있는 라벨 — 다음 라벨이 계정명, 그다음부터 값.
        if i + 1 < len(labels):
            values = labels[i + 2:i + 2 + n]
            if len(values) == n:
                return labels, {'account_label': labels[i + 1].strip(), 'values': values}
    return labels, None


def _sap_find_team_budget_row(wnd):
    """팀운영비 행 값 추출 진입점 — 좌표 기반(`_sap_find_team_budget_row_by_coords`)을 먼저
    시도하고, 실패하면(좌표 패턴이 아닌 화면 등) 예전 순서 기반 방식으로 폴백한다.
    (전체 라벨 목록, {'account_label', 'values'} | None)을 반환 — 실패 시 진단 메시지에
    쓸 라벨 목록은 폴백 경로에서 어차피 계산하므로 그대로 재사용."""
    by_coords = _sap_find_team_budget_row_by_coords(wnd)
    if by_coords is not None:
        return [], by_coords  # 성공 시 labels는 실패 진단용이라 불필요 — 재계산 생략
    return _sap_find_team_budget_row_sequential(wnd)


def fetch_team_budget(team, fperbl='1', tperbl='12'):
    """ZCO021 "코텍 예실레포트"에서 지정한 팀의 "550203 복리후생비-팀운영비" 행을 조회한다.
    `team`은 코스트 센터 트리에 보이는 팀 이름의 일부(예: "개발3팀")면 된다.
    `fperbl`/`tperbl`은 기간시작/기간종료(1~12) — 기본은 연간 누적(1~12)."""
    team = (team or '').strip()
    if not team:
        raise RuntimeError('팀 이름을 지정해주세요. 예: 개발3팀')
    try:
        fperbl_i, tperbl_i = int(fperbl), int(tperbl)
    except (TypeError, ValueError):
        raise RuntimeError(f'기간(fperbl/tperbl)은 1~12 사이의 숫자여야 합니다: {fperbl}~{tperbl}')
    if not (1 <= fperbl_i <= 12 and 1 <= tperbl_i <= 12 and fperbl_i <= tperbl_i):
        raise RuntimeError(f'기간이 올바르지 않습니다(1~12, 시작<=종료): {fperbl_i}~{tperbl_i}')
    fperbl, tperbl = str(fperbl_i), str(tperbl_i)

    session = _get_sap_session()
    session.StartTransaction('ZCO021')
    time.sleep(0.8)

    # 리포트(변형) 선택 팝업 — 위 주석 ① 참고. 없는 세션도 있을 수 있어 조용히 건너뛴다.
    try:
        wnd1 = session.findById('wnd[1]')
        usr1 = wnd1.findById('usr')
        for pos in (1, 2, 3, 4, 5, 6, 5, 4, 3, 2, 1, 0):
            usr1.verticalScrollbar.position = pos
        session.findById('wnd[1]').sendVKey(2)  # F2 = 선택(Choose)
        time.sleep(0.6)
    except Exception:
        pass

    wnd = session.findById('wnd[0]')
    try:
        wnd.findById('usr/ctxtP_FPERBL').text = fperbl
        wnd.findById('usr/ctxtP_TPERBL').text = tperbl
    except Exception as e:
        raise RuntimeError(f'ZCO021 기간(P_FPERBL/P_TPERBL) 입력 필드를 찾지 못했습니다 — SAP 화면 구성이 바뀌었을 수 있습니다: {e}')

    try:
        wnd.findById('tbar[1]/btn[8]').press()  # 실행(F8)
    except Exception as e:
        raise RuntimeError(f'ZCO021 실행(F8) 중 오류가 발생했습니다: {e}')
    time.sleep(1.5)

    wnd = session.findById('wnd[0]')
    try:
        tree = wnd.findById('shellcont/shell/shellcont[2]/shell')
    except Exception as e:
        raise RuntimeError(f'코스트 센터 트리를 찾지 못했습니다(SAP 화면 구성이 바뀌었을 수 있음): {e}')
    try:
        node_keys = list(tree.GetAllNodeKeys())
    except Exception as e:
        raise RuntimeError(f'코스트 센터 트리 노드 목록을 읽지 못했습니다: {e}')

    # 🐛 [2026-09-22 실사용 버그수정, 스크린샷으로 확인] `GetNodeTextByKey`는 이 트리에서
    #    "1008E010" 같은 코드(계층 컬럼)만 주고, 화면에 보이는 "개발1팀(판)" 같은 이름은
    #    **다른 컬럼**에 들어있었다(실패 메시지에 코드만 나열됐던 게 증거) — `_sap_dump_tree`와
    #    같은 다중 컬럼 탐색으로 바꿔 모든 컬럼 텍스트를 합쳐서 검색한다.
    try:
        col_names = list(tree.GetColumnNames())
    except Exception:
        col_names = []

    team_norm = team.replace(' ', '')
    target_key = None
    all_texts = []
    for key in node_keys:
        text = _sap_tree_node_search_text(tree, key, col_names)
        if not text:
            continue
        all_texts.append(text)
        if team_norm in text.replace(' ', ''):
            target_key = key
            break
    if target_key is None:
        raise RuntimeError(f'"{team}" 팀을 코스트 센터 트리에서 찾지 못했습니다. 트리에 있는 항목: {", ".join(all_texts) or "(읽기 실패)"}')
    tree.selectedNode = target_key
    time.sleep(1.2)

    wnd = session.findById('wnd[0]')
    labels, matched = _sap_find_team_budget_row(wnd)

    if matched is None:
        # 위 주석 ② — "* 원가 요소 그룹" 같은 접힌 행을 한 번 펼쳐보고 재시도.
        try:
            fields = wnd.findById('usr').Children
            for i in range(fields.Count):
                child = fields.Item(i)
                if child.Type == 'GuiLabel' and str(child.Text).strip().startswith('*'):
                    child.SetFocus()
                    session.findById('wnd[0]').sendVKey(2)
                    time.sleep(0.8)
                    break
        except Exception:
            pass
        wnd = session.findById('wnd[0]')
        labels, matched = _sap_find_team_budget_row(wnd)

    if matched is None:
        # 🆕 [2026-09-23, 실사용 버그리포트] 기간을 연간 누적(1~12)이 아니라 좁혀서(예: 1~6월)
        #    조회하면 이 라벨 매칭이 실패한다는 신고 접수 — 부분 기간에서는 화면이 라벨
        #    그리드가 아니라 ALV 그리드로 바뀔 가능성이 있어(추측, 실환경 미검증) 그리드
        #    존재 여부와 실제 라벨 목록을 에러에 그대로 남긴다(추측으로 파싱 로직을 고치는
        #    대신 다음 실패 시 원인을 바로 좁힐 수 있도록 — CLAUDE.md "추측 금지" 원칙).
        diag = [f'화면에서 읽은 항목 수: {len(labels)}건']
        try:
            grid_shell = _sap_find_grid(wnd)
        except Exception:
            grid_shell = None
        if grid_shell is not None:
            diag.append('⚠️ 화면에 ALV 그리드가 감지됨(부분 기간에서는 라벨 화면 대신 그리드로 바뀌었을 수 있음)')
            try:
                grid_dump = _sap_dump_grid(grid_shell)
            except Exception:
                grid_dump = None
            if grid_dump:
                diag.append('그리드 내용(최대 2000자): ' + (grid_dump if len(grid_dump) <= 2000 else grid_dump[:2000] + ' …(생략)'))
        else:
            diag.append('라벨 목록(최대 60개): ' + ' | '.join(labels[:60]))
        return {
            'ok': False,
            'error': f'"{team}" 화면은 열었지만 계정 {_TEAM_BUDGET_ACCOUNT_CODE}(복리후생비-팀운영비) 행을 찾지 못했습니다. 화면 구성이 다를 수 있습니다. ' + ' / '.join(diag),
        }

    # ⚠️ [2026-09-22 실사용 버그수정] dict로 반환하면 Flask jsonify(JSON_SORT_KEYS 기본값)가
    #    키를 알파벳(유니코드) 순으로 재정렬해버려 "예산금액→전기금액→...→잔여예산" 순서가
    #    "예산금액,임시전표,잔여예산,전기+임시,전기금액"처럼 뒤죽박죽 나왔다(실사용 확인) —
    #    배열(JSON array)은 정렬 대상이 아니라서 순서가 보존되는 [{'label','value'}] 형태로 변경.
    values = [{'label': k, 'value': v} for k, v in zip(_TEAM_BUDGET_COLUMNS, matched['values'])]
    period_label = f'{fperbl}~{tperbl}월'
    text = (f'[SAP 팀 운영비 조회(ZCO021): {team}, {period_label}]\n'
            f'계정: {matched["account_label"]}\n' +
            '\n'.join(f'{v["label"]}: {v["value"]}' for v in values))
    return {'ok': True, 'team': team, 'periodFrom': fperbl, 'periodTo': tperbl, 'account': matched['account_label'], 'values': values, 'text': text}


def simulate_indat_copy(row_count=2):
    """🧪 [2026-09-30 신규] 현재 SAP GUI에 열려있는 ZMM062 그리드에서
    행 0의 INDAT(입고일자)를 읽어 행 1~(row_count-1)에 modifyCell로 직접 쓸 수 있는지만 검증.
    저장은 하지 않으므로 데이터에 영향 없음 — 시뮬레이션 전용.
    전제: ZMM062를 열고 행 0의 INQTY·INDAT까지 이미 채워진 상태."""
    row_count = max(2, int(row_count))
    session = _get_sap_session()
    wnd = session.findById('wnd[0]')
    try:
        grid = wnd.findById('shellcont/shell')
    except Exception as e:
        return {'ok': False, 'error': f'ZMM062 그리드를 찾지 못했습니다 — SAP GUI에서 ZMM062를 실행하고 구매오더 번호를 입력해 그리드 화면까지 진행된 상태여야 합니다: {e}'}

    actual_rows = grid.RowCount
    if actual_rows < 2:
        return {'ok': False, 'error': f'그리드 행이 {actual_rows}개입니다. 시뮬레이션은 2행 이상 필요합니다.'}

    try:
        indat0 = str(grid.GetCellValue(0, 'INDAT')).strip()
    except Exception as e:
        return {'ok': False, 'error': f'행 0 INDAT 읽기 실패: {e}'}

    if not indat0:
        return {'ok': False, 'error': '행 0의 INDAT가 비어 있습니다. 먼저 행 0에서 F4 캘린더로 날짜를 선택해주세요.'}

    rows_written, rows_failed, detail = [], [], []
    test_range = range(1, min(row_count, actual_rows))
    for idx in test_range:
        try:
            grid.modifyCell(idx, 'INDAT', indat0)
            time.sleep(0.2)
            check = str(grid.GetCellValue(idx, 'INDAT')).strip()
            if check == indat0:
                rows_written.append(idx)
                detail.append(f'행{idx}: ✅ INDAT={check}')
            else:
                rows_failed.append(idx)
                detail.append(f'행{idx}: ⚠️ 썼는데 읽히는 값={check!r} (예상={indat0!r})')
        except Exception as e:
            rows_failed.append(idx)
            detail.append(f'행{idx}: ❌ {e}')

    ok = len(rows_failed) == 0
    summary = (
        f'행 0 INDAT={indat0!r}\n'
        f'테스트 행: {list(test_range)}\n'
        f'성공: {rows_written}, 실패: {rows_failed}\n' +
        '\n'.join(detail)
    )
    return {'ok': ok, 'indat_row0': indat0, 'rows_written': rows_written, 'rows_failed': rows_failed,
            'text': summary, 'detail': detail}


def simulate_vendor_copy(row_count=2):
    """🧪 [2026-09-30 신규] 현재 SAP GUI에 열려있는 ZMMR060 그리드에서
    행 0의 LIFNR/MWSKZ를 읽어 행 1~(row_count-1)에 modifyCell로 직접 쓸 수 있는지만 검증.
    저장은 하지 않으므로 데이터에 영향 없음 — 시뮬레이션 전용."""
    row_count = max(2, int(row_count))
    session = _get_sap_session()
    wnd = session.findById('wnd[0]')
    grid = _find_po_grid(session, wnd)
    if grid is None:
        return {'ok': False, 'error': 'ZMMR060 그리드를 찾지 못했습니다 — SAP GUI에서 ZMMR060을 실행하고 엑셀 업로드까지 완료된 상태여야 합니다.'}

    actual_rows = grid.RowCount
    if actual_rows < 1:
        return {'ok': False, 'error': f'그리드 행이 {actual_rows}개입니다. 업로드된 품목이 없습니다.'}

    # 행 0의 LIFNR/MWSKZ 읽기
    try:
        lifnr0 = str(grid.GetCellValue(0, 'LIFNR')).strip()
        mwskz0 = str(grid.GetCellValue(0, 'MWSKZ')).strip()
    except Exception as e:
        return {'ok': False, 'error': f'행 0 값 읽기 실패: {e}'}

    if not lifnr0:
        return {'ok': False, 'error': f'행 0의 LIFNR이 비어 있습니다. 먼저 F4로 협력사를 선택해주세요.'}

    rows_written, rows_failed, detail = [], [], []
    test_range = range(1, min(row_count, actual_rows))
    for idx in test_range:
        try:
            grid.modifyCell(idx, 'LIFNR', lifnr0)
            if mwskz0:
                grid.modifyCell(idx, 'MWSKZ', mwskz0)
            # 실제로 써졌는지 재확인
            check = str(grid.GetCellValue(idx, 'LIFNR')).strip()
            if check == lifnr0:
                rows_written.append(idx)
                detail.append(f'행{idx}: ✅ LIFNR={check}')
            else:
                rows_failed.append(idx)
                detail.append(f'행{idx}: ⚠️ 썼는데 읽히는 값={check!r} (예상={lifnr0!r})')
        except Exception as e:
            rows_failed.append(idx)
            detail.append(f'행{idx}: ❌ {e}')

    ok = len(rows_failed) == 0
    summary = (
        f'행 0 LIFNR={lifnr0!r}, MWSKZ={mwskz0!r}\n'
        f'테스트 행: {list(test_range)}\n'
        f'성공: {rows_written}, 실패: {rows_failed}\n' +
        '\n'.join(detail)
    )
    return {'ok': ok, 'lifnr_row0': lifnr0, 'mwskz_row0': mwskz0,
            'rows_written': rows_written, 'rows_failed': rows_failed,
            'text': summary}


# ── "구매오더 요청"(ZMMR060 → ZMM018) 전용 헬퍼 (2026-09-15 신규) ──────────
# AI 문답에 전자세금계산서/견적서 PDF를 첨부하면 항목을 추출해 만든 BDC Upload 엑셀을
# ZMMR060에 업로드해 구매오더를 생성하고, 저장 직전에 사람이 확인하도록 두 단계로 나눴다
# (kortek_backend.py/js 04h와 함께 설계 — CLAUDE.md "🛒 구매오더 요청" 절 참고, 실제 SAP
# 저장(구매오더 확정)은 되돌리기 번거로운 동작이라 사람 확인 없이 자동 실행하지 않기로
# 사용자와 명시적으로 합의함):
#   ① prepare_po_from_excel — 엑셀 업로드 → F8 → 협력사(사업자등록번호로 F4 검색)·세금코드·
#      단가 입력까지만 하고 저장(SAVE) 직전에 멈춘다. 결과 화면을 텍스트로 반환해 사람이
#      AI 문답 채팅에서 확인할 수 있게 한다.
#   ② confirm_save_po — 사람이 "저장해줘"라고 확인한 뒤에만 별도로 호출 — 실제로 저장
#      버튼을 눌러 구매오더를 확정하고, 오더번호를 읽어 ZMM018로 이동해 발주서 PDF를
#      출력한다. 두 함수는 서로 다른 서브프로세스 호출이지만 SAP GUI 세션 자체는 그 사이에
#      계속 살아있는 같은 프로세스이므로(사람이 화면을 그대로 열어둔 채로만 ②를 불러야
#      함), ②는 항상 ①이 남겨둔 화면 상태를 그대로 이어받는다.
# ⚠️⚠️ 2026-09-15 실사용 화면 녹화(Windows ScreenSketch)로 초기화면 구조(플랜트/파일
# 필드, "생성"/"조회" 라디오)는 시각적으로 확인했다 — "파일" 필드 옆 폴더 아이콘을 누르면
# 네이티브 Windows "열기" 다이얼로그가 뜨는데, 선택 후 그 필드에는 평범한 전체 경로
# 문자열(`C:\Users\...\Z38MMR060.xls`)이 그대로 채워지는 것으로 확인됨(스크린샷으로
# 확인) — 즉 라벨이 아니라 진짜 텍스트 입력 필드다. 이 프로젝트가 이미 겪은 "네이티브
# 다이얼로그는 SAP GUI Scripting으로 못 잡는다"는 제약(CLAUDE.md의 SAP 문서 열기 절
# 참고)을 감안해, 다이얼로그 자체를 열지 않고 이 필드에 곧바로 경로 문자열을 대입해서
# 완전히 우회한다(다른 SAP 선택화면 필드들과 동일한 방식). 다만 일반 화면 녹화라 정확한
# session.findById 기술 ID까지는 안 나와서, "플랜트"/"파일" 필드는 이 프로젝트의 기존
# 관례(_set_text_on_best_candidate로 "WERKS"/"FILE" 계열 문자열 추측)로 찾는 방어적
# 코드다 — 못 찾으면 조용히 잘못 진행하는 대신 명확한 RuntimeError로 실패한다(실패하면
# 라이브 진단으로 정확한 ID를 확인해야 함). 반대로 협력사(LIFNR)/세금코드(MWSKZ)/
# 단가(NETPR)/저장(btn[5])/ZMM018 부분은 사용자가 제공한 SAP GUI "기록 및 재생" 매크로
# (발주서 작성,출력.vbs)에서 그대로 가져온 정확한 ID다(추측 아님).
def _zmm060_select_create_radio(wnd, debug_steps=None):
    """ZMMR060 초기화면의 '생성' 라디오버튼을 선택한다.
    이전 실행이 '재처리' 모드였으면 그 모드가 남아 F8 후 "데이터가 존재하지 않습니다"
    오류가 나므로 항상 명시적으로 선택한다.
    라디오버튼 Name은 SAP 사내 커스텀이라 알 수 없으므로 Text로 탐색한다."""
    CREATE_TEXTS = ('생성', '신규', '등록', 'Anlegen', 'Create', 'New')
    def _search(container, depth=0):
        if depth > 6:
            return False
        try:
            count = container.Children.Count
        except Exception:
            return False
        for i in range(count):
            try:
                ch = container.Children.ElementAt(i)
            except Exception:
                continue
            ctype = ''
            try:
                ctype = ch.Type
            except Exception:
                pass
            if ctype == 'GuiRadioButton':
                try:
                    txt = (ch.Text or '').strip()
                    if any(t in txt for t in CREATE_TEXTS):
                        if not ch.Selected:
                            ch.Select()
                            if debug_steps is not None:
                                debug_steps.append(f'ZMMR060 생성 라디오버튼 선택: "{txt}"')
                        else:
                            if debug_steps is not None:
                                debug_steps.append(f'ZMMR060 생성 라디오버튼 이미 선택됨: "{txt}"')
                        return True
                except Exception:
                    pass
            if _search(ch, depth + 1):
                return True
        return False
    found = _search(wnd)
    if not found and debug_steps is not None:
        debug_steps.append('ZMMR060 생성 라디오버튼을 찾지 못함 — 현재 모드 그대로 진행')


def _navigate_to_po_upload_screen(session, wnd, excel_path, plant='1000', debug_steps=None):
    """ZMMR060("연구개발자재 발주시스템") 초기화면에 진입해 "생성" 모드로 로컬 엑셀
    파일을 업로드한다."""
    session.findById('wnd[0]/tbar[0]/okcd').text = '/nZMMR060'
    wnd.sendVKey(0)
    time.sleep(0.8)
    wnd = session.findById('wnd[0]')

    # ★ 생성 라디오버튼 강제 선택 — 이전 세션이 "재처리" 모드로 끝났으면 그대로 남아
    # F8 후 "데이터가 존재하지 않습니다" 오류가 나므로 항상 생성 모드를 명시한다.
    _zmm060_select_create_radio(wnd, debug_steps=debug_steps)

    _set_text_on_best_candidate(wnd, 'WERKS', plant)
    # 플랜트는 화면 기본값(보통 1000)이 이미 들어있는 경우가 많아, 못 찾아도 치명적이지
    # 않으므로 실패해도 계속 진행한다.

    file_field = None
    for guess in ('P_FILE', 'FILENAME', 'DATEI', 'FILE'):
        file_field = _set_text_on_best_candidate(wnd, guess, excel_path)
        if file_field is not None:
            break
    if file_field is None:
        raise RuntimeError('ZMMR060 화면에서 "파일" 입력 필드를 찾지 못했습니다 — 화면 구조가 예상과 다를 수 있습니다(라이브 진단 필요).')

    try:
        session.findById('wnd[0]/tbar[1]/btn[8]').press()  # 실행(F8) — 엑셀 업로드 실행
    except Exception as e:
        raise RuntimeError(f'ZMMR060 실행(F8) 중 오류가 발생했습니다: {e}')

    # F8 후 SAP가 엑셀을 파싱·검증하는 시간이 파일 크기·서버 응답에 따라 달라진다.
    # 고정 2초 대신 그리드 또는 상태표시줄 메시지가 나타날 때까지 폴링(최대 15초).
    for _w in range(15):
        time.sleep(1.0)
        try:
            _test_wnd = session.findById('wnd[0]')
        except Exception:
            continue
        # 결과 그리드가 나타났으면 즉시 반환
        try:
            session.findById('wnd[0]/shellcont/shell/shellcont/shell')
            return _test_wnd  # 그리드 발견
        except Exception:
            pass
        # 오류·경고 메시지가 상태표시줄에 나타났으면 더 기다려도 그리드는 안 나옴 → 반환
        try:
            _sbar = (session.findById('wnd[0]/sbar').Text or '').strip()
            if _sbar:
                return _test_wnd
        except Exception:
            pass
    # 15초 경과 후에도 변화 없으면 현재 wnd 반환(호출부에서 grid=None 처리)
    return session.findById('wnd[0]')


def _find_po_grid(session, wnd):
    """ZMMR060 결과 그리드는 `wnd[0]/shellcont/shell/shellcont/shell`(매크로에서 확인된
    절대경로, usr 서브트리 밖에 있는 특이한 구조) — 먼저 이 정확한 경로를 시도하고,
    실패하면 방어적으로 타입 기반 탐색으로 폴백한다."""
    try:
        return session.findById('wnd[0]/shellcont/shell/shellcont/shell')
    except Exception:
        return _find_by_id_substring(wnd, 'shellcont/shell', require_type='GuiShell')


def _sap_close_stray_popups(session, max_windows=4):
    """이전 시도가 중간에 실패해서(예: 협력사 검색 결과 없음) 팝업(wnd[1] 이상)이 열린 채로
    남아있으면, 그 위에 새 트랜잭션 코드를 입력해도 씹히거나 엉뚱한 동작을 한다 — "SAP에서
    뭔가 시도하다 멈추면 처음으로 돌아가서 트랜잭션 코드를 입력하고 다시 시도해야 하는데
    못하고 있음"이라는 실사용 제보로 확인됨(2026-09-16). 재시도 직전에 항상 이 함수로
    wnd[1]부터 위로 열려있는 창을 전부 닫아 깨끗한 상태(wnd[0]만 남은 상태)를 보장한다 —
    닫을 게 없으면 조용히 통과."""
    for i in range(max_windows, 0, -1):
        try:
            w = session.findById(f'wnd[{i}]')
        except Exception:
            continue
        try:
            w.close()
        except Exception:
            try:
                w.sendVKey(12)  # F12 = 취소, close()가 안 먹는 팝업 대비 폴백
            except Exception:
                pass
        time.sleep(0.3)


def prepare_po_from_excel(excel_path, biz_reg_no, items, plant='1000', currency='KRW'):
    """구매오더 생성 1단계 — 엑셀 업로드 후 각 품목 행에 협력사/세금코드/단가를 채우고
    저장 직전에 멈춘다. `items`는 엑셀에 넣은 행과 같은 순서의 리스트, 각 원소는
    {"unitPrice": 숫자} 형태(PDF에서 추출한 단가 — SAP에 저장된 값이 아니라 이 값을
    그대로 SAP에 입력한다). 협력사/세금코드는 품목(행)마다 반복해서 검색·선택한다(아래
    참고 — 처음엔 PO당 한 번이면 되는 줄 알았다가 실사용에서 틀렸음이 확인되어 고침).
    ⚠️ 재시도 시 이전 실패로 남은 팝업을 먼저 정리한다(`_sap_close_stray_popups`) —
    협력사 검색이 실패(사업자등록번호가 SAP에 없음 등)하면 "검색 결과 없음"류 팝업이
    열린 채로 남는데, 그 상태에서 그냥 다시 이 함수를 호출하면 새 트랜잭션 진입 자체가
    막히던 문제가 실사용에서 확인됨.
    `currency`(2026-09-16 신규, 사용자 요청 — "계산서/거래명세서에 KRW 말고 USD도 있다")
    — 그리드의 `WAERS`(통화) 컬럼은 실사용 테스트에서 아무것도 안 건드려도 'KRW'로
    자동 채워지는 것을 확인했으므로(협력사/플랜트 기준 기본 통화로 추정), 기본값(KRW)일
    때는 그대로 두고(이미 검증된 동작을 건드리지 않기 위해) **currency가 'KRW'가
    아닐 때만** 행마다 `WAERS` 셀을 명시적으로 덮어쓴다."""
    session = _get_sap_session()
    _sap_close_stray_popups(session)
    wnd = session.findById('wnd[0]')
    _dbg = []  # 진단 로그 — 실패 시 오류 메시지에 포함
    wnd = _navigate_to_po_upload_screen(session, wnd, excel_path, plant, debug_steps=_dbg)

    grid = _find_po_grid(session, wnd)
    if grid is None:
        sbar_text = ''
        try:
            sbar_text = (session.findById('wnd[0]/sbar').Text or '').strip()
        except Exception:
            pass
        detail = f' [SAP 상태표시줄: "{sbar_text}"]' if sbar_text else ''
        # 라디오버튼 현재 상태 스캔 — "재처리" 모드인지 진단용
        _rb_diag = []
        try:
            def _scan_rb(container, depth=0):
                if depth > 6:
                    return
                try:
                    count = container.Children.Count
                except Exception:
                    return
                for i in range(count):
                    try:
                        ch = container.Children.ElementAt(i)
                        if ch.Type == 'GuiRadioButton':
                            _rb_diag.append(f'  [{ch.Text}] selected={ch.Selected}')
                    except Exception:
                        pass
                    try:
                        _scan_rb(container.Children.ElementAt(i), depth + 1)
                    except Exception:
                        pass
            _scan_rb(session.findById('wnd[0]'))
        except Exception:
            pass
        _dbg_str = (' | debug: ' + '; '.join(_dbg)) if _dbg else ''
        _rb_str = (' | 라디오버튼: ' + ', '.join(_rb_diag)) if _rb_diag else ''
        raise RuntimeError(
            '엑셀 업로드 후 결과 그리드를 찾지 못했습니다.' + detail + _dbg_str + _rb_str +
            ' — 이 증상은 보통 ①ZMMR060이 "재처리" 모드로 열렸거나 ②엑셀 안의 값 중 SAP에'
            ' 실제로 존재하지 않는 것이 있어 업로드 검증에서 막힌 경우입니다'
            '(프로젝트코드·구매담당자 사번·자재코드·구매그룹 등은 자유 텍스트가 아니라'
            ' SAP 마스터데이터와 일치해야 합니다). 엑셀 파일: ' + str(excel_path))

    # [2026-09-30 수정] 협력사(LIFNR)/세금코드(MWSKZ)는 첫 행(row 0)만 F4로 조회·선택하고,
    # 나머지 행은 modifyCell로 이미 검증된 값을 직접 씀 — 사람이 수동으로 "row 0 Ctrl+C →
    # 나머지 행 Ctrl+V" 하는 것과 동일한 동작이다.
    # [구 설명 정정] 이전 주석에서 "검색 결과를 다른 행에 복사하는 기능이 없다"고 했으나,
    # 이는 잘못된 판단이었다 — row 0의 F4 완료 후 GetCellValue로 LIFNR을 읽어 modifyCell로
    # 쓰면 SAP이 저장 시점에 검증하며 정상 통과한다(사용자 실사용 확인).

    # ── 행 0: F4 팝업으로 협력사 조회 ──────────────────────────────────────────
    grid.currentCellRow = 0
    grid.currentCellColumn = 'LIFNR'
    grid.pressF4()
    time.sleep(0.6)
    try:
        biz_field = session.findById(
            "wnd[1]/usr/tabsG_SELONETABSTRIP/tabpTAB001/ssubSUBSCR_PRESEL:SAPLSDH4:0220/"
            "sub:SAPLSDH4:0220/txtG_SELFLD_TAB-LOW[1,24]"
        )
        biz_field.text = str(biz_reg_no)
        biz_field.setFocus()
        biz_field.caretPosition = len(str(biz_reg_no))
        session.findById('wnd[1]').sendVKey(0)  # 검색 실행
        time.sleep(0.6)
        session.findById('wnd[1]/usr/lbl[1,3]').caretPosition = 9  # 첫 결과 행 선택
        session.findById('wnd[1]').sendVKey(2)  # 더블클릭과 동일 — 선택 확정
        time.sleep(0.5)
    except Exception as e:
        raise RuntimeError(f'1번째 품목의 협력사(사업자등록번호 "{biz_reg_no}") 검색 중 오류가 발생했습니다: {e} — 그 사업자등록번호로 등록된 협력사가 SAP에 없을 수 있습니다.')

    # ── 행 0: F4 팝업으로 세금코드 선택 ──────────────────────────────────────
    grid.currentCellRow = 0
    grid.currentCellColumn = 'MWSKZ'
    grid.pressF4()
    time.sleep(0.6)
    try:
        session.findById('wnd[1]/usr/lbl[1,21]').setFocus()
        session.findById('wnd[1]/usr/lbl[1,21]').caretPosition = 1
        session.findById('wnd[1]').sendVKey(2)
        time.sleep(0.5)
    except Exception as e:
        raise RuntimeError(f'1번째 품목의 세금코드 선택 중 오류가 발생했습니다: {e}')

    # ── 행 0에서 채워진 LIFNR/MWSKZ 값 읽기 (Ctrl+C에 해당) ──────────────────
    lifnr_filled = ''
    mwskz_filled = ''
    try:
        lifnr_filled = str(grid.GetCellValue(0, 'LIFNR')).strip()
        mwskz_filled = str(grid.GetCellValue(0, 'MWSKZ')).strip()
    except Exception:
        pass  # 읽기 실패 시 이후 행도 F4 폴백

    # ── 행 1~N: Ctrl+V에 해당 — 이미 검증된 값을 modifyCell로 직접 씀 ─────────
    for idx in range(1, len(items)):
        if lifnr_filled:
            try:
                grid.modifyCell(idx, 'LIFNR', lifnr_filled)
            except Exception:
                # modifyCell 실패 시 F4 폴백 (SAP 그리드가 직접 쓰기를 막는 경우)
                grid.currentCellRow = idx
                grid.currentCellColumn = 'LIFNR'
                grid.pressF4()
                time.sleep(0.6)
                try:
                    biz_field = session.findById(
                        "wnd[1]/usr/tabsG_SELONETABSTRIP/tabpTAB001/ssubSUBSCR_PRESEL:SAPLSDH4:0220/"
                        "sub:SAPLSDH4:0220/txtG_SELFLD_TAB-LOW[1,24]"
                    )
                    biz_field.text = str(biz_reg_no)
                    biz_field.setFocus()
                    biz_field.caretPosition = len(str(biz_reg_no))
                    session.findById('wnd[1]').sendVKey(0)
                    time.sleep(0.6)
                    session.findById('wnd[1]/usr/lbl[1,3]').caretPosition = 9
                    session.findById('wnd[1]').sendVKey(2)
                    time.sleep(0.5)
                except Exception as e2:
                    raise RuntimeError(f'{idx + 1}번째 품목의 협력사 검색 중 오류가 발생했습니다: {e2}')
        if mwskz_filled:
            try:
                grid.modifyCell(idx, 'MWSKZ', mwskz_filled)
            except Exception:
                # modifyCell 실패 시 F4 폴백
                grid.currentCellRow = idx
                grid.currentCellColumn = 'MWSKZ'
                grid.pressF4()
                time.sleep(0.6)
                try:
                    session.findById('wnd[1]/usr/lbl[1,21]').setFocus()
                    session.findById('wnd[1]/usr/lbl[1,21]').caretPosition = 1
                    session.findById('wnd[1]').sendVKey(2)
                    time.sleep(0.5)
                except Exception as e2:
                    raise RuntimeError(f'{idx + 1}번째 품목의 세금코드 선택 중 오류가 발생했습니다: {e2}')

    # 품목별 단가(NETPR)/EPEIN — PDF에서 추출한 값을 행 순서대로 입력.
    # [2026-09-30 버그수정] 소수점 단가(예: 321.94)를 NETPR에 그대로 쓰면 SAP KRW 필드가
    #   반올림(322)하여 금액 불일치 발생. 소수점 자릿수만큼 EPEIN(가격단위)을 올려서 보완:
    #   321.94 → NETPR=32194, EPEIN=100 → 2,000개 × 32194 ÷ 100 = 643,880원 ≈ 명세서 643,882원 ✓
    for idx, item in enumerate(items):
        price = item.get('unitPrice')
        if price is None:
            continue
        try:
            price = float(price)
            # 소수점 자릿수 → EPEIN 결정
            _ps = ('{:.10f}'.format(price)).rstrip('0')
            _dec_len = len(_ps.split('.')[1]) if '.' in _ps else 0
            _epein = (10 ** _dec_len) if _dec_len > 0 else 1
            _netpr = int(round(price * _epein))
            grid.modifyCell(idx, 'NETPR', str(_netpr))
            # [2026-10-01] WAERS(통화) 수정은 ZMMR060 그리드에서 하지 않는다 — KRW가 기본값으로
            # 자동 채워지는 것을 실사용에서 확인함. USD 등 다른 통화는 저장 후 ME22N에서 변경.
            # (기존: currency != 'KRW'일 때 grid.modifyCell(idx, 'WAERS', currency) 호출했으나
            #  WAERS 필드가 read-only인 SAP 구성에서 오류 위험 → 제거)
            grid.currentCellRow = idx
            grid.currentCellColumn = 'EPEIN'
            grid.triggerModified()
            grid.modifyCell(idx, 'EPEIN', str(_epein))
        except Exception as e:
            raise RuntimeError(f'{idx + 1}번째 품목의 단가 입력 중 오류가 발생했습니다: {e}')

    body, source = _sap_dump_screen_body(wnd)
    header = '[SAP 구매오더 생성(ZMMR060) — 저장 전 확인 필요]\n'
    text = header + '\n' + (body or '(화면 내용을 읽지 못했습니다)')
    return {'ok': True, 'source': source, 'text': text}


def _change_po_currency_in_me22n(po_number, currency):
    """발주 저장 후 ME22N에서 통화(WAERS)를 변경하고 저장한다.
    사용자가 ZMM018에서 발주번호를 클릭해 들어가는 것과 동일한 결과를, 직접 /nME22N으로
    진입하는 방식으로 구현한다(ZMM018 그리드 drill-in보다 안정적).

    실측(2026-10-01 덤프): WAERS는 SAPLMEGUI:1105 헤더 서브스크린이 아니라
    품목 그리드 tblSAPLMEGUITC_1211의 MEPO1211-WAERS[11,0] 셀에 있음.
    MEPO_TOPLINE-WAERS 필드는 이 SAP 레이아웃에 존재하지 않는다."""
    session = _get_sap_session()
    _sap_close_stray_popups(session)

    # 1. ME22N 직접 진입 (PO 변경 화면)
    session.findById('wnd[0]/tbar[0]/okcd').text = '/nME22N'
    wnd = session.findById('wnd[0]')
    wnd.sendVKey(0)
    time.sleep(0.8)
    wnd = session.findById('wnd[0]')

    # 2. 발주 번호 입력 (ME22N 초기 선택 화면의 EBELN 필드)
    ebeln_f = _set_text_on_best_candidate(wnd, 'EBELN', po_number)
    if ebeln_f is None:
        raise RuntimeError(
            f'ME22N 화면에서 발주번호(EBELN) 입력 필드를 찾지 못했습니다. '
            f'SAP GUI가 이미 다른 화면에 있을 수 있습니다.'
        )
    wnd.sendVKey(0)  # Enter → PO 로드
    time.sleep(1.5)
    wnd = session.findById('wnd[0]')

    # 3. WAERS(통화) 필드 탐색 및 변경
    # 1차: _set_text_on_best_candidate로 WAERS substring 탐색
    #       실측 필드: MEPO1211-WAERS (품목 그리드 tblSAPLMEGUITC_1211 안의 셀)
    waers_f = _set_text_on_best_candidate(wnd, 'WAERS', currency)
    if waers_f is None:
        # 2차 폴백: 실측 경로로 직접 접근 — 품목 그리드 1행 WAERS 셀 [11,0]
        # (2026-10-01 덤프: MEPO_TOPLINE-WAERS 없음, MEPO1211-WAERS[11,0]에 "KRW" 확인)
        try:
            waers_f = session.findById(
                'wnd[0]/usr/subSUB0:SAPLMEGUI:0020/subSUB2:SAPLMEVIEWS:1100'
                '/subSUB2:SAPLMEVIEWS:1200/subSUB1:SAPLMEGUI:1211'
                '/tblSAPLMEGUITC_1211/txtMEPO1211-WAERS[11,0]'
            )
            waers_f.text = currency
        except Exception:
            raise RuntimeError(
                f'ME22N에서 통화(WAERS) 입력 필드를 변경하지 못했습니다. '
                f'품목 그리드 WAERS 셀(MEPO1211-WAERS[11,0])이 편집 불가 상태일 수 있습니다. '
                f'ME22N에서 발주번호 {po_number}를 열어 통화 컬럼이 편집 가능한지 확인해주세요.'
            )

    time.sleep(0.3)

    # 4. 저장 (F11 = ME22N 저장 단축키)
    wnd.sendVKey(11)
    time.sleep(1.0)
    _sap_close_stray_popups(session)

    sbar_text = ''
    try:
        sbar_text = (session.findById('wnd[0]/sbar').Text or '').strip()
    except Exception:
        pass

    return {
        'ok': True,
        'message': f'구매오더 {po_number} 통화를 {currency}로 변경했습니다.' + (f' ({sbar_text})' if sbar_text else '')
    }


def confirm_save_po(purchasing_org='9000', plant='1000', currency='KRW'):
    """구매오더 생성 2단계 — `prepare_po_from_excel`이 채워둔 화면을 사람이 확인한 뒤
    호출한다. 저장(SAVE) → 오더번호 확보 → ZMM018에서 발주서 PDF 출력까지 진행한다.
    이 함수 호출 시점에 SAP GUI가 반드시 `prepare_po_from_excel`이 마지막으로 남겨둔
    화면(그리드에 협력사/단가가 채워진 채 저장 대기 중)이어야 한다 — 그 사이 사람이나
    다른 스크립트가 화면을 바꿨으면 예상 못한 상태에서 저장이 실행될 위험이 있다."""
    session = _get_sap_session()

    try:
        session.findById('wnd[0]/tbar[1]/btn[5]').press()  # 저장
        time.sleep(0.5)
    except Exception as e:
        raise RuntimeError(f'저장(SAVE) 중 오류가 발생했습니다: {e}')

    # ★ 저장 직후 즉시 상태표시줄 읽기 — SAP가 "구매오더 XXXXXXXXXX가 생성되었습니다"
    # 메시지를 이 시점에만 잠깐 남기고 팝업이나 다른 상호작용으로 곧 지워진다.
    po_number = None
    try:
        _sbar_early = (session.findById('wnd[0]/sbar').Text or '').strip()
        _m = re.search(r'\b(\d{7,10})\b', _sbar_early)
        if _m:
            po_number = _m.group(1)
            print(f'[DEBUG] 저장 직후 sbar: {_sbar_early!r} → po={po_number}', file=sys.stderr)
    except Exception:
        pass

    # 저장 확인 팝업이 뜨면 확인(매크로에서 확인된 패턴) — 안 뜨면 조용히 건너뜀.
    try:
        session.findById('wnd[1]/usr/btnBUTTON_1').press()
        time.sleep(0.8)
    except Exception:
        pass

    # 팝업 확인 후 상태표시줄 재확인 (아직 못 읽었을 경우)
    if not po_number:
        try:
            _sbar_post = (session.findById('wnd[0]/sbar').Text or '').strip()
            _m2 = re.search(r'\b(\d{7,10})\b', _sbar_post)
            if _m2:
                po_number = _m2.group(1)
                print(f'[DEBUG] 팝업 후 sbar: {_sbar_post!r} → po={po_number}', file=sys.stderr)
        except Exception:
            pass

    wnd = session.findById('wnd[0]')
    grid = _find_po_grid(session, wnd)
    if grid is None:
        if po_number:
            # 그리드는 사라졌지만 이미 오더번호를 읽었으면 계속 진행
            pass
        else:
            raise RuntimeError('저장 후 결과 그리드를 찾지 못했습니다 — 저장이 실패했을 수 있습니다.')

    # 방법 2: 그리드의 EBELN 컬럼 직접 읽기 — drill-down 없이 getCellValue 사용.
    if not po_number and grid is not None:
        try:
            val = (grid.getCellValue(0, 'EBELN') or '').strip()
            if re.search(r'\d{7,}', val):
                po_number = val
                print(f'[DEBUG] getCellValue EBELN: {val!r}', file=sys.stderr)
        except Exception:
            pass

    # 방법 3: drill-down — 위 방법이 모두 실패한 경우에만.
    # VBS 매크로 확인 경로: currentCellColumn=EBELN → clickCurrentCell → MEPO_TOPLINE-EBELN
    if not po_number and grid is not None:
        try:
            time.sleep(0.5)  # 저장 완료 안정화 대기
            grid.currentCellRow = 0
            grid.currentCellColumn = 'EBELN'
            grid.clickCurrentCell()  # ME21N 상세화면으로 drill-down
            time.sleep(1.5)  # ME21N 로딩 대기 (기존 1.0 → 1.5)
            po_field = session.findById(
                'wnd[0]/usr/subSUB0:SAPLMEGUI:0020/subSUB0:SAPLMEGUI:0030/subSUB1:SAPLMEGUI:1105/txtMEPO_TOPLINE-EBELN'
            )
            po_number = (po_field.text or '').strip()
            # 뒤로가기 3번 — 매크로에서 확인된 복귀 경로.
            for _ in range(3):
                session.findById('wnd[0]/tbar[0]/btn[3]').press()
                time.sleep(0.4)
        except Exception as e:
            # 오더는 저장됐으므로 raise 대신 경고만 — po_number는 None 상태로 유지
            print(f'[DEBUG] drill-down 오더번호 읽기 실패: {e}', file=sys.stderr)

    if not po_number:
        raise RuntimeError('구매오더는 저장됐지만 오더번호를 읽지 못했습니다 — SAP에서 직접 확인해주세요.')

    print_result = print_po_via_zmm018(po_number, purchasing_org, plant, currency)
    return {'ok': True, 'poNumber': po_number,
            'autoSaved': print_result.get('autoSaved', False),
            'pdfPath': print_result.get('pdfPath'),   # 발주서 PDF 경로(자동저장 성공 시에만 유효)
            'message': f'구매오더 "{po_number}"가 생성되어 저장됐습니다. ' + print_result.get('message', '')}


_PO_PDF_OUT_DIR = os.path.join('C:\\SAP_DMS', '구매오더')


def _sap_frontend_window():
    """pywinauto로 SAP GUI 프런트엔드 창을 찾는다(class_name이 항상 'SAP_FRONTEND_SESSION'
    임을 실사용 진단으로 확인함) — 아래 `_save_po_pdf_to_file`가 SAP GUI Scripting이 닿지
    않는 임베드 PDF 뷰어를 다루기 위해 사용."""
    from pywinauto import Desktop
    for w in Desktop(backend='uia').windows():
        try:
            if w.element_info.class_name == 'SAP_FRONTEND_SESSION':
                return w
        except Exception:
            continue
    return None


def _save_po_pdf_to_file(save_path):
    """**2026-09-15 신규, 실사용 화면 녹화로 필요성이 확인됨 — SAP GUI Scripting이 아닌
    별도 계층(Windows UI Automation, `pywinauto`)을 쓴다.** "발주서출력"을 누르면 뜨는
    PDF 미리보기는 SAP GUI 안에 임베드된 순수 HTML/PDF 렌더링 콘텐츠라(`wnd[1]/usr/
    cntlHTML/shellcont/shell`의 `SAP.HTMLControl.1` — 라이브 진단으로 그 안쪽엔 더 이상
    자식 컨트롤이 없음을 확인) `session.findById`로 그 안의 저장 아이콘을 직접 클릭할
    방법이 없다. 사용자가 보내준 화면 녹화를 보면: 그 저장 아이콘을 누르면 네이티브
    Windows "사본 저장..." 다이얼로그가 뜨고, 거기서 파일명(=오더번호)·형식(PDF)을
    지정해야 비로소 실제 파일이 만들어진다 — 이 네이티브 다이얼로그도 SAP GUI
    Scripting으로는 못 잡는 영역(SAP 문서 열기 기능에서 이미 겪은 것과 같은 제약)이라,
    Ctrl+S(안 되면 Ctrl+Shift+S) 표준 단축키를 SAP 창에 직접 보내 다이얼로그를 띄운 뒤,
    그 다이얼로그의 파일명 입력란에 전체 경로를 직접 입력하는 방식으로 자동화한다.
    ⚠️⚠️ **이 함수는 아직 라이브 검증 전이다** — Claude Code 세션이 Bash로 직접
    "키보드 입력을 다른 창에 보내는" 동작(SAP GUI Scripting보다 훨씬 넓은 범위의 OS
    자동화)을 실행하려 하자 harness의 자동 모드 분류기가 차단해서, 이 세션 안에서는
    테스트를 끝까지 하지 못했다(위 `confirm_save_po`가 harness에 막혔던 것과 같은 종류의
    안전장치 — 우회 시도하지 않음). 실제 앱(브라우저 → kortek_backend.py → 이 서브프로세스)
    경로는 Claude Code Bash를 거치지 않으므로 이 차단과 무관하다. 문제가 생기면 이 함수
    부터 의심하고, 필요하면 사용자가 직접 `py -3-32 sap_bridge_32.py print_po_via_zmm018
    <오더번호>`를 자기 터미널에서 실행해 재현/디버깅할 것(그 경우엔 harness 차단이
    없으므로 실제 동작을 볼 수 있음)."""
    from pywinauto.keyboard import send_keys
    from pywinauto import Desktop

    sap_win = _sap_frontend_window()
    if sap_win is None:
        raise RuntimeError('SAP GUI 창을 찾지 못해 PDF 저장 다이얼로그를 띄울 수 없습니다.')

    import ctypes as _ct_pre
    from pywinauto import Desktop as _Desktop_pdf

    # ⚠️ [2026-09-28 v6] PDF 미리보기가 wnd[1]로 별도 최상위 창으로 열리는 경우가 있음.
    # 이전 코드: sap_win.descendants()에서 "PDF"/"미리보기" 이름의 자식을 click_input()
    # → 문제: 그 요소가 탭/버튼이면 클릭 시 화면이 전환되어 PDF 뷰어가 닫힐 수 있음.
    # → 문제: set_focus()는 OS 전경(SetForegroundWindow)을 보장하지 않아 단축키가 엉뚱한 창으로 감.
    # 수정: (1) 최상위 창 레벨에서 "PDF 미리보기" 창(또는 추가 SAP 창)을 찾아 대상으로 삼고,
    #        (2) SetForegroundWindow로 OS 전경을 확실히 보장한 뒤,
    #        (3) 창 중앙(콘텐츠 영역)을 클릭해 임베드 PDF 컨트롤에 키보드 포커스를 줌.
    #            (자식 요소 이름 검색 → click 방식은 탭버튼 오동작 위험이 있어 제거)
    # [2026-09-29 버그수정] 2건 이상 배치 처리 시 1번째 PDF가 Acrobat으로 열려있으면
    # "PDF" 제목에서 break → Acrobat을 대상 창으로 잘못 선택하는 버그 수정.
    # SAP_FRONTEND 클래스 창(wnd[1])을 최우선으로 찾고, 없을 때만 "PDF/미리보기" 제목 창을 폴백으로.
    pdf_target_win = None
    _pdf_title_fallback = None
    try:
        for _w in _Desktop_pdf(backend='uia').windows():
            try:
                _title = _w.window_text() or ''
                _cls = _w.element_info.class_name or ''
            except Exception:
                continue
            if 'SAP_FRONTEND' in _cls and _w.handle != sap_win.handle:
                pdf_target_win = _w  # SAP wnd[1] — 최우선
                break
            if _pdf_title_fallback is None and ('PDF' in _title or '미리보기' in _title):
                _pdf_title_fallback = _w  # Acrobat 등 — SAP wnd[1]이 없을 때만 사용
    except Exception:
        pass
    if pdf_target_win is None:
        pdf_target_win = _pdf_title_fallback
    target_win = pdf_target_win or sap_win

    # OS 레벨 전경 전환 → 이후 send_keys가 확실히 이 창으로 감
    _ct_pre.windll.user32.SetForegroundWindow(target_win.handle)
    time.sleep(0.5)

    # 창 중앙 클릭: 임베드 PDF 컨트롤에 키보드 포커스 전달
    try:
        _r = target_win.rectangle()
        _cx = (_r.left + _r.right) // 2 - _r.left
        _cy = (_r.top + _r.bottom) // 2 - _r.top
        target_win.click_input(coords=(_cx, _cy))
    except Exception:
        pass
    time.sleep(0.5)

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # [2026-09-28 v8] 라이브 테스트로 확인한 방식으로 전면 재작성
    # 핵심 발견:
    # 1) 다이얼로그 제목이 '사본 저장...' — UIA Desktop.windows()에서 안 보임.
    #    win32gui.EnumWindows로 class=#32770 + 제목에 '저장' 포함으로 찾아야 함.
    # 2) AttachThreadInput(my_tid, dlg_tid) + SetFocus(Edit_HWND) 후 send_keys
    #    → 파일이름 입력란에 확실히 타이핑 됨 (GetFocus()가 0x0이어도 동작).
    # 3) 파일이름 Edit은 y좌표 두 번째(EnumChildWindows로 class=Edit 탐색).
    # 4) 저장 버튼은 mouse_event 절대좌표 클릭.
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    import win32gui as _wg, win32con as _wc, win32api as _wa, win32process as _wp

    def _find_save_dialog_win32(timeout_sec):
        """win32gui.EnumWindows로 '사본 저장' 다이얼로그(#32770) 탐색."""
        deadline = time.time() + timeout_sec
        while time.time() < deadline:
            found = []
            def _cb(hwnd, _):
                try:
                    t = _wg.GetWindowText(hwnd)
                    cls = _wg.GetClassName(hwnd)
                    if ('저장' in t or 'Save' in t or 'save' in t) and cls == '#32770':
                        found.append(hwnd)
                except Exception:
                    pass
            _wg.EnumWindows(_cb, None)
            if found:
                return found[0]
            time.sleep(0.3)
        return None

    def _find_filename_edit(dlg_hwnd):
        """다이얼로그 안에서 파일이름 Edit 컨트롤 HWND 반환.
        구조: 다이얼로그 → ComboBoxEx32 → ComboBox → Edit (class=Edit, y좌표 두 번째).
        """
        children = []
        def _cb2(hwnd, _):
            try:
                if _wg.GetClassName(hwnd) == 'Edit':
                    r = _wg.GetWindowRect(hwnd)
                    children.append((hwnd, r[3]))  # (handle, y_bottom)
            except Exception:
                pass
        _wg.EnumChildWindows(dlg_hwnd, _cb2, None)
        # y_bottom 내림차순: [0]=파일형식콤보내부Edit, [1]=파일이름Edit
        children.sort(key=lambda x: x[1], reverse=True)
        if len(children) >= 2:
            return children[1][0]
        return children[0][0] if children else None

    def _find_save_button(dlg_hwnd):
        """다이얼로그 안에서 '저장' 버튼 HWND 반환."""
        result = []
        def _cb3(hwnd, _):
            try:
                t = _wg.GetWindowText(hwnd)
                cls = _wg.GetClassName(hwnd)
                if cls == 'Button' and ('저장' in t or t == '&Save' or t == 'Save'):
                    result.append(hwnd)
            except Exception:
                pass
        _wg.EnumChildWindows(dlg_hwnd, _cb3, None)
        return result[0] if result else None

    # 단축키 전송으로 다이얼로그 오픈
    for shortcut in ('^+s', '^s'):
        send_keys(shortcut, pause=0.05)
        time.sleep(1.5)
        dlg_h = _find_save_dialog_win32(5)
        if dlg_h:
            break
    if not dlg_h:
        raise RuntimeError('PDF 저장 다이얼로그("사본 저장...")가 열리지 않았습니다 — PDF 미리보기가 열려 있는지 확인하세요.')

    edit_h = _find_filename_edit(dlg_h)
    btn_h  = _find_save_button(dlg_h)
    if edit_h is None:
        raise RuntimeError('파일이름 Edit 컨트롤을 찾지 못했습니다.')

    import ctypes as _ct
    # 스레드 입력 연결 → SetFocus로 Edit에 포커스
    dlg_tid, _ = _wp.GetWindowThreadProcessId(dlg_h)
    my_tid = _ct.windll.kernel32.GetCurrentThreadId()
    _ct.windll.user32.AttachThreadInput(my_tid, dlg_tid, True)
    _ct.windll.user32.SetForegroundWindow(dlg_h)
    time.sleep(0.2)
    _ct.windll.user32.SetFocus(edit_h)
    time.sleep(0.2)
    _ct.windll.user32.AttachThreadInput(my_tid, dlg_tid, False)

    # 파일이름 입력: Ctrl+A → 직접 타이핑 (클립보드 사용 안 함)
    # ⚠️ 이전(v8) 클립보드 방식(_set_windows_clipboard_text + Ctrl+V)은
    # Excel이 클립보드 변경을 감지해 "클립보드에 많은 양의 내용" 팝업을 띄움.
    # send_keys는 파일 경로 문자(\, :, 한글, 숫자 등)를 특수문자 없이 직접 전송 가능.
    # pywinauto send_keys 특수문자({, }, +, ^, %, (, ), ~)를 이스케이프 처리.
    import re as _re
    _safe_path = _re.sub(r'([{}+^%()~])', r'{\1}', save_path)
    send_keys('^a')
    time.sleep(0.1)
    send_keys(_safe_path, with_spaces=True)
    time.sleep(0.3)

    # 저장 버튼 클릭 (버튼 못 찾으면 Enter로 폴백)
    if btn_h:
        r = _wg.GetWindowRect(btn_h)
        cx = (r[0] + r[2]) // 2
        cy = (r[1] + r[3]) // 2
        _wa.SetCursorPos((cx, cy))
        time.sleep(0.05)
        _wa.mouse_event(_wc.MOUSEEVENTF_LEFTDOWN, cx, cy, 0, 0)
        time.sleep(0.05)
        _wa.mouse_event(_wc.MOUSEEVENTF_LEFTUP, cx, cy, 0, 0)
    else:
        send_keys('{ENTER}')
    time.sleep(1.0)

    # "파일이 이미 있습니다 — 덮어쓰시겠습니까?" 같은 확인창이 뜰 수 있음 — 뜨면 Enter로 승인.
    for w in Desktop(backend='uia').windows():
        try:
            title = w.window_text()
        except Exception:
            continue
        if '확인' in title or 'Confirm' in title:
            send_keys('{ENTER}')
            break
    time.sleep(0.5)

    if not os.path.exists(save_path):
        raise RuntimeError(f'저장 다이얼로그는 처리했지만 파일이 생성되지 않았습니다({save_path}) — 다이얼로그 상태를 SAP 화면에서 직접 확인해주세요.')
    return save_path


def _mb52_multi_select(session, wnd, matnr_list):
    """MB52 선택 화면에서 자재번호 복수 입력.
    단일: MATNR-LOW에 직접 입력.
    복수: VALU_PUSH 버튼 클릭 → 대화상자 테이블에 한 줄씩 입력 → F8(복사).
    반환: 실제로 MB52에 입력된 자재번호 집합 (대화상자 실패 시 첫 번째만)."""
    matnr_low_f = _find_by_id_substring(wnd, 'MATNR-LOW')

    if len(matnr_list) == 1:
        if matnr_low_f:
            matnr_low_f.text = matnr_list[0]
        return set(matnr_list)

    # 다중값 버튼 클릭
    valu_btn = _find_by_id_substring(wnd, 'MATNR_%_APP_%-VALU_PUSH')
    if valu_btn is None:
        if matnr_low_f:
            matnr_low_f.text = matnr_list[0]
        return {matnr_list[0]}

    try:
        valu_btn.press()
        time.sleep(1.0)
        dlg = session.findById('wnd[1]')
    except Exception:
        if matnr_low_f:
            matnr_low_f.text = matnr_list[0]
        return {matnr_list[0]}

    # 표준 SAP 선택 옵션 대화상자 테이블 — 경로는 SAP 버전에 따라 달라질 수 있어
    # 두 가지 공통 경로를 순서대로 시도하고, 둘 다 실패하면 id substring 탐색.
    _DLG_LOW_PATHS = [
        'wnd[1]/usr/tabsTAB_STRIP/tabpSIVA/ssubSUBSCREEN_AREA:SAPLSSEL:1105/tblSAPSELECTION_SCREEN_T/ctxtSELECTION_SCREEN_T-LOW[2,{i}]',
        'wnd[1]/usr/tblSELECT_OPTION_T/ctxtSELECT_OPTION_T-LOW[1,{i}]',
    ]
    entered = set()
    for i, matnr in enumerate(matnr_list):
        cell = None
        for tmpl in _DLG_LOW_PATHS:
            try:
                cell = session.findById(tmpl.format(i=i))
                break
            except Exception:
                pass
        if cell is None:
            break  # 대화상자 구조 불명 → 여기까지만
        try:
            cell.text = matnr
            entered.add(matnr)
        except Exception:
            break

    try:
        dlg.sendVKey(8)  # F8 = 복사
        time.sleep(0.5)
    except Exception:
        try:
            dlg.sendVKey(12)
        except Exception:
            pass

    if not entered:
        # 대화상자 입력 전부 실패 → fallback
        if matnr_low_f:
            matnr_low_f.text = matnr_list[0]
        return {matnr_list[0]}
    return entered


def _query_stock_via_mb52(matnr_list, werks='1000'):
    """MB52로 자재 리스트 창고 재고 일괄조회.
    반환: {found: {matnr: labst_total}, t133e: bool}
    - found: 결과 그리드에서 읽은 자재별 합산 재고
    - t133e: T133E 팝업이 발생해 일부 자재가 누락됐을 가능성
    실측 덤프 기반 구현 (2026-10-01): MATNR-LOW=ctxtMATNR-LOW,
      WERKS-LOW=ctxtWERKS-LOW, VALU_PUSH=btn%_MATNR_%_APP_%-VALU_PUSH."""
    session = _get_sap_session()
    _sap_close_stray_popups(session)

    session.findById('wnd[0]/tbar[0]/okcd').text = '/nMB52'
    wnd = session.findById('wnd[0]')
    wnd.sendVKey(0)
    time.sleep(1.0)
    wnd = session.findById('wnd[0]')

    entered = _mb52_multi_select(session, wnd, matnr_list)

    werks_f = _find_by_id_substring(wnd, 'WERKS-LOW')
    if werks_f:
        werks_f.text = werks

    wnd.sendVKey(8)  # F8 실행
    time.sleep(2.5)

    t133e = False
    # T133E 팝업이 떴으면 닫고 계속 (팝업 닫힌 후 결과 그리드가 있을 수 있음)
    try:
        popup = session.findById('wnd[1]')
        popup_text = (popup.Text or '').upper()
        if 'T133E' in popup_text or 'T133' in popup_text:
            t133e = True
        popup.sendVKey(12)
        time.sleep(0.5)
    except Exception:
        pass

    wnd = session.findById('wnd[0]')
    shell = _sap_find_grid(wnd)
    if shell is None:
        return {'found': {}, 't133e': t133e}

    grid_text = _sap_dump_grid(shell)
    if not grid_text:
        return {'found': {}, 't133e': t133e}

    def _parse_sap_num(s):
        s = (s or '').strip()
        if not s or s == '-':
            return 0.0
        # SAP Korean: comma = 천단위 구분자. "9,641" → 9641
        if '.' in s and ',' in s:
            last_dot = s.rfind('.')
            last_comma = s.rfind(',')
            if last_comma > last_dot:  # German: "1.234,56"
                return float(s.replace('.', '').replace(',', '.'))
            else:  # US: "1,234.56"
                return float(s.replace(',', ''))
        if ',' in s:
            return float(s.replace(',', ''))   # "9,641" → 9641
        if '.' in s:
            parts = s.split('.')
            if len(parts) == 2 and len(parts[1]) == 3:
                return float(parts[0])
            return float(s)
        try:
            return float(s)
        except Exception:
            return 0.0

    lines = grid_text.split('\n')
    if not lines:
        return {'found': {}, 't133e': t133e}
    headers = lines[0].split('\t')

    def _ci(name):
        for idx, h in enumerate(headers):
            if name.upper() in h.upper():
                return idx
        return -1

    matnr_i = _ci('MATNR')
    labst_i = _ci('LABST')
    if matnr_i < 0 or labst_i < 0:
        return {'found': {}, 't133e': t133e}

    found = {}
    for line in lines[1:]:
        if not line.strip():
            continue
        cells = line.split('\t')
        def _g(i): return cells[i].strip() if 0 <= i < len(cells) else ''
        matnr = _g(matnr_i)
        if not matnr:
            continue
        labst = _parse_sap_num(_g(labst_i))
        found[matnr] = found.get(matnr, 0.0) + labst  # 저장위치별 합산

    return {'found': found, 't133e': t133e}


def _query_stock_via_mm03(matnr, werks='1000'):
    """MM03 '회계 1' LBKUM 단일 자재 조회. MB52 fallback용."""
    def _parse_lbkum(raw):
        s = (raw or '').strip()
        if not s or s == '-':
            return 0.0
        # SAP Korean: comma = 천단위 구분자 (US format). "9,641" → 9641, not 9.641
        if '.' in s and ',' in s:
            last_dot = s.rfind('.')
            last_comma = s.rfind(',')
            if last_comma > last_dot:  # German: "1.234,56"
                return float(s.replace('.', '').replace(',', '.'))
            else:  # US: "1,234.56"
                return float(s.replace(',', ''))
        if ',' in s:
            return float(s.replace(',', ''))   # "9,641" → 9641
        if '.' in s:
            parts = s.split('.')
            if len(parts) == 2 and len(parts[1]) == 3:
                return float(parts[0])
            return float(s)
        try:
            return float(s)
        except Exception:
            # 🐛🐛 [2026-10-02] 파싱 실패를 0.0으로 삼키면 "재고 0개"라는 **틀린 답**이
            #   그대로 사용자에게 나간다(실제로 라벨 "총 재고"를 집어와 0이 나가고 있었다).
            #   조회 실패는 실패로 드러낼 것 — CLAUDE.md "조용히 삼키지 말 것".
            raise RuntimeError(f'재고 수치를 해석하지 못했습니다: "{raw}"')

    session = _get_sap_session()
    _sap_close_stray_popups(session)
    wnd = session.findById('wnd[0]')
    _navigate_to_material_screen(session, wnd, matnr)

    found = _select_tab_with_retry(wnd, 'tabpSP24')
    if not found:
        raise RuntimeError(f'자재 {matnr}: "회계 1" 탭을 찾지 못했습니다.')

    lbkum_raw = None
    for _attempt in range(6):
        time.sleep(0.5)
        wnd = session.findById('wnd[0]')
        # ⚠️ 'LBKUM'만 쓰면 lblCKMLPP-LBKUM(라벨 .Text="총 재고")이 먼저 걸려 0이 나간다
        #    — _MATERIAL_PRICE_FIELD_IDS 위 주석 참고(2026-10-02 덤프로 확인).
        field = _find_by_id_substring(wnd, 'txtCKMLPP-LBKUM')
        if field is not None:
            lbkum_raw = str(field.Text).strip()
            break

    if lbkum_raw is None:
        raise RuntimeError(f'자재 {matnr}: LBKUM 필드를 찾지 못했습니다.')

    return _parse_lbkum(lbkum_raw), lbkum_raw


def query_mard_stock(matnr_input, werks='1000'):
    """자재 재고 조회.
    - 자재 1개  : MB52 + MM03 **둘 다** 조회해 나란히 보여준다(2026-10-02 사용자 요청).
    - 자재 2개+ : MB52 일괄(빠름)만 쓰고 누락분만 MM03 fallback — MM03은 자재당 화면을
                  순회해서 복수 조회 시 급격히 느려지므로 의도적으로 예외 적용.
    matnr_input에 쉼표로 여러 자재번호 지정 가능.
    반환: {ok, results:[{matnr,werks,labst,mb52Labst?,mm03Lbkum?,source,text}], text}
    ⚠️ MB52 LABST(해당 플랜트 가용·비제한 재고)와 MM03 LBKUM(전체 플랜트 평가재고 총계)은
       집계 범위가 다른 값이다 — 두 값이 달라도 버그가 아니므로 답변에 그 사실을 같이 적는다.
    실측: 2026-10-01 덤프 기반 구현. MB52 layout '/MM' 기준 MATNR+LABST 컬럼 합산."""
    matnr_list = [m.strip() for m in matnr_input.split(',') if m.strip()]
    if not matnr_list:
        raise RuntimeError('자재번호를 지정해주세요.')
    single = len(matnr_list) == 1

    # ── 1단계: MB52 일괄 조회 시도 ─────────────────────────────────────────
    mb52_found = {}
    mb52_err = None
    try:
        mb52_res = _query_stock_via_mb52(matnr_list, werks)
        mb52_found = mb52_res.get('found', {})
    except Exception as e:
        mb52_err = str(e)
        print(f'[MB52 실패, MM03 fallback] {e}', file=sys.stderr)

    # ── 2단계: 단일=MB52+MM03 동시 / 복수=MB52 누락분만 MM03 fallback ──────
    results = []

    for matnr in matnr_list:
        if single:
            # 단일 조회는 두 트랜잭션을 모두 읽어 비교 제시(한쪽이 실패해도 다른 쪽은 보여준다)
            labst = mb52_found.get(matnr)
            lbkum_num = lbkum_raw = None
            mm03_err = None
            try:
                lbkum_num, lbkum_raw = _query_stock_via_mm03(matnr, werks)
            except Exception as e:
                mm03_err = str(e)
                print(f'[MM03 실패] {matnr}: {e}', file=sys.stderr)
            if labst is None and lbkum_num is None:
                results.append({
                    'matnr': matnr, 'werks': werks, 'labst': None, 'source': 'error',
                    'mb52Labst': None, 'mm03Lbkum': None,
                    'text': (f'자재 {matnr} 조회 실패 — '
                             f'MB52: {mb52_err or "결과 없음"} / MM03: {mm03_err or "결과 없음"}')
                })
                continue
            lines = [f'자재 {matnr} 재고 (플랜트 {werks})']
            lines.append('  - MB52 가용재고(LABST): '
                         + (f'{labst:.0f} EA' if labst is not None
                            else f'조회 실패 ({mb52_err or "결과 없음"})'))
            lines.append('  - MM03 회계1 전체평가재고(LBKUM): '
                         + (f'{lbkum_raw} EA' if lbkum_num is not None
                            else f'조회 실패 ({mm03_err or "결과 없음"})'))
            if labst is not None and lbkum_num is not None and abs(labst - lbkum_num) > 0.5:
                lines.append('  * 두 값은 집계 범위가 달라 차이가 날 수 있습니다'
                             ' (MB52=해당 플랜트 가용 / MM03=전체 플랜트 평가재고).')
            results.append({
                'matnr': matnr, 'werks': werks,
                'labst': labst if labst is not None else lbkum_num,
                'mb52Labst': labst, 'mm03Lbkum': lbkum_num,
                'source': 'MB52+MM03', 'text': '\n'.join(lines)
            })
        elif matnr in mb52_found:
            labst = mb52_found[matnr]
            results.append({
                'matnr': matnr, 'werks': werks, 'labst': labst, 'source': 'MB52',
                'text': f'자재 {matnr} 재고 (플랜트 {werks}): {labst:.0f} EA [MB52]'
            })
        else:
            # MM03 fallback
            try:
                lbkum_num, lbkum_raw = _query_stock_via_mm03(matnr, werks)
                results.append({
                    'matnr': matnr, 'werks': werks, 'labst': lbkum_num, 'source': 'MM03',
                    'text': f'자재 {matnr} 재고 (플랜트 {werks}): {lbkum_raw} EA [MM03 회계1]'
                })
            except Exception as e:
                results.append({
                    'matnr': matnr, 'werks': werks, 'labst': None, 'source': 'error',
                    'text': f'자재 {matnr} 조회 실패: {str(e)}'
                })

    # ── 요약 텍스트 ────────────────────────────────────────────────────────
    if len(results) == 1:
        combined_text = results[0]['text']
    else:
        n_mb52 = sum(1 for r in results if r.get('source') == 'MB52')
        n_mm03 = sum(1 for r in results if r.get('source') == 'MM03')
        n_dual = sum(1 for r in results if r.get('source') == 'MB52+MM03')
        if n_dual:
            header = f'[재고 조회: MB52+MM03 동시 {n_dual}건]'
        elif n_mm03:
            header = f'[재고 일괄조회: MB52 {n_mb52}건 + MM03 {n_mm03}건]'
        else:
            header = '[MB52 재고 일괄조회]'
        lines = [header]
        for r in results:
            if r['labst'] is not None:
                lines.append(f'  • {r["matnr"]}: {r["labst"]:.0f} EA')
            else:
                lines.append(f'  • {r["matnr"]}: 조회 실패')
        combined_text = '\n'.join(lines)

    return {'ok': True, 'results': results, 'text': combined_text}


def print_po_via_zmm018(po_number, purchasing_org='9000', plant='1000', currency='KRW'):
    """ZMM018에서 이미 존재하는 구매오더번호로 발주서 PDF를 출력하고, 실제 파일로 저장한
    뒤 연결된 프로그램(Acrobat 등)으로 연다.
    `currency`가 'KRW'가 아니면 ZMM018 진입 전에 ME22N에서 통화를 먼저 변경한다
    (사용자 요청: "통화 변경은 구매 발주서 출력 화면에서 발주번호 누르고 들어가서 변경" — 2026-10-01).
    `confirm_save_po`가 저장 직후 자동 호출하고, 이미 저장된 오더번호로 출력만 재시도하는 복구
    용도로도 쓸 수 있다. 저장(SAVE)이 전혀 없는 순수 조회/출력 동작이라 저장보다 안전하다."""

    # [2026-10-01] USD 등 KRW가 아닌 통화: ZMM018 출력 전에 ME22N에서 WAERS 변경
    if currency and currency.upper() != 'KRW':
        try:
            _change_po_currency_in_me22n(po_number, currency)
        except Exception as e:
            print(f'[경고] ME22N 통화 변경 실패 (통화: {currency}), KRW로 발주서 출력 계속 진행: {e}', file=sys.stderr)
            # 실패해도 중단하지 않음 — 발주는 이미 저장됐으므로 발주서 출력은 가능

    session = _get_sap_session()
    try:
        session.findById('wnd[0]/tbar[0]/okcd').text = '/nZMM018'
        wnd = session.findById('wnd[0]')
        wnd.sendVKey(0)
        time.sleep(0.8)
        wnd = session.findById('wnd[0]')
        _set_text_on_best_candidate(wnd, 'S_EKORG-LOW', purchasing_org)
        _set_text_on_best_candidate(wnd, 'S_WERKS-LOW', plant)
        ebeln_field = _set_text_on_best_candidate(wnd, 'S_EBELN-LOW', po_number)
        if ebeln_field is None:
            raise RuntimeError('ZMM018 화면에서 오더번호 입력 필드를 찾지 못했습니다.')
        session.findById('wnd[0]/tbar[1]/btn[8]').press()  # 실행(F8)
        time.sleep(1.5)

        # ZMM018 결과 그리드는 `wnd[0]/shellcont/shell`(ZMMR060과 달리 한 단계만 중첩 —
        # 매크로에서 확인된 절대경로).
        try:
            out_grid = session.findById('wnd[0]/shellcont/shell')
        except Exception:
            out_grid = _find_by_id_substring(session.findById('wnd[0]'), 'shellcont/shell', require_type='GuiShell')
        out_grid.currentCellColumn = ''
        out_grid.selectedRows = '0'
        session.findById('wnd[0]/tbar[1]/btn[13]').press()  # 출력(미리보기 표시) — 매크로에서 확인된 인덱스
        # ⚠️ [2026-09-15 사용자 실사용 관찰 반영] 미리보기가 뜨자마자 단축키를 보내면
        # 렌더링이 덜 끝난 상태라 반응이 없거나(또는 뜬 걸 감지하기 전에 다른 요인으로
        # 사라지는 것처럼 보임 — "다이얼로그가 금방 닫힌다"는 사용자 제보) 놓치는 것으로
        # 보여, 3초 대기 후 단축키를 보내도록 늘림(기존 2초 → 3초).
        time.sleep(3.0)
    except Exception as e:
        raise RuntimeError(f'구매오더("{po_number}") 발주서 미리보기 표시(ZMM018) 중 오류가 발생했습니다: {e} — ZMM018에서 오더번호 "{po_number}"로 직접 출력해주세요.')

    # ⚠️ [2026-09-15 사용자 결정] 여러 차례 시도했지만(Ctrl+S/Ctrl+Shift+S 순서 변경,
    # 클릭 포커스 보강, "PDF 미리보기" 요소 직접 클릭) 임베드 PDF 뷰어의 저장 다이얼로그를
    # 자동으로 못 띄움 — 사용자가 "그냥 사용자가 열고 저장해야 하나보다"라고 결론 내림.
    # 그래서 이 마지막 한 걸음(💾 아이콘 클릭)은 **사람이 직접 하는 것으로 확정**하고,
    # 자동화 실패를 오류로 취급하지 않는다 — 여기까지(미리보기를 여는 것) 자동으로 되면
    # 이미 대부분의 수고를 던 것이므로 `ok: True`로 정상 완료 처리하고, 저장은 안내만 한다.
    # (이 함수 자체는 남겨둠 — 나중에 임베드 뷰어의 정확한 단축키/컨트롤을 알게 되면
    # 다시 켤 수 있도록.)
    os.makedirs(_PO_PDF_OUT_DIR, exist_ok=True)
    pdf_path = os.path.join(_PO_PDF_OUT_DIR, f'{po_number}.pdf')
    auto_saved = False
    _last_err = None
    for _try in range(3):  # 최대 3회 재시도
        try:
            _save_po_pdf_to_file(pdf_path)
            auto_saved = True
            break
        except Exception as e:
            _last_err = e
            print(f'[구매오더 PDF 자동저장 시도 {_try + 1}/3 실패] {e}', file=sys.stderr)
            if _try < 2:
                time.sleep(2.0)

    if auto_saved:
        try:
            os.startfile(pdf_path)
        except Exception:
            pass
        return {'ok': True, 'poNumber': po_number, 'pdfPath': pdf_path, 'autoSaved': True,
                'message': f'구매오더 "{po_number}"의 발주서 PDF를 "{pdf_path}"로 저장하고 열었습니다.'}

    # 3회 모두 실패 — pdfPath는 None(파일 미존재), 수동 출력 안내
    return {'ok': True, 'poNumber': po_number, 'autoSaved': False, 'pdfPath': None,
            'message': f'구매오더 "{po_number}" 발주서 PDF 자동저장에 3번 실패했습니다 — ZMM018을 직접 열어 오더번호 "{po_number}"로 발주서를 출력해주세요. (마지막 오류: {_last_err})'}


# ── 🆕 [2026-09-21, Phase 10] 실패 화면 스냅샷 — "구조만" 저장 (docs/phase10-issue-learning-design.md §3-C) ──
# 목적: 사용자의 라이브 SAP 세션 없이도 "라벨 컨트롤에 값을 넣음/그리드 열 위치 밀림/팝업 잔존/필수 필드
# 미입력" 같은 실패 유형을 원격으로 판별. 읽기 전용(클릭·입력 없음), 자체 예외 처리, 시간·크기 상한.
# 필드 **값**(GuiTextField/GuiCTextField/테이블·그리드 셀)은 저장하지 않는다 — 캡션성 컨트롤
# (라벨/버튼/탭/제목)의 Text와 상태바 문구만 저장하고, 5자리 이상 숫자열은 '#'으로 마스킹한다.
_SNAP_CAPTION_TYPES = ('GuiLabel', 'GuiButton', 'GuiTab', 'GuiTitlebar')
_SNAP_SKIP_DESCEND = ('GuiMenubar', 'GuiTitlebar', 'GuiStatusbar', 'GuiTableControl', 'GuiTree')
_SNAP_MAX_NODES = 200
_SNAP_MAX_SECONDS = 2.0
_SNAP_MAX_BYTES = 24000


def _snap_mask(text, limit=120):
    try:
        t = re.sub(r'\d{5,}', '#', str(text))
        t = re.sub(r'[\w.+-]+@[\w-]+\.[\w.-]+', '#mail', t)
        return t[:limit]
    except Exception:
        return ''


def _capture_failure_snapshot():
    """실패 직후 지금 SAP 화면의 구조를 dict로 반환한다. 세션을 못 얻거나 어떤 이유로든 실패하면
    None — 절대 예외를 던지지 않는다(실패 보고 자체를 방해하면 안 됨)."""
    t0 = time.time()
    try:
        session = _get_sap_session()
    except Exception:
        return None
    snap = {}
    try:
        info = session.Info
        for k, attr in (('tcode', 'Transaction'), ('program', 'Program'), ('screen', 'ScreenNumber')):
            try:
                snap[k] = str(getattr(info, attr))
            except Exception:
                pass
    except Exception:
        pass
    try:
        snap['windows'] = int(session.Children.Count)  # 2 이상이면 팝업이 남아있다는 뜻
    except Exception:
        pass
    try:
        sb = session.findById('wnd[0]/sbar')
        snap['status'] = {'t': str(sb.MessageType), 'text': _snap_mask(sb.Text, 200)}
    except Exception:
        pass
    nodes = []
    try:
        win_count = int(session.Children.Count)
    except Exception:
        win_count = 1
    for wi in range(min(win_count, 3)):
        try:
            wnd = session.findById('wnd[%d]' % wi)
        except Exception:
            continue
        try:
            nodes.append(['GuiWindow', 'wnd[%d]' % wi, '', 1, _snap_mask(wnd.Text, 80)])
        except Exception:
            pass
        queue = [(wnd, 0)]
        while queue and len(nodes) < _SNAP_MAX_NODES and (time.time() - t0) < _SNAP_MAX_SECONDS:
            node, depth = queue.pop(0)
            try:
                children = node.Children
                count = children.Count
            except Exception:
                continue
            for ci in range(count):
                if len(nodes) >= _SNAP_MAX_NODES or (time.time() - t0) >= _SNAP_MAX_SECONDS:
                    break
                try:
                    ch = children(ci)
                    ctype = str(ch.Type)
                    cid = str(ch.Id)
                    rel = cid.split('ses[0]/', 1)[-1] if 'ses[0]/' in cid else cid
                    try:
                        chg = 1 if ch.Changeable else 0
                    except Exception:
                        chg = -1
                    rec = [ctype, rel, str(getattr(ch, 'Name', '') or ''), chg]
                    if ctype in _SNAP_CAPTION_TYPES:
                        try:
                            rec.append(_snap_mask(ch.Text, 60))
                        except Exception:
                            pass
                    elif ctype == 'GuiShell':
                        try:  # ALV 그리드는 행/열 수와 컬럼 기술명만(값 없음)
                            rec.append({'rows': int(ch.RowCount), 'cols': [str(c) for c in list(ch.ColumnOrder)[:30]]})
                        except Exception:
                            pass
                    nodes.append(rec)
                    if ctype not in _SNAP_SKIP_DESCEND and depth < 8:
                        queue.append((ch, depth + 1))
                except Exception:
                    continue
    snap['tree'] = nodes
    snap['truncated'] = len(nodes) >= _SNAP_MAX_NODES or (time.time() - t0) >= _SNAP_MAX_SECONDS
    # 크기 상한 — 넘으면 트리를 앞에서부터 줄인다
    try:
        while len(json.dumps(snap, ensure_ascii=False)) > _SNAP_MAX_BYTES and snap['tree']:
            snap['tree'] = snap['tree'][:max(1, int(len(snap['tree']) * 0.8))]
            snap['truncated'] = True
    except Exception:
        return None
    snap['ms'] = int((time.time() - t0) * 1000)
    return snap


def _attach_failure_info(result):
    """실패 결과(dict)에 stage/snapshot을 붙여 돌려준다 — 수집 실패는 절대 결과를 바꾸지 않는다."""
    try:
        if _CUR_STAGE[0]:
            result['stage'] = _CUR_STAGE[0]
        snap = _capture_failure_snapshot()
        if snap:
            result['snapshot'] = snap
    except Exception:
        pass
    return result


# ── "자재 입고 처리"(ZMM062) 전용 헬퍼 (2026-09-22 신규, 사용자 제공 매크로 기반) ──────
# ⚠️⚠️ 이건 조회가 아니라 실제 SAP 전기(POSTING) — 재고/회계에 실제 영향을 준다. 구매오더
# 자동화(prepare_po_from_excel → confirm_save_po)와 같은 원칙으로, AI 문답에서 사람이
# "입고 처리 할게요"라고 명시적으로 확인한 뒤에만 호출되고, 그 뒤로는 저장까지 완전
# 자동화한다(중간에 멈추지 않음 — "저장 직전 정지는 폐기"와 동일 원칙, 사용자 요청으로 확정).
# 실사용 매크로("자재 입고 처리(ZMM062).vbs")에서 그대로 가져온 시퀀스 — 일부 단계(초반
# F4 리포트 선택 팝업, "실행 → 뒤로 → 즐겨찾기 더블클릭 → 같은 오더번호로 재실행", 저장 후
# 이어지는 두 번째 저장+확인)는 정확한 이유를 다 이해하지 못한 채 그대로 재현한다(추측
# 금지 원칙 — 그 사람이 실제로 성공했던 시퀀스이므로 "왜 되는지"보다 "그대로 재현"을 택함).
# 매크로의 하드코딩값(오더번호 9100019479, 입고수량 70, 입고일자 20260918)은 그날의 예시
# 값일 뿐이라 그대로 쓰면 안 되므로:
#   - 오더번호(EBELN)는 인자로 받는다.
#   - 입고수량(INQTY)은 **사용자 요청대로 발주수량과 동일**하게 — 이 리포트 자체가 이미
#     "MENGE"(발주수량) 컬럼을 갖고 있어, 하드코딩 대신 그 행의 MENGE 값을 그대로 읽어
#     INQTY에 쓴다(추가 조회 없이 같은 화면 안에서 해결).
#   - 입고일자(INDAT)도 **사용자 요청대로 생성일자와 동일**하게 — 같은 이유로 "AEDAT"
#     (생성일) 컬럼 값을 그대로 읽어 쓴다.
# ⚠️ 즐겨찾기 노드("F00216")는 그 사람 SAP GUI 개인 설정이라 다른 세션/PC에서 그대로
# 재현된다는 보장이 없음 — 있으면 쓰고, 실패하면(예외) 이미 한 번 실행해둔 화면을 그대로 쓴다.
def post_goods_receipt(ebeln, dump_only=False):
    """ZMM062에서 구매오더 `ebeln`의 자재를 입고 처리(전기)한다.
    입고수량=발주수량(MENGE), 입고일자=오늘(F4 날짜선택).
    시퀀스는 사용자가 기록한 VBS 매크로(입고처리.vbs) 기준으로 재작성됨.
    dump_only=True: 그리드 화면까지만 이동 후 스크린 덤프 반환 (실제 전기 안 함)."""
    ebeln = (ebeln or '').strip()
    if not ebeln:
        raise RuntimeError('구매오더 번호(EBELN)를 지정해주세요.')

    today = time.strftime('%Y%m%d')
    session = _get_sap_session()

    # VBS: 즐겨찾기(F00216) → ZMM062 → PO번호 입력 → F8 실행
    # 즐겨찾기 경로로 먼저 시도, 실패 시 /nZMM062 직접 입력
    _nav_ok = False
    try:
        session.findById(
            'wnd[0]/usr/cntlIMAGE_CONTAINER/shellcont/shell/shellcont[0]/shell'
        ).doubleClickNode('F00216')
        time.sleep(1.0)
        _nav_ok = True
    except Exception:
        pass
    if not _nav_ok:
        try:
            session.findById('wnd[0]/tbar[0]/okcd').text = '/nZMM062'
            session.findById('wnd[0]').sendVKey(0)
            time.sleep(1.0)
        except Exception as e:
            raise RuntimeError(f'ZMM062 진입 실패: {e}')

    # 구매오더 번호 입력 → 실행(F8)
    wnd = session.findById('wnd[0]')
    try:
        wnd.findById('usr/ctxtS_EBELN-LOW').text = ebeln
        wnd.findById('usr/ctxtS_EBELN-LOW').setFocus()
        wnd.findById('usr/ctxtS_EBELN-LOW').caretPosition = len(ebeln)
        wnd.findById('tbar[1]/btn[8]').press()
        time.sleep(1.2)
    except Exception as e:
        raise RuntimeError(f'ZMM062 구매오더 번호 입력/실행 중 오류: {e}')

    wnd = session.findById('wnd[0]')
    try:
        grid = wnd.findById('shellcont/shell')
    except Exception as e:
        raise RuntimeError(f'입고 처리 입력 화면(그리드)을 찾지 못했습니다: {e}')

    try:
        row_count = grid.RowCount
    except Exception:
        row_count = 0
    if not row_count:
        raise RuntimeError(f'구매오더 "{ebeln}"에 대해 입고 대기 중인 품목이 없습니다 — 이미 처리됐거나 오더번호를 확인해주세요.')

    # dump_only 모드: 그리드 화면 덤프만 반환 (실제 전기 없음)
    if dump_only:
        _dump_lines = []
        try:
            _dump_lines.append(f'GridType={grid.Type}, RowCount={row_count}')
            # 첫 번째 행 모든 컬럼 값 읽기 시도
            _sample_cols = ['MENGE','INQTY','INDAT','ERFMG','WBDAT','BLDAT','BUDAT',
                            'WEMPF','UMENG','WMENGE','BWTAR','LGORT','CHARG','EBELN',
                            'EBELP','MATNR','MAKTX','MEINS','LICHA','ZEINR']
            _row_vals = {}
            for _c in _sample_cols:
                try:
                    _v = grid.GetCellValue(0, _c)
                    _row_vals[_c] = str(_v)
                except Exception as _e:
                    _row_vals[_c] = f'ERR:{_e}'
            _dump_lines.append('행0 샘플컬럼값: ' + str(_row_vals))
            # 그리드 type 속성
            for _attr in ['ColumnCount','RowCount','FirstVisibleRow','CurrentCellRow','CurrentCellColumn']:
                try:
                    _dump_lines.append(f'{_attr}={getattr(grid, _attr)}')
                except Exception as _e:
                    _dump_lines.append(f'{_attr}=ERR:{_e}')
        except Exception as _de:
            _dump_lines.append(f'덤프오류: {_de}')
        # tbar[1] 버튼도 읽기
        _tb = {}
        for _bi in range(20):
            try:
                _b = wnd.findById(f'tbar[1]/btn[{_bi}]')
                _tb[_bi] = (getattr(_b,'Text','') or '') + '/' + (getattr(_b,'Tooltip','') or '')
            except Exception:
                pass
        return {'ok': True, 'dump_only': True, 'dumpLines': _dump_lines, 'tbar1': _tb, 'ebeln': ebeln}

    # ── 각 행: INQTY 입력 → triggerModified → INDAT 설정
    # [2026-09-30 수정] 행 0만 F4 캘린더로 날짜 선택, 행 1+는 modifyCell로 직접 복사
    # (LIFNR 최적화와 동일 패턴 — simulate_indat_copy로 사전 검증됨)
    # [2026-09-29 V01 VBS 기준]
    # 행0:  modifyCell(INQTY) → currentCellColumn='INDAT' → triggerModified → pressF4 → selectionInterval
    # 행1+: modifyCell(INQTY) → currentCellRow=row_idx  → triggerModified → modifyCell(INDAT, indat_row0)
    # (focusDate 없음 — VBS에 없음)
    processed_rows = []
    order_qtys = []
    _debug_steps = []
    _indat_filled = ''  # 행 0 F4 후 읽은 SAP 포맷 날짜값 (행 1+에 재사용)

    for row_idx in range(row_count):
        try:
            order_qty = str(grid.GetCellValue(row_idx, 'MENGE')).strip()
        except Exception as e:
            raise RuntimeError(f'발주수량(MENGE) 읽기 오류 (행 {row_idx}): {e}')
        if not order_qty:
            continue

        # 1. INQTY 입력
        try:
            grid.modifyCell(row_idx, 'INQTY', order_qty)
            time.sleep(0.4)
        except Exception as e:
            raise RuntimeError(f'입고수량(INQTY) 입력 오류 (행 {row_idx}): {e}')

        # 2. 포커스 이동 + triggerModified — INQTY 값 그리드 커밋
        #    행0: currentCellColumn='INDAT', 행1+: currentCellRow=row_idx (VBS 그대로)
        try:
            if row_idx == 0:
                grid.currentCellColumn = 'INDAT'
            else:
                grid.currentCellRow = row_idx
            time.sleep(0.3)
            grid.triggerModified()
            time.sleep(0.5)
        except Exception as e:
            raise RuntimeError(f'triggerModified 오류 (행 {row_idx}): {e}')

        # 3. INDAT 설정
        #    행 0: F4 캘린더 팝업으로 today 선택 (VBS 그대로)
        #    행 1+: modifyCell로 행 0에서 읽은 값 직접 복사 (F4 폴백 포함)
        if row_idx == 0:
            try:
                grid.pressF4()
                time.sleep(1.0)
            except Exception as e:
                raise RuntimeError(f'pressF4(INDAT) 오류 (행 {row_idx}): {e}')

            _cal_set = False
            for _cal_path in [
                'wnd[1]/usr/cntlCONTAINER/shellcont/shell',
                'wnd[1]/usr/cntlCONTAINER/shellcont/shell/shellcont/shell',
            ]:
                try:
                    _cal = session.findById(_cal_path)
                    _cal.selectionInterval = f'{today},{today}'
                    _cal_set = True
                    time.sleep(0.6)
                    break
                except Exception:
                    pass
            if not _cal_set:
                try:
                    session.findById('wnd[1]').sendVKey(0)
                    time.sleep(0.5)
                except Exception:
                    pass
                _debug_steps.append(f'행0: 캘린더 경로 탐색 실패, Enter로 닫기 시도')

            # 행 0의 실제 INDAT 값(SAP 포맷)을 읽어 두기
            try:
                _indat_filled = str(grid.GetCellValue(0, 'INDAT')).strip()
            except Exception:
                _indat_filled = ''
        else:
            # 행 1+: modifyCell로 직접 복사, 실패 시 F4 폴백
            _indat_set = False
            if _indat_filled:
                try:
                    grid.modifyCell(row_idx, 'INDAT', _indat_filled)
                    time.sleep(0.2)
                    # ⚠️ [2026-09-30 버그수정] modifyCell은 F4 캘린더와 달리 커밋을 자동으로
                    #    트리거하지 않는다. 마지막 행은 다음 행 반복의 triggerModified가 없어
                    #    INDAT가 미커밋 상태로 저장 → SAP "입고 날짜 확인" 오류 발생.
                    #    모든 행에서 modifyCell 직후 triggerModified로 즉시 커밋한다.
                    grid.currentCellRow = row_idx
                    grid.triggerModified()
                    time.sleep(0.3)
                    _indat_set = True
                    _debug_steps.append(f'행{row_idx}: INDAT modifyCell+triggerModified 성공({_indat_filled!r})')
                except Exception as _me:
                    _debug_steps.append(f'행{row_idx}: INDAT modifyCell 실패({_me}), F4 폴백')
            if not _indat_set:
                # F4 폴백 (행 0와 동일 시퀀스)
                try:
                    grid.pressF4()
                    time.sleep(1.0)
                except Exception as e:
                    raise RuntimeError(f'pressF4(INDAT) 오류 (행 {row_idx}): {e}')
                _cal_set = False
                for _cal_path in [
                    'wnd[1]/usr/cntlCONTAINER/shellcont/shell',
                    'wnd[1]/usr/cntlCONTAINER/shellcont/shell/shellcont/shell',
                ]:
                    try:
                        _cal = session.findById(_cal_path)
                        _cal.selectionInterval = f'{today},{today}'
                        _cal_set = True
                        time.sleep(0.6)
                        break
                    except Exception:
                        pass
                if not _cal_set:
                    try:
                        session.findById('wnd[1]').sendVKey(0)
                        time.sleep(0.5)
                    except Exception:
                        pass

        # 4. 반영값 확인 (디버그)
        try:
            _chk = str(grid.GetCellValue(row_idx, 'INQTY')).strip()
            _chk_d = str(grid.GetCellValue(row_idx, 'INDAT')).strip()
            _debug_steps.append(f'행{row_idx}: MENGE={order_qty} → INQTY={_chk}, INDAT={_chk_d}')
        except Exception as e:
            _debug_steps.append(f'행{row_idx}: 확인읽기 실패: {e}')

        processed_rows.append(row_idx)
        order_qtys.append(order_qty)

    if not processed_rows:
        raise RuntimeError(f'구매오더 "{ebeln}"에 처리할 수량이 있는 품목이 없습니다.')

    _popup_texts = []

    # ── 전체선택: setCurrentCell(-1,"") → selectAll (V01 VBS 기준)
    try:
        grid.setCurrentCell(-1, '')
        time.sleep(0.3)
        grid.selectAll()
        time.sleep(0.4)
    except Exception:
        pass

    # ── 저장: btn[5] → 팝업 → btn[12] (단일 패스, V01 VBS 기준)
    try:
        wnd.findById('tbar[1]/btn[5]').press()
        time.sleep(2.0)
    except Exception as e:
        raise RuntimeError(f'입고처리 btn[5] 오류: {e} [debug={_debug_steps}]')
    try:
        _w1 = session.findById('wnd[1]')
        _pt2 = ''
        for _pid in ['usr/txtMESSAGE', 'usr/lbl[1,2]', 'usr/lbl[2,2]']:
            try:
                _pt2 = (_w1.findById(_pid).Text or '').strip()
                if _pt2: break
            except Exception:
                pass
        if _pt2:
            _popup_texts.append(f'팝업: {_pt2}')
        _w1.findById('tbar[0]/btn[12]').press()
        time.sleep(2.0)  # 팝업 confirm 후 SAP 전기 완료까지 충분히 대기
    except Exception:
        pass

    # 상태바 확인 — 전기 성공 여부 판정
    # SAP이 전기 후 상태바를 채우는 데 시간이 걸릴 수 있으므로 최대 4회 재시도
    status_text = ''
    for _sbar_try in range(4):
        try:
            status_text = (session.findById('wnd[0]/sbar').Text or '').strip()
        except Exception:
            status_text = ''
        if status_text:
            break
        time.sleep(0.8)

    # "자재 문서 XXXXXXXXXX이(가) 전기되었습니다" 패턴 → 확실한 성공
    _mat_doc_m = re.search(r'자재\s*문서\s*(\d{10})', status_text)
    _mat_doc_no = _mat_doc_m.group(1) if _mat_doc_m else None

    # 오류 키워드 확인
    _sbar_mtype = ''
    try:
        _sbar_mtype = (session.findById('wnd[0]/sbar').MessageType or '').strip()
    except Exception:
        pass
    _is_sbar_error = (_sbar_mtype in ('E', 'A')) or any(
        kw in status_text for kw in ['오류', '불가', '실패', 'Fehler', 'Error', '취소']
    )

    if _is_sbar_error:
        return {
            'ok': False,
            'ebeln': ebeln,
            'error': f'구매오더 "{ebeln}" 입고 처리 중 오류: {status_text}',
            'debug': {'debugSteps': _debug_steps, 'popupTexts': _popup_texts},
        }

    if not status_text:
        # 팝업까지 확인했으면 전기는 거의 확실히 됐으나 문서번호 확인 불가
        return {
            'ok': True,
            'ebeln': ebeln,
            'rowCount': len(processed_rows),
            'orderQtys': order_qtys,
            'goodsReceiptDate': today,
            'statusText': '',
            'message': f'구매오더 "{ebeln}" 입고 처리 저장까지 진행됐습니다 ({len(processed_rows)}건). SAP 상태표시줄이 비어 있어 자재문서 번호를 확인하지 못했습니다 — SAP에서 자재문서가 생성됐는지 직접 확인해주세요.',
            'debug': {'debugSteps': _debug_steps, 'popupTexts': _popup_texts},
        }

    qty_summary = ', '.join(order_qtys) if len(order_qtys) > 1 else (order_qtys[0] if order_qtys else '?')
    row_label = f'{len(processed_rows)}건' if len(processed_rows) > 1 else '1건'
    mat_doc_label = f', 자재문서: {_mat_doc_no}' if _mat_doc_no else ''
    return {
        'ok': True,
        'ebeln': ebeln,
        'rowCount': len(processed_rows),
        'orderQtys': order_qtys,
        'goodsReceiptDate': today,
        'statusText': status_text,
        'matDocNo': _mat_doc_no,
        'message': f'구매오더 "{ebeln}" 자재 입고 처리를 완료했습니다 ({row_label}, 수량: {qty_summary}, 입고일자: {today}{mat_doc_label}). [SAP: {status_text}]',
        'debug': {'debugSteps': _debug_steps, 'popupTexts': _popup_texts},
    }


def display_reservation(rsnum):
    """MB23 - 예약 번호로 예약 조회."""
    session = _get_sap_session()
    _sap_close_stray_popups(session)
    wnd = session.findById('wnd[0]')
    session.findById('wnd[0]/tbar[0]/okcd').text = '/nMB23'
    wnd.sendVKey(0)
    time.sleep(1.0)
    wnd = session.findById('wnd[0]')
    wnd.findById('usr/ctxtRM07M-RSNUM').text = str(rsnum).strip()
    wnd.findById('tbar[1]/btn[5]').press()
    time.sleep(1.2)
    wnd = session.findById('wnd[0]')
    grid = _sap_find_grid(wnd)
    if grid:
        table = _sap_dump_grid(grid)
        row_count = grid.RowCount
    else:
        table = '\n'.join(_sap_dump_fields(wnd))
        row_count = None
    title = wnd.findById('titl').Text if wnd.findById('titl') else ''
    return {'ok': True, 'rsnum': rsnum, 'title': title, 'table': table, 'rowCount': row_count}


def compare_bom(mat1, mat2, plant='1000', mode='diff'):
    """CS14 - 두 자재의 BOM을 비교한다. mode: 'diff'(차이비교) or 'summary'(요약비교)."""
    session = _get_sap_session()
    _sap_close_stray_popups(session)
    wnd = session.findById('wnd[0]')
    session.findById('wnd[0]/tbar[0]/okcd').text = '/nCS14'
    wnd.sendVKey(0)
    time.sleep(1.0)
    wnd = session.findById('wnd[0]')
    usr = wnd.findById('usr')
    usr.findById('subINC1:SAPMC29V:0130/ctxtMATNR1').text = str(mat1).strip()
    usr.findById('subINC1:SAPMC29V:0130/ctxtWERKS1').text = plant
    usr.findById('subINC2:SAPMC29V:0131/ctxtMATNR2').text = str(mat2).strip()
    usr.findById('subINC2:SAPMC29V:0131/ctxtWERKS2').text = plant
    btn_id = 5 if mode == 'diff' else 6
    wnd.findById('tbar[1]/btn[' + str(btn_id) + ']').press()
    time.sleep(1.5)
    wnd = session.findById('wnd[0]')
    grid = _sap_find_grid(wnd)
    if grid:
        table = _sap_dump_grid(grid)
        row_count = grid.RowCount
    else:
        table = '\n'.join(_sap_dump_fields(wnd))
        row_count = None
    mode_label = '차이비교' if mode == 'diff' else '요약비교'
    return {'ok': True, 'mat1': mat1, 'mat2': mat2, 'plant': plant, 'mode': mode_label,
            'table': table, 'rowCount': row_count}



def fetch_material_change_history(material, plant='1000', date_from=None, date_to=None, by='change'):
    """ZCO037 - 자재마스터(상태) 변경이력 조회.

    by: 'change'=변경일자기준(radR2, 화면 기본) / 'valid'=유효일자기준(radR1).

    ⚠️⚠️ [2026-10-02 실화면 덤프로 확인된 3가지 불일치 수정 — 실사용 제보 "이전 이력이 안 보임"]
      1) 라디오(radR1/radR2)를 코드가 전혀 건드리지 않아, **사람이 마지막에 둔 상태**가 그대로
         적용됐다 — 같은 질문에 PC·시점마다 다른 답이 나오는 구조였다. 이제 명시적으로 고른다.
      2) plant 인자를 받기만 하고 P_WERKS에 **쓰지 않으면서** 반환값에는 담아, 적용된 것처럼 보였다.
      3) 날짜 필드명이 P_UDATE인 줄 알았으나 그런 필드는 없고 실제로는 S_UDATE-LOW/HIGH다
         (valid_date를 넘기면 findById에서 예외가 났다).
      또한 이전 조회에서 남은 선택조건(S_MTART/S_BKLAS/S_MMSTA)이 그대로 필터로 걸려
      이력이 조용히 잘려 나갈 수 있어 매번 비운다."""
    session = _get_sap_session()
    _sap_close_stray_popups(session)
    wnd = session.findById('wnd[0]')
    session.findById('wnd[0]/tbar[0]/okcd').text = '/nZCO037'
    wnd.sendVKey(0)
    time.sleep(1.0)
    wnd = session.findById('wnd[0]')

    def _set(field_id, value):
        """선택화면 필드에 값을 쓴다(없는 필드는 조용히 무시 — 계정별 화면 차이 대비)."""
        try:
            wnd.findById('usr/' + field_id).text = value
            return True
        except Exception:
            return False

    # (1) 작업구분 라디오를 명시적으로 선택 — 화면에 남은 상태에 결과가 좌우되지 않게
    try:
        wnd.findById('usr/radR1' if by == 'valid' else 'usr/radR2').select()
    except Exception as e:
        print(f'[ZCO037] 작업구분 라디오 설정 실패(화면 기본값 사용): {e}', file=sys.stderr)

    # (2) 플랜트 — 기존엔 인자를 받고도 쓰지 않았다
    if plant:
        _set('ctxtP_WERKS', str(plant).strip())

    _set('ctxtS_MATNR-LOW', str(material).strip())
    _set('ctxtS_MATNR-HIGH', '')

    # (3) 변경일자 기간 — 실제 필드는 P_UDATE가 아니라 S_UDATE-LOW/HIGH
    _set('ctxtS_UDATE-LOW', str(date_from).strip() if date_from else '')
    _set('ctxtS_UDATE-HIGH', str(date_to).strip() if date_to else '')

    # (4) 이전 조회의 잔존 필터 제거 — 남아 있으면 이력이 조용히 걸러진다
    for _f in ('ctxtS_MTART-LOW', 'ctxtS_MTART-HIGH', 'ctxtS_BKLAS-LOW', 'ctxtS_BKLAS-HIGH',
               'ctxtS_MMSTA-LOW', 'ctxtS_MMSTA-HIGH'):
        _set(_f, '')

    wnd.findById('tbar[1]/btn[8]').press()
    time.sleep(1.5)
    wnd = session.findById('wnd[0]')
    grid = _sap_find_grid(wnd)
    if grid:
        table = _sap_dump_grid(grid)
        row_count = grid.RowCount
    else:
        table = '\n'.join(_sap_dump_fields(wnd))
        row_count = None
    # rowCount를 answer에도 실어 "1건뿐"인지 "더 있는데 안 보이는"지 사람이 바로 판별하게 한다
    return {'ok': True, 'material': material, 'plant': plant, 'table': table,
            'rowCount': row_count, 'basis': ('유효일자기준' if by == 'valid' else '변경일자기준'),
            'dateFrom': date_from or '', 'dateTo': date_to or ''}


def fetch_delivery_history(material, vendor=None, date_from=None, date_to=None):
    """ZSD027 - 납품 내역 관리 조회."""
    session = _get_sap_session()
    _sap_close_stray_popups(session)
    wnd = session.findById('wnd[0]')
    session.findById('wnd[0]/tbar[0]/okcd').text = '/nZSD027'
    wnd.sendVKey(0)
    time.sleep(1.0)
    wnd = session.findById('wnd[0]')
    wnd.findById('usr/ctxtP_MATNR-LOW').text = str(material).strip()
    if vendor:
        wnd.findById('usr/ctxtP_LIFNR-LOW').text = str(vendor).strip()
    if date_from:
        wnd.findById('usr/ctxtP_LFDAT-LOW').text = str(date_from).strip()
    if date_to:
        wnd.findById('usr/ctxtP_LFDAT-HIGH').text = str(date_to).strip()
    wnd.findById('tbar[1]/btn[8]').press()
    time.sleep(1.5)
    wnd = session.findById('wnd[0]')
    grid = _sap_find_grid(wnd)
    if grid:
        table = _sap_dump_grid(grid)
        row_count = grid.RowCount
    else:
        table = '\n'.join(_sap_dump_fields(wnd))
        row_count = None
    return {'ok': True, 'material': material, 'table': table, 'rowCount': row_count}


def fetch_purchase_info_records(material, vendor=None, porg='1000', key_date=None):
    """ZMM006 - 자재/공급업체 구매 정보 레코드 조회."""
    session = _get_sap_session()
    _sap_close_stray_popups(session)
    wnd = session.findById('wnd[0]')
    session.findById('wnd[0]/tbar[0]/okcd').text = '/nZMM006'
    wnd.sendVKey(0)
    time.sleep(1.0)
    wnd = session.findById('wnd[0]')
    wnd.findById('usr/ctxtS_MATNR-LOW').text = str(material).strip()
    if vendor:
        wnd.findById('usr/ctxtS_LIFNR-LOW').text = str(vendor).strip()
    wnd.findById('usr/ctxtS_EKORG-LOW').text = porg
    if key_date:
        wnd.findById('usr/ctxtP_KEYDT').text = str(key_date).strip()
    wnd.findById('tbar[1]/btn[8]').press()
    time.sleep(1.5)
    wnd = session.findById('wnd[0]')
    grid = _sap_find_grid(wnd)
    if grid:
        table = _sap_dump_grid(grid)
        row_count = grid.RowCount
    else:
        table = '\n'.join(_sap_dump_fields(wnd))
        row_count = None
    return {'ok': True, 'material': material, 'porg': porg, 'table': table, 'rowCount': row_count}


def display_production_order(aufnr):
    """CO03 - 생산 오더 조회 (개요)."""
    session = _get_sap_session()
    _sap_close_stray_popups(session)
    wnd = session.findById('wnd[0]')
    session.findById('wnd[0]/tbar[0]/okcd').text = '/nCO03'
    wnd.sendVKey(0)
    time.sleep(1.0)
    wnd = session.findById('wnd[0]')
    wnd.findById('usr/ctxtCAUFVD-AUFNR').text = str(aufnr).strip()
    wnd.findById('tbar[1]/btn[5]').press()
    time.sleep(1.5)
    wnd = session.findById('wnd[0]')
    grid = _sap_find_grid(wnd)
    if grid:
        table = _sap_dump_grid(grid)
        row_count = grid.RowCount
    else:
        table = '\n'.join(_sap_dump_fields(wnd))
        row_count = None
    title = ''
    try:
        title = wnd.findById('titl').Text
    except Exception:
        pass
    return {'ok': True, 'aufnr': aufnr, 'title': title, 'table': table, 'rowCount': row_count}


def fetch_production_orders(material=None, aufnr=None, date_from=None, date_to=None, plant='1000'):
    """COOIS - 생산오더정보시스템 목록 조회."""
    session = _get_sap_session()
    _sap_close_stray_popups(session)
    wnd = session.findById('wnd[0]')
    session.findById('wnd[0]/tbar[0]/okcd').text = '/nCOOIS'
    wnd.sendVKey(0)
    time.sleep(1.2)
    wnd = session.findById('wnd[0]')
    _sel_base = 'usr/tabsTABSTRIP_SELBLOCK/tabpSEL_00/ssub%_SUBSCREEN_SELBLOCK:PPIO_ENTRY:1200/'
    if material:
        wnd.findById(_sel_base + 'ctxtS_MATNR-LOW').text = str(material).strip()
    if aufnr:
        wnd.findById(_sel_base + 'ctxtS_AUFNR-LOW').text = str(aufnr).strip()
    if date_from:
        wnd.findById(_sel_base + 'ctxtS_ECKST-LOW').text = str(date_from).strip()
    if date_to:
        wnd.findById(_sel_base + 'ctxtS_ECKST-HIGH').text = str(date_to).strip()
    wnd.findById('tbar[1]/btn[8]').press()
    time.sleep(2.0)
    wnd = session.findById('wnd[0]')
    grid = _sap_find_grid(wnd)
    if grid:
        table = _sap_dump_grid(grid)
        row_count = grid.RowCount
    else:
        table = '\n'.join(_sap_dump_fields(wnd))
        row_count = None
    return {'ok': True, 'material': material, 'aufnr': aufnr, 'table': table, 'rowCount': row_count}


def main():
    try:
        import win32com.client  # noqa: F401  (설치 여부 확인용)
    except ImportError:
        print(json.dumps({'ok': False, 'error': '32비트 Python용 pywin32가 설치되지 않았습니다. kortek_backend.bat을 다시 실행하면 자동 설치됩니다(또는 수동: py -3-32 -m pip install pywin32).'}, ensure_ascii=False))
        return
    try:
        action = sys.argv[1] if len(sys.argv) > 1 else 'fetch_screen'
        if action == 'open_document':
            doc_type = sys.argv[2] if len(sys.argv) > 2 else ''
            material = sys.argv[3] if len(sys.argv) > 3 else None
            result = open_document(doc_type, material)
        elif action == 'fetch_material_documents':
            material = sys.argv[2] if len(sys.argv) > 2 else ''
            result = fetch_material_documents(material)
        elif action == 'fetch_material_price':
            material = sys.argv[2] if len(sys.argv) > 2 else ''
            result = fetch_material_price(material)
        elif action == 'download_documents_batch':
            doc_type = sys.argv[2] if len(sys.argv) > 2 else 'P01'
            materials_str = sys.argv[3] if len(sys.argv) > 3 else ''
            materials = [m.strip() for m in materials_str.split(',') if m.strip()]
            result = download_documents_batch(materials, doc_type)
        elif action == 'lookup_documents_batch':
            doc_type = sys.argv[2] if len(sys.argv) > 2 else 'P02'
            materials_str = sys.argv[3] if len(sys.argv) > 3 else ''
            materials = [m.strip() for m in materials_str.split(',') if m.strip()]
            result = lookup_documents_batch(materials, doc_type)
        elif action == 'resolve_pattern':
            pattern = sys.argv[2] if len(sys.argv) > 2 else ''
            mats = resolve_materials_by_description_pattern(pattern)
            result = {'ok': True, 'pattern': pattern, 'count': len(mats), 'materials': mats}
        elif action == 'fetch_project_codes':
            pattern = sys.argv[2] if len(sys.argv) > 2 else ''
            bwart = sys.argv[3] if len(sys.argv) > 3 and sys.argv[3].strip() else None
            werks = sys.argv[4] if len(sys.argv) > 4 and sys.argv[4].strip() else None
            by = sys.argv[5] if len(sys.argv) > 5 and sys.argv[5].strip() else 'code'
            result = fetch_project_codes(pattern, bwart, werks, by=by)
        elif action == 'download_documents_by_pattern':
            pattern = sys.argv[2] if len(sys.argv) > 2 else ''
            doc_type = sys.argv[3] if len(sys.argv) > 3 else 'P01'
            result = download_documents_by_pattern(pattern, doc_type)
        elif action == 'fetch_bom':
            materials_arg = sys.argv[2] if len(sys.argv) > 2 else ''
            plant = sys.argv[3] if len(sys.argv) > 3 else '1000'
            tcode_mode = sys.argv[4] if len(sys.argv) > 4 else 'auto'  # 'single'|'multi'|'auto'
            explosion = sys.argv[5] if len(sys.argv) > 5 else 'single'  # 'single'|'multi'
            show_price = (sys.argv[6] if len(sys.argv) > 6 else '0') in ('1', 'true', 'True')
            show_location = (sys.argv[7] if len(sys.argv) > 7 else '0') in ('1', 'true', 'True')
            layout_variant = sys.argv[8] if len(sys.argv) > 8 and sys.argv[8].strip() else None
            materials_list = [m.strip() for m in materials_arg.split(',') if m.strip()]
            materials_param = materials_list if len(materials_list) > 1 else (materials_list[0] if materials_list else '')
            use_single_tcode = {'single': True, 'multi': False}.get(tcode_mode, None)
            result = fetch_bom(materials_param, plant, use_single_tcode=use_single_tcode,
                                explosion=explosion, show_price=show_price, show_location=show_location,
                                layout_variant=layout_variant)
        elif action == 'fetch_where_used':
            materials_arg = sys.argv[2] if len(sys.argv) > 2 else ''
            plant = sys.argv[3] if len(sys.argv) > 3 else '1000'
            materials_list = [m.strip() for m in materials_arg.split(',') if m.strip()]
            materials_param = materials_list if len(materials_list) > 1 else (materials_list[0] if materials_list else '')
            result = fetch_where_used(materials_param, plant)
        elif action == 'fetch_where_used_batch':
            materials_arg = sys.argv[2] if len(sys.argv) > 2 else ''
            plant = sys.argv[3] if len(sys.argv) > 3 else '1000'
            materials_list = [m.strip() for m in materials_arg.split(',') if m.strip()]
            result = fetch_where_used_batch(materials_list, plant)
        elif action == 'fetch_approval_info':
            materials_arg = sys.argv[2] if len(sys.argv) > 2 else ''
            materials_list = [m.strip() for m in materials_arg.split(',') if m.strip()]
            result = fetch_approval_info(materials_list)
        elif action == 'fetch_zmm009_material_list':
            materials_arg = sys.argv[2] if len(sys.argv) > 2 else ''
            storage_location = sys.argv[3] if len(sys.argv) > 3 else '1000'
            layout_variant = sys.argv[4] if len(sys.argv) > 4 and sys.argv[4].strip() else None
            materials_list = [m.strip() for m in materials_arg.split(',') if m.strip()]
            result = fetch_zmm009_material_list(materials_list, storage_location, layout_variant)
        elif action == 'prepare_po_from_excel':
            excel_path = sys.argv[2] if len(sys.argv) > 2 else ''
            biz_reg_no = sys.argv[3] if len(sys.argv) > 3 else ''
            items_json = sys.argv[4] if len(sys.argv) > 4 else '[]'
            plant = sys.argv[5] if len(sys.argv) > 5 else '1000'
            currency = sys.argv[6] if len(sys.argv) > 6 and sys.argv[6] else 'KRW'
            items = json.loads(items_json)
            result = prepare_po_from_excel(excel_path, biz_reg_no, items, plant, currency)
        elif action == 'simulate_indat_copy':
            row_count = int(sys.argv[2]) if len(sys.argv) > 2 and sys.argv[2].isdigit() else 2
            result = simulate_indat_copy(row_count)
        elif action == 'simulate_vendor_copy':
            row_count = int(sys.argv[2]) if len(sys.argv) > 2 and sys.argv[2].isdigit() else 2
            result = simulate_vendor_copy(row_count)
        elif action == 'confirm_save_po':
            purchasing_org = sys.argv[2] if len(sys.argv) > 2 else '9000'
            plant = sys.argv[3] if len(sys.argv) > 3 else '1000'
            currency = sys.argv[4] if len(sys.argv) > 4 and sys.argv[4] else 'KRW'
            result = confirm_save_po(purchasing_org, plant, currency)
        elif action == 'print_po_via_zmm018':
            po_number = sys.argv[2] if len(sys.argv) > 2 else ''
            purchasing_org = sys.argv[3] if len(sys.argv) > 3 else '9000'
            plant = sys.argv[4] if len(sys.argv) > 4 else '1000'
            currency = sys.argv[5] if len(sys.argv) > 5 and sys.argv[5] else 'KRW'
            result = print_po_via_zmm018(po_number, purchasing_org, plant, currency)
        elif action == 'fetch_team_budget':
            team = sys.argv[2] if len(sys.argv) > 2 else ''
            fperbl = sys.argv[3] if len(sys.argv) > 3 and sys.argv[3] else '1'
            tperbl = sys.argv[4] if len(sys.argv) > 4 and sys.argv[4] else '12'
            result = fetch_team_budget(team, fperbl, tperbl)
        elif action == 'create_reservation':
            # [2026-10-02] 자재 보관함 → MB21 예약(계정대체청구서) 생성. MIGO 전기는 하지 않는다.
            import json as _json3
            items_arg   = _json3.loads(sys.argv[2]) if len(sys.argv) > 2 else []
            bwart_arg   = sys.argv[3] if len(sys.argv) > 3 and sys.argv[3].strip() else '951'
            order_arg   = sys.argv[4] if len(sys.argv) > 4 else ''
            kostl_arg   = sys.argv[5] if len(sys.argv) > 5 and sys.argv[5].strip() else None
            werks_arg   = sys.argv[6] if len(sys.argv) > 6 and sys.argv[6].strip() else '1000'
            lgort_arg   = sys.argv[7] if len(sys.argv) > 7 and sys.argv[7].strip() else None
            rsdat_arg   = sys.argv[8] if len(sys.argv) > 8 and sys.argv[8].strip() else None
            wempf_arg   = sys.argv[9] if len(sys.argv) > 9 and sys.argv[9].strip() else None
            text_arg    = sys.argv[10] if len(sys.argv) > 10 and sys.argv[10].strip() else None
            purp_arg    = sys.argv[11] if len(sys.argv) > 11 and sys.argv[11].strip() else None
            result = create_reservation(
                items_arg, bwart=bwart_arg, order_number=order_arg, cost_center=kostl_arg,
                werks=werks_arg, lgort_default=lgort_arg, rsdat=rsdat_arg,
                wempf=wempf_arg, text=text_arg, purpose=purp_arg)
        elif action == 'print_reservation_zmm019':
            rsnum_arg = sys.argv[2] if len(sys.argv) > 2 else ''
            werks_arg = sys.argv[3] if len(sys.argv) > 3 and sys.argv[3].strip() else '1000'
            rsdat_arg = sys.argv[4] if len(sys.argv) > 4 and sys.argv[4].strip() else None
            result = print_reservation_zmm019(rsnum_arg, werks_arg, rsdat_arg)
        elif action == 'migo_return_receipt':
            import json as _json2
            items_arg   = _json2.loads(sys.argv[2]) if len(sys.argv) > 2 else []
            order_arg   = sys.argv[3] if len(sys.argv) > 3 else ''
            cost_center = sys.argv[4] if len(sys.argv) > 4 and sys.argv[4].strip() else None
            lgort_arg   = sys.argv[5] if len(sys.argv) > 5 and sys.argv[5].strip() else '5000'
            text_arg    = sys.argv[6] if len(sys.argv) > 6 and sys.argv[6].strip() else None
            rsdat_arg   = sys.argv[7] if len(sys.argv) > 7 and sys.argv[7].strip() else None
            wempf_arg   = sys.argv[8] if len(sys.argv) > 8 and sys.argv[8].strip() else None
            result = migo_return_receipt(
                items_arg, order_arg, cost_center=cost_center,
                lgort_default=lgort_arg, text=text_arg, rsdat=rsdat_arg, wempf=wempf_arg)
        elif action == 'post_goods_receipt':
            ebeln = sys.argv[2] if len(sys.argv) > 2 else ''
            _dump_flag = '--dump-only' in sys.argv
            result = post_goods_receipt(ebeln, dump_only=_dump_flag)
        elif action == 'fetch_vendor_by_stcd2':
            stcd2_arg = sys.argv[2] if len(sys.argv) > 2 else ''
            result = fetch_vendor_by_stcd2(stcd2_arg)
        elif action == 'fetch_vendor_by_lifnr':
            lifnr_arg = sys.argv[2] if len(sys.argv) > 2 else ''
            result = fetch_vendor_by_lifnr(lifnr_arg) or {'ok': False, 'error': '조회 결과 없음'}
        elif action == 'fetch_lifnr_from_mm03':
            material_arg = sys.argv[2] if len(sys.argv) > 2 else ''
            result = {'lifnr': fetch_lifnr_from_mm03(material_arg), 'ok': True}
        elif action == 'fetch_vendor_info_by_material':
            material_arg = sys.argv[2] if len(sys.argv) > 2 else ''
            result = fetch_vendor_info_by_material(material_arg)
        elif action == 'query_mard_stock':
            matnr_arg = sys.argv[2] if len(sys.argv) > 2 else ''
            werks_arg = sys.argv[3] if len(sys.argv) > 3 and sys.argv[3].strip() else '1000'
            result = query_mard_stock(matnr_arg, werks_arg)
        elif action == 'dump_screen_tree':
            save_dir = sys.argv[2] if len(sys.argv) > 2 and sys.argv[2].strip() else None
            result = dump_screen_tree(save_dir)
        elif action == 'navigate_and_dump':
            tcode_arg = sys.argv[2] if len(sys.argv) > 2 else ''
            save_dir = sys.argv[3] if len(sys.argv) > 3 and sys.argv[3].strip() else None
            result = navigate_and_dump(tcode_arg, save_dir)
        elif action == 'display_reservation':
            result = display_reservation(sys.argv[2] if len(sys.argv) > 2 else '')
        elif action == 'compare_bom':
            mat1 = sys.argv[2] if len(sys.argv) > 2 else ''
            mat2 = sys.argv[3] if len(sys.argv) > 3 else ''
            plant = sys.argv[4] if len(sys.argv) > 4 and sys.argv[4].strip() else '1000'
            mode = sys.argv[5] if len(sys.argv) > 5 and sys.argv[5].strip() else 'diff'
            result = compare_bom(mat1, mat2, plant, mode)
        elif action == 'fetch_material_change_history':
            mat = sys.argv[2] if len(sys.argv) > 2 else ''
            plant = sys.argv[3] if len(sys.argv) > 3 and sys.argv[3].strip() else '1000'
            dfrom = sys.argv[4] if len(sys.argv) > 4 and sys.argv[4].strip() else None
            dto   = sys.argv[5] if len(sys.argv) > 5 and sys.argv[5].strip() else None
            by    = sys.argv[6] if len(sys.argv) > 6 and sys.argv[6].strip() else 'change'
            result = fetch_material_change_history(mat, plant, dfrom, dto, by)
        elif action == 'fetch_delivery_history':
            mat = sys.argv[2] if len(sys.argv) > 2 else ''
            vendor = sys.argv[3] if len(sys.argv) > 3 and sys.argv[3].strip() else None
            df = sys.argv[4] if len(sys.argv) > 4 and sys.argv[4].strip() else None
            dt = sys.argv[5] if len(sys.argv) > 5 and sys.argv[5].strip() else None
            result = fetch_delivery_history(mat, vendor, df, dt)
        elif action == 'fetch_purchase_info_records':
            mat = sys.argv[2] if len(sys.argv) > 2 else ''
            vendor = sys.argv[3] if len(sys.argv) > 3 and sys.argv[3].strip() else None
            porg = sys.argv[4] if len(sys.argv) > 4 and sys.argv[4].strip() else '1000'
            kdate = sys.argv[5] if len(sys.argv) > 5 and sys.argv[5].strip() else None
            result = fetch_purchase_info_records(mat, vendor, porg, kdate)
        elif action == 'display_production_order':
            result = display_production_order(sys.argv[2] if len(sys.argv) > 2 else '')
        elif action == 'fetch_production_orders':
            mat = sys.argv[2] if len(sys.argv) > 2 and sys.argv[2].strip() else None
            aufnr = sys.argv[3] if len(sys.argv) > 3 and sys.argv[3].strip() else None
            df = sys.argv[4] if len(sys.argv) > 4 and sys.argv[4].strip() else None
            dt = sys.argv[5] if len(sys.argv) > 5 and sys.argv[5].strip() else None
            plant = sys.argv[6] if len(sys.argv) > 6 and sys.argv[6].strip() else '1000'
            result = fetch_production_orders(mat, aufnr, df, dt, plant)
        else:
            result = fetch_current_screen()
        if isinstance(result, dict) and result.get('ok') is False:
            _attach_failure_info(result)
        print(json.dumps(result, ensure_ascii=False))
    except RuntimeError as e:
        print(json.dumps(_attach_failure_info({'ok': False, 'error': str(e)}), ensure_ascii=False))
    except Exception as e:
        import traceback
        traceback.print_exc(file=sys.stderr)
        # [2026-10-02] 원시 COM 문자열을 그대로 내보내면 사용자가 무엇을 해야 할지 알 수 없다
        #   — humanize_sap_error가 상태바까지 담아 한국어로 바꿔 준다.
        try:
            _sess = _get_sap_session()
        except Exception:
            _sess = None
        print(json.dumps(_attach_failure_info({'ok': False, 'error': humanize_sap_error(e, _sess)}), ensure_ascii=False))


if __name__ == '__main__':
    main()
