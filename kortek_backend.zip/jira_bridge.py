# -*- coding: utf-8 -*-
"""🪐 JIRA(Kortek Issue Tracker) REST API 연동.

대상: http://jira.kortek.co.kr — Jira Server **5.2.11**(2013-04-15 빌드, serverInfo 실측).
PAT(개인 액세스 토큰)가 없는 시대의 버전이라(PAT는 Jira 8.14+) 모든 호출을 **Basic Auth**
(아이디:비밀번호를 매 요청에 실음)로 한다. REST API(/rest/api/2/*)가 이미 열려 있고 401에도
깨끗한 JSON을 주므로(실측: GET /rest/api/2/issue/GABKJ-1 → 401 +
{"errorMessages":[...],"errors":{}}) SAP/그룹웨어/인사관리처럼 화면 자동화가 필요 없다.

비밀번호는 Windows DPAPI로 암호화해 jira_login_config.json(.gitignore)에만 두고, 어떤
응답에도 돌려주지 않는다. ⚠️⚠️ 이 서버는 HTTP 전용(암호화 없음)이라 사내망을 벗어나면
평문으로 샌다 — 이 스크립트는 그 사실을 바꾸지 못한다.

⚠️⚠️ **CAPTCHA/계정잠금 정책을 모른다 — "모르면 안 한다".** 자격증명이 한 번 틀리면(401)
또는 CAPTCHA 요구 헤더(X-Authentication-Denied-Reason)가 오면, 그 자리에서 잠그고
**다시 시도하지 않는다**(SAP·그룹웨어·인사관리와 같은 이유). 사람이 🔑 설정에서 계정을
다시 저장해야 풀린다. 이 가드는 여기(백엔드)에 있다 — 프런트(js/36 `_jiraEnsureLogin`)는
"이미 실패했으면 또 부르지 않는다"는 자기 가드를 따로 갖되, 서버가 최종 방어선이다.
"""
import os
import json
import requests
from requests.auth import HTTPBasicAuth

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
_CFG_PATH = os.path.join(BASE_DIR, 'jira_login_config.json')
JIRA_BASE = 'http://jira.kortek.co.kr'
_TIMEOUT = 15

# ⚠️ 한 번 틀리면 잠근다 — 이 서버가 몇 번까지 허용하는지 모른다(모르면 1회).
_BLOCKED = {'reason': None}


class JiraApiError(RuntimeError):
    def __init__(self, message, status=None):
        super(JiraApiError, self).__init__(message)
        self.status = status


def _dpapi_encrypt_b64(text):
    """⚠️ kortek_backend.py에도 같은 함수가 있지만 **여기에 따로 둔다** — 이 모듈을 import 않는
    PC에서도(아직 jira 기능을 안 쓰는 PC) kortek_backend.py만으로 돌아가야 한다."""
    import ctypes
    import base64
    from ctypes import wintypes

    class _BLOB(ctypes.Structure):
        _fields_ = [('cbData', wintypes.DWORD), ('pbData', ctypes.POINTER(ctypes.c_char))]
    raw = text.encode('utf-8')
    buf = ctypes.create_string_buffer(raw, len(raw))
    blob_in = _BLOB(len(raw), ctypes.cast(buf, ctypes.POINTER(ctypes.c_char)))
    blob_out = _BLOB()
    if not ctypes.windll.crypt32.CryptProtectData(ctypes.byref(blob_in), 'kortek-jira-login', None, None, None, 0, ctypes.byref(blob_out)):
        raise RuntimeError('Windows 데이터 보호(DPAPI)로 비밀번호를 암호화하지 못했습니다.')
    try:
        return base64.b64encode(ctypes.string_at(blob_out.pbData, blob_out.cbData)).decode('ascii')
    finally:
        ctypes.windll.kernel32.LocalFree(blob_out.pbData)


def _dpapi_decrypt_b64(b64):
    import ctypes
    import base64
    from ctypes import wintypes

    class _BLOB(ctypes.Structure):
        _fields_ = [('cbData', wintypes.DWORD), ('pbData', ctypes.POINTER(ctypes.c_char))]
    raw = base64.b64decode(b64)
    buf = ctypes.create_string_buffer(raw, len(raw))
    bin_ = _BLOB(len(raw), ctypes.cast(buf, ctypes.POINTER(ctypes.c_char)))
    bout = _BLOB()
    if not ctypes.windll.crypt32.CryptUnprotectData(ctypes.byref(bin_), None, None, None, None, 0, ctypes.byref(bout)):
        raise RuntimeError('저장된 비밀번호를 복호화하지 못했습니다'
                            '(다른 Windows 계정/PC에서 저장한 설정일 수 있음) — 다시 저장해주세요.')
    try:
        return ctypes.string_at(bout.pbData, bout.cbData).decode('utf-8')
    finally:
        ctypes.windll.kernel32.LocalFree(bout.pbData)


def _cfg():
    try:
        with open(_CFG_PATH, 'r', encoding='utf-8') as f:
            c = json.load(f)
        return c if isinstance(c, dict) else {}
    except Exception:
        return {}


def _write_cfg(c):
    with open(_CFG_PATH, 'w', encoding='utf-8') as f:
        json.dump(c, f, ensure_ascii=False, indent=2)


def status():
    """로그인은 하지 않는다 — 설정 유무 + 서버 도달 가능 여부만."""
    c = _cfg()
    out = {'ok': True, 'configured': bool(c.get('user') and c.get('pw_dpapi')),
           'user': c.get('user', ''), 'verified': bool(c.get('verified')),
           'blocked': _BLOCKED['reason']}
    try:
        requests.get(JIRA_BASE + '/rest/api/2/serverInfo', timeout=5)
        out['reachable'] = True
    except Exception as e:
        out['reachable'] = False
        out['message'] = 'JIRA 서버에 연결할 수 없습니다: %s' % e
    return out


def save_config(user, pw):
    enc = _dpapi_encrypt_b64(pw)
    _write_cfg({'user': user, 'pw_dpapi': enc, 'verified': False})
    _BLOCKED['reason'] = None  # 새 자격증명을 저장했으니 잠금을 푼다


def delete_config():
    if os.path.exists(_CFG_PATH):
        os.remove(_CFG_PATH)
    _BLOCKED['reason'] = None


def _auth():
    c = _cfg()
    if not (c.get('user') and c.get('pw_dpapi')):
        return None
    pw = _dpapi_decrypt_b64(c['pw_dpapi'])
    return HTTPBasicAuth(c['user'], pw)


def _err_text(r):
    try:
        j = r.json()
    except Exception:
        return None
    msgs = list(j.get('errorMessages') or [])
    errs = j.get('errors') or {}
    msgs += ['%s: %s' % (k, v) for k, v in errs.items()]
    return ' / '.join(msgs) if msgs else None


def _request(method, path, **kw):
    """모든 JIRA 호출의 단일 입구 — 잠금 판정·401/CAPTCHA 감지가 여기 한 곳에만 있다."""
    if _BLOCKED['reason']:
        raise JiraApiError(_BLOCKED['reason'])
    try:
        auth = _auth()
    except Exception as e:
        raise JiraApiError(str(e))
    if not auth:
        raise JiraApiError('저장된 JIRA 계정이 없습니다 — 🔑 설정에서 등록해주세요.')
    try:
        r = requests.request(method, JIRA_BASE + path, auth=auth, timeout=_TIMEOUT, **kw)
    except Exception as e:
        raise JiraApiError('JIRA 서버에 연결하지 못했습니다: %s' % e)
    # ⚠️ CAPTCHA 요구는 401이 아니라 이 헤더로 온다(그룹웨어와 달리 폼이 없어 추측만 가능하므로
    #    실제로 보이면 보수적으로 바로 잠근다) — 상태코드보다 먼저 본다.
    deny = r.headers.get('X-Authentication-Denied-Reason')
    if deny:
        _BLOCKED['reason'] = ('🔒 JIRA 가 추가 인증(보안문자 등)을 요구합니다 — 브라우저로 '
                              + JIRA_BASE + ' 에 직접 로그인해 풀어주세요. (사유: ' + deny + ')')
        raise JiraApiError(_BLOCKED['reason'])
    if r.status_code == 401:
        _BLOCKED['reason'] = ('🔒 JIRA 로그인 실패(아이디/비밀번호를 확인해주세요) — '
                              '계정을 다시 저장할 때까지 재시도하지 않습니다.')
        raise JiraApiError(_BLOCKED['reason'], status=401)
    if r.status_code == 403:
        # 권한 문제는 계정 자체가 틀린 게 아니다 — 잠그지 않는다.
        raise JiraApiError(_err_text(r) or '이 이슈를 볼 권한이 없습니다.', status=403)
    if r.status_code == 404:
        # ⚠️ [2026-11-17] 그냥 "못 찾았다"로만 끝내면 진단이 안 된다 — JIRA가 본문에 사유를
        # 실어 보내는 경우가 있어(예: 첨부가 서버에서 꺼져 있을 때) 있으면 덧붙인다.
        msg = '요청한 대상을 찾을 수 없습니다 (HTTP 404, %s).' % path
        extra = _err_text(r)
        if extra:
            msg += ' ' + extra
        raise JiraApiError(msg, status=404)
    if r.status_code >= 400:
        raise JiraApiError(_err_text(r) or ('JIRA 오류 (HTTP %d)' % r.status_code), status=r.status_code)
    return r


def verify_login():
    """자격증명을 **한 번만** 확인한다(whoami). 성공하면 verified 플래그를 남긴다.

    ⚠️⚠️ [2026-11-11 실측] `/rest/api/2/myself`는 이 서버(2013년 빌드)에 **등록돼 있지 않다**
    — 인증은 성공하는데(응답 헤더에 `X-Seraph-LoginReason: OK`, `X-AUSERNAME: <내 계정>`이
    실린다) 그 리소스 자체가 없어 **404**("null for uri")로 떨어진다. 그래서 자격증명이
    맞는데도 "로그인 실패"로 오판했다. `/rest/api/2/user?username=<내 계정>`은 실측으로
    200이 확인됐다 — 이게 이 서버에서 통하는 whoami다.
    """
    c = _cfg()
    user = c.get('user') or ''
    r = _request('GET', '/rest/api/2/user', params={'username': user})
    me = r.json()
    c['verified'] = True
    _write_cfg(c)
    return {'ok': True, 'displayName': me.get('displayName') or me.get('name'), 'name': me.get('name')}


FIELDS_DEFAULT = ('summary,description,status,assignee,reporter,priority,issuetype,'
                   'created,updated,comment,components,labels,fixVersions,attachment,resolution')


# ── 🏷 커스텀 필드 이름 → id (2026-11-12, "구성 요소/해결책/Milestone도 보여줘") ──────
#  `resolution`은 표준 필드라 위 FIELDS_DEFAULT에 그냥 적으면 되지만, **Milestone은 이
#  인스턴스의 커스텀 필드**(`customfield_NNNNN`)라 이름만으로는 조회할 수 없다 — `/rest/api/2/
#  field`로 전체 필드 정의(id↔이름)를 한 번 받아 이름으로 찾는다. 필드 정의는 거의 안
#  바뀌므로 넉넉히(30분) 캐시한다. ⚠️ 실패해도 예외를 던지지 않고 None — 이 부가 정보 하나
#  때문에 이슈 조회 전체가 막히면 안 된다(핵심 정보는 FIELDS_DEFAULT의 표준 필드들이다).
_FIELD_META_CACHE = {'ts': 0, 'id_by_name': None}
_FIELD_META_TTL = 1800


def _field_id_by_name(name):
    import time
    now = time.time()
    cache = _FIELD_META_CACHE
    if cache['id_by_name'] is None or (now - cache['ts']) > _FIELD_META_TTL:
        try:
            r = _request('GET', '/rest/api/2/field')
            m = {}
            for fdef in r.json():
                nm = (fdef.get('name') or '').strip().lower()
                if nm and nm not in m:
                    m[nm] = fdef.get('id')
            cache['id_by_name'] = m
            cache['ts'] = now
        except Exception:
            return None  # 다음 호출에서 다시 시도(성공할 때만 캐시에 올린다)
    return (cache['id_by_name'] or {}).get((name or '').strip().lower())


def _field_display_value(v):
    """커스텀 필드 값 표시용 — select(단일: dict{value|name})·다중선택(list)·문자열을 전부 받는다."""
    if v is None:
        return ''
    if isinstance(v, dict):
        return v.get('value') or v.get('name') or ''
    if isinstance(v, list):
        return ', '.join(_field_display_value(x) for x in v if x is not None)
    return str(v)


def _shape_issue(raw, milestone_field_id=None):
    f = raw.get('fields') or {}
    status_f = f.get('status') or {}
    assignee = f.get('assignee') or {}
    reporter = f.get('reporter') or {}
    priority = f.get('priority') or {}
    issuetype = f.get('issuetype') or {}
    resolution = f.get('resolution') or {}
    comments = ((f.get('comment') or {}).get('comments')) or []
    attachments = f.get('attachment') or []
    milestone = _field_display_value(f.get(milestone_field_id)) if milestone_field_id else ''
    return {
        'key': raw.get('key'),
        'id': raw.get('id'),  # ⚠️ 숫자 id — 일부 자원(첨부 생성 등)이 key를 안 받는 경우의 폴백용
        'url': JIRA_BASE + '/browse/' + str(raw.get('key') or ''),
        'summary': f.get('summary') or '',
        'description': f.get('description') or '',
        'status': status_f.get('name') or '',
        'statusId': status_f.get('id'),
        'assignee': assignee.get('displayName') or '',
        'assigneeName': assignee.get('name') or '',
        'reporter': reporter.get('displayName') or '',
        'priority': priority.get('name') or '',
        'priorityId': priority.get('id'),
        'issuetype': issuetype.get('name') or '',
        'created': f.get('created') or '',
        'updated': f.get('updated') or '',
        'components': [c.get('name') for c in (f.get('components') or [])],
        'resolution': resolution.get('name') or '',
        'milestone': milestone,
        'labels': f.get('labels') or [],
        'comments': [{'author': (c.get('author') or {}).get('displayName'),
                      'body': c.get('body'), 'created': c.get('created')} for c in comments],
        # 📎 [2026-11-11 사용자 요청] 댓글에 "첨부 파일 참조"라고만 적혀 있고 정작 파일은
        # 안 보이는 문제 — JIRA는 첨부를 **댓글이 아니라 이슈**에 붙인다(실측 GABJQ-4,
        # 3건). 다운로드는 Basic Auth가 필요해 브라우저가 직접 못 받으므로
        # /jira/attachment 프록시를 거친다(아래 fetch_attachment).
        'attachments': [{'filename': a.get('filename') or '',
                          'size': a.get('size') or 0,
                          'mimeType': a.get('mimeType') or '',
                          'url': a.get('content') or '',
                          'author': (a.get('author') or {}).get('displayName'),
                          'created': a.get('created') or ''} for a in attachments],
    }


def get_issue(key):
    mid = _field_id_by_name('Milestone')
    fields = FIELDS_DEFAULT + (',' + mid if mid else '')
    r = _request('GET', '/rest/api/2/issue/' + key, params={'fields': fields})
    return _shape_issue(r.json(), mid)


def search(jql, max_results=50):
    # 📋 [2026-11-12 2차, 사용자 요청] 목록(표)에도 구성 요소/해결책/Milestone 열을 보여
    # 달라고 해서 이 필드들을 더했다 — `mid` 조회는 `_field_id_by_name`이 캐시하므로(30분)
    # 검색을 반복해도 매번 새로 묻지 않는다.
    mid = _field_id_by_name('Milestone')
    fields = 'summary,status,assignee,priority,issuetype,updated,components,resolution'
    if mid:
        fields += ',' + mid
    r = _request('GET', '/rest/api/2/search', params={
        'jql': jql, 'maxResults': max_results, 'fields': fields
    })
    j = r.json()
    return {'total': j.get('total', 0), 'issues': [_shape_issue(i, mid) for i in j.get('issues', [])]}


def add_comment(key, body):
    _request('POST', '/rest/api/2/issue/' + key + '/comment', json={'body': body})
    return {'ok': True}


# ── 👤 담당자 변경 확장(2026-11-11) — 아이디를 몰라도 이름으로 찾는다 ──────────
#  ⚠️⚠️ 실측: `/rest/api/2/user/assignable/search`의 `query` 파라미터는 이 서버에서
#  **조용히 무시된다**("hong"과 "yhpark"로 각각 질의해도 똑같은 50명이 그대로 왔다) —
#  그래서 JIRA 쪽 검색을 믿지 않고 `list_projects`/`resolve_project_key`와 같은 원칙으로
#  **우리가 전체를 받아 직접 거른다**(결정론 먼저, CLAUDE.md). `maxResults`는 실제로
#  듣는다(실측 204명 한 번에 옴) — 페이지네이션 없이 한 번에 받는다.
def _assignable_users(params, q):
    r = _request('GET', '/rest/api/2/user/assignable/search', params=params)
    out = [{'name': u.get('name'), 'displayName': u.get('displayName') or u.get('name')}
           for u in r.json()]
    if q:
        ql = q.strip().lower()
        out = [u for u in out if ql in (u['name'] or '').lower() or ql in (u['displayName'] or '').lower()]
    return out


def assignable_users(key, q=None):
    return _assignable_users({'issueKey': key, 'maxResults': 500}, q)


def assignable_users_for_project(project_key, q=None):
    """🆕 [2026-11-12] 새 이슈 생성 모달의 담당자 찾기 — 아직 이슈 키가 없으니 `issueKey`
    대신 `project`로 묻는다(JIRA REST가 둘 다 지원). 그 외엔 `assignable_users`와 동일
    (JIRA의 `query=` 를 못 믿어 전체를 받아 우리가 직접 거르는 것까지 포함)."""
    return _assignable_users({'project': project_key, 'maxResults': 500}, q)


def get_transitions(key):
    r = _request('GET', '/rest/api/2/issue/' + key + '/transitions')
    return [{'id': t.get('id'), 'name': t.get('name'), 'to': (t.get('to') or {}).get('name')}
            for t in r.json().get('transitions', [])]


def fetch_attachment(url):
    """첨부파일 바이트를 가져온다 — 브라우저가 직접 받으면 Basic Auth가 없어 401이 난다.

    ⚠️ `url` 은 프런트가 issue 조회로 받은 `attachments[].url` 그대로다 — **그 값 그대로가
    아니면 거부한다**(JIRA_BASE/secure/attachment/ 로 시작하지 않으면). 임의 주소를 우리
    자격증명으로 대신 불러오는 SSRF 통로가 되지 않게 하기 위해서다.
    """
    prefix = JIRA_BASE + '/secure/attachment/'
    if not url.startswith(prefix):
        raise JiraApiError('허용되지 않은 첨부파일 주소입니다.')
    return _request('GET', url[len(JIRA_BASE):])


def _safe_attachment_filename(name):
    """경로 조각을 뺀다 — JIRA 메타데이터를 신뢰하지만, 로컬 파일 시스템에 쓰는 자리라
    방어적으로 한 번 더 거른다(`os.path.basename` + 금지 문자 치환)."""
    import re
    name = os.path.basename(str(name or 'attachment'))
    name = re.sub(r'[\\/:*?"<>|]', '_', name).strip() or 'attachment'
    return name


def open_attachment_native(url, filename):
    """📎 [2026-11-12 사용자 요청] 첨부를 **연결 프로그램으로** 연다 — NAS(`/nas/app/open-native`)
    와 같은 UX 지만, JIRA 첨부는 이미 로컬에 있는 파일이 아니라 **매번 내려받아야 한다**(이
    서버로 와서 바이트를 받고 임시 폴더에 1부만 남긴다 — 같은 이름이면 덮어써 쌓이지 않는다).
    Windows 전용(`os.startfile`).
    """
    if not hasattr(os, 'startfile'):
        raise JiraApiError('이 기능은 Windows에서만 됩니다.')
    r = fetch_attachment(url)   # 화이트리스트(JIRA_BASE/secure/attachment/) 검사는 여기서 이미 한다
    import tempfile
    d = os.path.join(tempfile.gettempdir(), 'kortek_jira_attachments')
    os.makedirs(d, exist_ok=True)
    fp = os.path.join(d, _safe_attachment_filename(filename))
    with open(fp, 'wb') as f:
        f.write(r.content)
    try:
        os.startfile(fp)        # noqa: S606 — 우리가 방금 받아 쓴 임시 폴더 안 파일로 한정된다
    except Exception as e:
        raise JiraApiError('열지 못했습니다: %s' % e)
    return fp


def _add_attachment_raw(id_or_key, filename, content, mime_type=None, token_header='no-check'):
    r = _request('POST', '/rest/api/2/issue/' + id_or_key + '/attachments',
                  headers={'X-Atlassian-Token': token_header},
                  files={'file': (filename, content, mime_type or 'application/octet-stream')})
    return [{'filename': a.get('filename') or '',
             'size': a.get('size') or 0,
             'mimeType': a.get('mimeType') or '',
             'url': a.get('content') or '',
             'author': (a.get('author') or {}).get('displayName'),
             'created': a.get('created') or ''} for a in r.json()]


def add_attachment(key, filename, content, mime_type=None):
    """이슈에 새 파일을 올린다(첨부 저장, 2026-11-11 추가).

    ⚠️⚠️ [2026-11-17 2차 실측, 사용자 제보] 처음엔 "키 대신 숫자 id를 요구하나" 의심해
    id 폴백을 넣었는데, 실제 서버에서 **숫자 id(`26721`)로도 똑같이 404**가 나서 그 가설은
    틀렸다(id/key 문제가 아니다) — 그 폴백은 뺐다.

    다시 좁혀 보니 **`X-Atlassian-Token` 헤더 값 자체가 Jira 버전마다 다르다.** 최신
    Jira는 `no-check`(하이픈 있음)를 문서에 적어 두지만, Atlassian 커뮤니티에는 **하이픈
    없는 `nocheck`을 기대하는 더 오래된 빌드**(지금 이 서버처럼 2013년 빌드 계열)에서
    `no-check`를 보내면 XSRF 검사가 조용히 실패하며 **403이 아니라 404**로 거부된 사례가
    보고돼 있다. → `no-check`로 먼저 시도하고(최신 문서 값, 바뀌지 않는 기본 경로), 404면
    **같은 키로** `nocheck`(하이픈 없이)을 한 번 더 시도한다. 둘 다 안 되면 원래 404를
    그대로 올린다(두 번째 시도가 진짜 원인을 가리면 안 된다).
    """
    try:
        return _add_attachment_raw(key, filename, content, mime_type, 'no-check')
    except JiraApiError as e:
        if e.status != 404:
            raise
        return _add_attachment_raw(key, filename, content, mime_type, 'nocheck')


def do_transition(key, transition_id, comment=None):
    body = {'transition': {'id': str(transition_id)}}
    if comment:
        body['update'] = {'comment': [{'add': {'body': comment}}]}
    _request('POST', '/rest/api/2/issue/' + key + '/transitions', json=body)
    return {'ok': True}


def update_fields(key, fields):
    """fields 예: {'summary': '...', 'assignee': {'name': 'uid'}, 'priority': {'id': '3'}}"""
    _request('PUT', '/rest/api/2/issue/' + key, json={'fields': fields})
    return {'ok': True}


def priorities():
    r = _request('GET', '/rest/api/2/priority')
    return [{'id': p.get('id'), 'name': p.get('name')} for p in r.json()]


# ── 🆕 새 이슈(키) 생성 (2026-11-12, "제일 중요한 신규 이슈 생성 기능이 없다") ──────────
#  사람이 📝+ 새 이슈 모달에서 입력하고 버튼을 눌러야만 실행된다(쓰기는 읽기와 경로 분리 —
#  js/40 QA_TOOLS에 등록하지 않는다, docs/qa-tool-router.md 원칙 그대로).
def list_issue_types():
    """생성 모달의 '유형' 선택지. 하위 작업(subtask)은 뺀다 — 이 탭은 상위 이슈 생성만
    다룬다(하위 작업은 부모 이슈가 있어야 하는데 이 모달엔 그 입력이 없다)."""
    r = _request('GET', '/rest/api/2/issuetype')
    return [{'id': t.get('id'), 'name': t.get('name')} for t in r.json() if not t.get('subtask')]


def project_components(project_key):
    """생성 모달의 '구성 요소' 선택지 — 그 프로젝트에 실제로 등록된 것만(실측 이슈의
    components 값과 같은 이름이라야 한다)."""
    r = _request('GET', '/rest/api/2/project/' + project_key + '/components')
    return [{'id': c.get('id'), 'name': c.get('name')} for c in r.json()]


def create_issue(project_key, summary, description='', issuetype='Task', priority=None, assignee=None, components=None):
    """새 이슈를 만들고, 만든 뒤 바로 전체 모양으로 다시 읽어 돌려준다(다른 쓰기 함수들—
    add_comment/do_transition—과 같은 관례, 모달이 새로고침 없이 바로 그릴 수 있게).

    ⚠️⚠️ **issuetype/priority/components는 id가 아니라 이름으로 보낸다** — JIRA REST API가
    프로젝트 컨텍스트 안에서 이름을 해석해 주므로, 이 서버의 id 체계를 미리 알아낼 필요가
    없다(list_issue_types()/project_components()는 **생성 모달의 선택지를 보여주는 용도**일
    뿐, create_issue 자체는 그 목록이 없어도 사람이 적은 이름 그대로 시도한다). 그 프로젝트에
    없는 이름이거나 이 인스턴스만의 다른 필수 커스텀 필드가 있으면 JIRA가 400으로 알려주고
    그 메시지를 그대로 보여준다 — 추측해서 채우지 않는다(CLAUDE.md "결정론 먼저").
    """
    project_key = (project_key or '').strip()
    summary = (summary or '').strip()
    if not project_key:
        raise JiraApiError('프로젝트 코드가 없습니다 — 먼저 📁 연결 설정에서 지정해주세요.')
    if not summary:
        raise JiraApiError('요약을 입력해주세요.')
    fields = {
        'project': {'key': project_key},
        'summary': summary,
        'issuetype': {'name': issuetype or 'Task'},
    }
    if description:
        fields['description'] = description
    if priority:
        fields['priority'] = {'name': priority}
    if assignee:
        fields['assignee'] = {'name': assignee}
    if components:
        comps = [{'name': c} for c in components if c]
        if comps:
            fields['components'] = comps
    r = _request('POST', '/rest/api/2/issue', json={'fields': fields})
    j = r.json()
    key = j.get('key')
    if not key:
        raise JiraApiError('이슈가 생성된 것 같지만 키를 받지 못했습니다: %s' % j)
    return get_issue(key)


# ── 📁 프로젝트 목록 — 코드(key)와 이름(name)으로 둘 다 찾게 (2026-11-11) ──────────
#  실측: 604개, 응답 0.1초/186KB — 매번 불러도 될 정도로 가볍다. 그래도 탭을 들락거릴
#  때마다 다시 받지 않도록 짧게(5분) 캐시한다. ⚠️ 프로젝트 **이름**은 `LNW>SHUFFLER 3.0"`
#  처럼 특수문자·끝에 따옴표가 섞여 있어(실측) JQL `project = "그 이름"` 매칭이 깨지기
#  쉽다 — 그래서 이름은 **사람이 찾는 용도로만** 쓰고, 실제 연결은 **항상 key** 로 한다.
_PROJECT_CACHE = {'ts': 0, 'list': None}
_PROJECT_CACHE_TTL = 300


def list_projects(q=None):
    import time
    now = time.time()
    if _PROJECT_CACHE['list'] is None or (now - _PROJECT_CACHE['ts']) > _PROJECT_CACHE_TTL:
        r = _request('GET', '/rest/api/2/project')
        _PROJECT_CACHE['list'] = [{'key': p.get('key'), 'name': p.get('name')} for p in r.json()]
        _PROJECT_CACHE['ts'] = now
    out = _PROJECT_CACHE['list']
    if q:
        ql = q.strip().lower()
        out = [p for p in out if ql in (p['key'] or '').lower() or ql in (p['name'] or '').lower()]
    return out


def resolve_project_key(text):
    """사람이 적은 글자(코드 또는 이름의 일부)를 **정확히 하나의** 프로젝트 key 로 바꾼다.

    ⚠️ 여러 개에 걸리거나 하나도 안 걸리면 **추측하지 않고** None 을 돌려준다 — 잘못
    고르면 엉뚱한 프로젝트의 수백 건 이슈가 딸려 온다.
    """
    text = (text or '').strip()
    if not text:
        return None
    projects = list_projects()
    for p in projects:
        if p['key'] == text.upper():
            return p['key']
    hits = [p for p in projects if text.lower() in (p['name'] or '').lower()]
    if len(hits) == 1:
        return hits[0]['key']
    return None
